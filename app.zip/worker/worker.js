// Calculator chat server - Cloudflare Worker + D1 (binding name: DB).
// Keep this file ASCII only (safe to paste from a phone).
const ITER = 10000; // PBKDF2 rounds (free plan CPU is small; raise on paid plan)
const DUR = { day: 864e5, week: 6048e5, month: 2592e6, year: 31536e6 };
const MAX_MEDIA = 17 * 1024 * 1024;
const SCHEMA = [
  "CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, full_name TEXT NOT NULL, name_key TEXT NOT NULL, phone TEXT NOT NULL UNIQUE, username TEXT NOT NULL UNIQUE, pass_hash TEXT, pass_salt TEXT, rec_hash TEXT, rec_salt TEXT, role TEXT NOT NULL DEFAULT 'user', status TEXT NOT NULL DEFAULT 'pending', expires_at INTEGER DEFAULT 0, permanent INTEGER DEFAULT 0, created_at INTEGER, last_seen INTEGER DEFAULT 0, inbox_ver INTEGER DEFAULT 0, lock_hash TEXT, lock_salt TEXT, lock_hidden INTEGER DEFAULT 0)",
  "CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_at INTEGER)",
  "CREATE INDEX IF NOT EXISTS ix_sess_user ON sessions(user_id)",
  "CREATE TABLE IF NOT EXISTS codes (code TEXT PRIMARY KEY, duration TEXT NOT NULL, permanent INTEGER DEFAULT 0, max_uses INTEGER DEFAULT 1, uses INTEGER DEFAULT 0, note TEXT DEFAULT '', status TEXT DEFAULT 'active', created_at INTEGER)",
  "CREATE TABLE IF NOT EXISTS code_uses (code TEXT, user_id TEXT, used_at INTEGER, PRIMARY KEY(code,user_id))",
  "CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)",
  "CREATE TABLE IF NOT EXISTS chats (id TEXT PRIMARY KEY, type TEXT NOT NULL, name TEXT, dm_key TEXT UNIQUE, created_by TEXT, created_at INTEGER, updated_at INTEGER)",
  "CREATE TABLE IF NOT EXISTS chat_members (chat_id TEXT, user_id TEXT, role TEXT DEFAULT 'member', muted INTEGER DEFAULT 0, locked INTEGER DEFAULT 0, read_upto INTEGER DEFAULT 0, gone INTEGER DEFAULT 0, joined_at INTEGER, updated_at INTEGER, PRIMARY KEY(chat_id,user_id))",
  "CREATE INDEX IF NOT EXISTS ix_cm_user ON chat_members(user_id)",
  "CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, sender_id TEXT NOT NULL, type TEXT NOT NULL, body TEXT DEFAULT '', media TEXT, reply TEXT, reactions TEXT DEFAULT '{}', deleted INTEGER DEFAULT 0, created_at INTEGER, updated_at INTEGER, edited_at INTEGER DEFAULT 0)",
  "CREATE INDEX IF NOT EXISTS ix_msg_chat ON messages(chat_id, created_at)",
  "CREATE INDEX IF NOT EXISTS ix_msg_upd ON messages(updated_at)",
  "CREATE TABLE IF NOT EXISTS receipts (message_id TEXT, user_id TEXT, delivered_at INTEGER, read_at INTEGER, updated_at INTEGER, PRIMARY KEY(message_id,user_id))",
  "CREATE INDEX IF NOT EXISTS ix_rc_user ON receipts(user_id, delivered_at)",
  "CREATE INDEX IF NOT EXISTS ix_rc_upd ON receipts(updated_at)",
  "CREATE TABLE IF NOT EXISTS hidden_msgs (user_id TEXT, message_id TEXT, PRIMARY KEY(user_id,message_id))",
  "CREATE TABLE IF NOT EXISTS blocks (blocker_id TEXT, blocked_id TEXT, PRIMARY KEY(blocker_id,blocked_id))",
  "CREATE TABLE IF NOT EXISTS media (id TEXT PRIMARY KEY, owner_id TEXT, mime TEXT, size INTEGER, name TEXT, chunks INTEGER, created_at INTEGER)",
  "CREATE TABLE IF NOT EXISTS media_chunks (media_id TEXT, idx INTEGER, data TEXT, PRIMARY KEY(media_id,idx))",
  "CREATE TABLE IF NOT EXISTS typing (chat_id TEXT, user_id TEXT, until INTEGER, PRIMARY KEY(chat_id,user_id))",
  "CREATE TABLE IF NOT EXISTS attempts (k TEXT PRIMARY KEY, n INTEGER, ts INTEGER)"
];
let ready = false;

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'authorization,content-type',
  'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS'
};
const J = (o, s = 200) => new Response(JSON.stringify(o), {
  status: s, headers: { ...CORS, 'content-type': 'application/json', 'cache-control': 'no-store' }
});
const err = (m, s = 400) => J({ error: m }, s);
const enc = new TextEncoder();
const hex = (b) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
const rid = (n = 16) => hex(crypto.getRandomValues(new Uint8Array(n)));
const sha = async (s) => hex(await crypto.subtle.digest('SHA-256', enc.encode(s)));
async function hashPw(pw, salt) {
  const k = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: ITER }, k, 256);
  return hex(bits);
}
const eq = (a, b) => typeof a === 'string' && typeof b === 'string' && a.length === b.length && a === b;
const strong = (p) => typeof p === 'string' && p.length >= 8 && p.length <= 100 &&
  /[A-Z]/.test(p) && /[a-z]/.test(p) && /[0-9]/.test(p) && /[^A-Za-z0-9]/.test(p);
const normName = (n) => String(n || '').normalize('NFC').trim().replace(/\s+/g, ' ');
const nameKey = (n) => normName(n).toLowerCase();
function normPhone(p) {
  p = String(p || '').replace(/[\u0660-\u0669]/g, (d) => d.charCodeAt(0) - 0x660)
    .replace(/[\u06F0-\u06F9]/g, (d) => d.charCodeAt(0) - 0x6F0).replace(/[\s\-()]/g, '');
  return /^\+?[0-9]{8,15}$/.test(p) ? p : null;
}
const chunks = (a, n) => { const o = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };
const inList = (a, from = 1) => a.map((_, i) => '?' + (i + from)).join(',');

function accessOf(u, t) {
  if (u.role === 'owner') return 'ok';
  if (u.status === 'blocked') return 'blocked';
  if (u.status !== 'active') return 'need_code';
  if (u.permanent) return 'ok';
  return u.expires_at > t ? 'ok' : 'need_code';
}
function userOut(u, t) {
  return {
    id: u.id, full_name: u.full_name, username: u.username, phone: u.phone, role: u.role,
    access: accessOf(u, t), expires_at: u.expires_at, permanent: !!u.permanent,
    lock_hash: u.lock_hash || '', lock_salt: u.lock_salt || '', lock_hidden: !!u.lock_hidden
  };
}
function msgOut(r) {
  const d = !!r.deleted;
  return {
    id: r.id, chat_id: r.chat_id, sid: r.sender_id, type: r.type, body: d ? '' : r.body,
    media: d || !r.media ? null : JSON.parse(r.media), reply: d || !r.reply ? null : JSON.parse(r.reply),
    rx: d ? {} : JSON.parse(r.reactions || '{}'), del: d ? 1 : 0, at: r.created_at, up: r.updated_at, ed: r.edited_at || 0
  };
}
const HID = 'NOT EXISTS (SELECT 1 FROM hidden_msgs h WHERE h.user_id=?1 AND h.message_id=m.id)';
const BLK = 'NOT EXISTS (SELECT 1 FROM blocks b WHERE b.blocker_id=?1 AND b.blocked_id=m.sender_id)';

export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    try {
      if (!ready) { await env.DB.batch(SCHEMA.map((s) => env.DB.prepare(s))); ready = true; }
      return await route(req, env);
    } catch (e) {
      return J({ error: 'server_error', detail: String(e && e.message || e) }, 500);
    }
  }
};

async function body(req) { try { return await req.json(); } catch (e) { return {}; } }
async function newSession(env, uid) {
  const tok = rid(32);
  await env.DB.prepare('INSERT INTO sessions(token_hash,user_id,created_at) VALUES(?1,?2,?3)')
    .bind(await sha(tok), uid, Date.now()).run();
  return tok;
}
async function auth(env, req) {
  const m = /^Bearer (.+)$/.exec(req.headers.get('authorization') || '');
  if (!m) return null;
  const u = await env.DB.prepare(
    'SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?1').bind(await sha(m[1])).first();
  if (!u) return null;
  const t = Date.now();
  if ((u.last_seen || 0) < t - 45000) {
    await env.DB.prepare('UPDATE users SET last_seen=?1 WHERE id=?2').bind(t, u.id).run();
    u.last_seen = t;
  }
  return u;
}
async function limited(env, k, max = 8) {
  const r = await env.DB.prepare('SELECT n,ts FROM attempts WHERE k=?1').bind(k).first();
  return !!(r && r.ts > Date.now() - 900000 && r.n >= max);
}
async function failed(env, k) {
  const t = Date.now();
  await env.DB.prepare('INSERT INTO attempts(k,n,ts) VALUES(?1,1,?2) ON CONFLICT(k) DO UPDATE SET n=CASE WHEN ts<?3 THEN 1 ELSE n+1 END, ts=?2')
    .bind(k, t, t - 900000).run();
}
const cleared = (env, k) => env.DB.prepare('DELETE FROM attempts WHERE k=?1').bind(k).run();
const bumpSql = 'UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id IN (SELECT user_id FROM chat_members WHERE chat_id=?2 AND gone=0)';

async function route(req, env) {
  const url = new URL(req.url);
  const M = req.method;
  const P = url.pathname.split('/').filter(Boolean);
  if (P[0] !== 'api') return new Response('calc-chat ok', { headers: CORS });
  const A = P[1];
  const t = Date.now();

  if (A === 'ping') {
    const o = await env.DB.prepare("SELECT COUNT(*) c FROM users WHERE role='owner'").first();
    return J({ ok: true, owner: o.c > 0 });
  }
  if (A === 'register' && M === 'POST') return register(env, await body(req), t);
  if (A === 'login' && M === 'POST') return login(env, await body(req), t);
  if (A === 'recover' && M === 'POST') return recover(env, await body(req));

  const u = await auth(env, req);
  if (!u) return err('unauthorized', 401);
  const acc = accessOf(u, t);
  const b = (M === 'GET' || M === 'DELETE') ? {} : (A === 'media' && M === 'PUT' ? {} : await body(req));

  if (A === 'me') return J({ user: userOut(u, t), settings: await settings(env), now: t });
  if (A === 'logout') {
    const m = /^Bearer (.+)$/.exec(req.headers.get('authorization'));
    await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?1').bind(await sha(m[1])).run();
    return J({ ok: true });
  }
  if (A === 'password' && M === 'POST') return changePw(env, u, b, 'pass');
  if (A === 'recovery' && M === 'POST') return changePw(env, u, b, 'rec');
  if (A === 'lock' && M === 'POST') {
    await env.DB.prepare('UPDATE users SET lock_hash=COALESCE(?1,lock_hash), lock_salt=COALESCE(?2,lock_salt), lock_hidden=COALESCE(?3,lock_hidden) WHERE id=?4')
      .bind(b.hash || null, b.salt || null, b.hidden === undefined ? null : (b.hidden ? 1 : 0), u.id).run();
    return J({ ok: true });
  }
  if (A === 'redeem' && M === 'POST') return redeem(env, u, b, t);
  if (A === 'owner-chat') return ownerChat(env, u, M, b, t);

  if (A === 'owner') {
    if (u.role !== 'owner') return err('forbidden', 403);
    return ownerApi(env, u, P, M, b, t);
  }
  if (acc !== 'ok') return err(acc, 403);

  if (A === 'sync') return sync(env, u, url);
  if (A === 'users' && P[2] && M === 'GET') return userInfo(env, u, P[2]);
  if (A === 'lookup' && M === 'GET') {
    const x = await findUser(env, new URL(req.url).searchParams.get('q'), t);
    if (!x || x.id === u.id) return err('user_not_found', 404);
    return J({ user: uBrief(x) });
  }
  if (A === 'blocks' && M === 'POST') {
    if (!b.user_id || b.user_id === u.id) return err('bad_request');
    if (b.block) await env.DB.prepare('INSERT OR IGNORE INTO blocks VALUES(?1,?2)').bind(u.id, b.user_id).run();
    else await env.DB.prepare('DELETE FROM blocks WHERE blocker_id=?1 AND blocked_id=?2').bind(u.id, b.user_id).run();
    await env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, u.id).run();
    return J({ ok: true });
  }
  if (A === 'chats') return chatsApi(env, u, P, M, b, url, t);
  if (A === 'messages' && P[2]) return messageApi(env, u, P, M, b, t);
  if (A === 'media') return mediaApi(env, u, P, M, req, b, t);
  return err('not_found', 404);
}

async function settings(env) {
  const r = await env.DB.prepare("SELECT v FROM settings WHERE k='allow_screens'").first();
  return { allow_screens: !!(r && r.v === '1') };
}

async function register(env, b, t) {
  const name = normName(b.full_name), phone = normPhone(b.phone);
  const un = String(b.username || '').trim().toLowerCase();
  if (name.split(' ').length < 4 || name.length > 80 || !/^[\p{L}\p{M}' .-]+$/u.test(name)) return err('bad_name');
  if (!phone) return err('bad_phone');
  if (!/^[a-z0-9_.]{3,24}$/.test(un)) return err('bad_username');
  if (!strong(b.password)) return err('weak_password');
  if (!b.recovery || String(b.recovery).length < 4 || String(b.recovery).length > 100) return err('weak_recovery');
  const ps = rid(8), rs = rid(8);
  const id = rid(8);
  try {
    await env.DB.prepare(
      "INSERT INTO users(id,full_name,name_key,phone,username,pass_hash,pass_salt,rec_hash,rec_salt,role,status,created_at,last_seen,inbox_ver) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9," +
      "CASE WHEN (SELECT COUNT(*) FROM users)=0 THEN 'owner' ELSE 'user' END," +
      "CASE WHEN (SELECT COUNT(*) FROM users)=0 THEN 'active' ELSE 'pending' END,?10,?10,?10)")
      .bind(id, name, nameKey(name), phone, un, await hashPw(b.password, ps), ps,
        await hashPw(String(b.recovery), rs), rs, t).run();
  } catch (e) {
    const m = String(e && e.message || e);
    if (/users\.phone/.test(m)) return err('phone_taken', 409);
    if (/users\.username/.test(m)) return err('username_taken', 409);
    throw e;
  }
  const u = await env.DB.prepare('SELECT * FROM users WHERE id=?1').bind(id).first();
  return J({ token: await newSession(env, id), user: userOut(u, t), settings: await settings(env) });
}

async function login(env, b, t) {
  const un = String(b.username || '').trim().toLowerCase();
  const key = 'login:' + un;
  if (await limited(env, key)) return err('too_many', 429);
  const u = await env.DB.prepare('SELECT * FROM users WHERE username=?1').bind(un).first();
  const ok = u && eq(u.name_key, nameKey(b.full_name)) && u.phone === normPhone(b.phone) &&
    eq(u.pass_hash, await hashPw(String(b.password || ''), u.pass_salt));
  if (!ok) { await failed(env, key); return err('bad_login', 401); }
  await cleared(env, key);
  return J({ token: await newSession(env, u.id), user: userOut(u, t), settings: await settings(env) });
}

async function recover(env, b) {
  const un = String(b.username || '').trim().toLowerCase();
  const key = 'rec:' + un;
  if (await limited(env, key, 6)) return err('too_many', 429);
  const u = await env.DB.prepare('SELECT * FROM users WHERE username=?1').bind(un).first();
  const ok = u && eq(u.name_key, nameKey(b.full_name)) && u.phone === normPhone(b.phone) &&
    eq(u.rec_hash, await hashPw(String(b.recovery || ''), u.rec_salt));
  if (!ok) { await failed(env, key); return err('bad_recovery', 401); }
  if (!strong(b.new_password)) return err('weak_password');
  const s = rid(8);
  await env.DB.batch([
    env.DB.prepare('UPDATE users SET pass_hash=?1, pass_salt=?2 WHERE id=?3').bind(await hashPw(b.new_password, s), s, u.id),
    env.DB.prepare('DELETE FROM sessions WHERE user_id=?1').bind(u.id)]);
  await cleared(env, key);
  return J({ ok: true });
}

async function changePw(env, u, b, which) {
  const key = 'chg:' + u.id;
  if (await limited(env, key)) return err('too_many', 429);
  if (!eq(u.pass_hash, await hashPw(String(b.current || ''), u.pass_salt))) {
    await failed(env, key); return err('bad_login', 401);
  }
  await cleared(env, key);
  const s = rid(8);
  if (which === 'pass') {
    if (!strong(b.value)) return err('weak_password');
    await env.DB.prepare('UPDATE users SET pass_hash=?1, pass_salt=?2 WHERE id=?3').bind(await hashPw(b.value, s), s, u.id).run();
  } else {
    if (!b.value || String(b.value).length < 4 || String(b.value).length > 100) return err('weak_recovery');
    await env.DB.prepare('UPDATE users SET rec_hash=?1, rec_salt=?2 WHERE id=?3').bind(await hashPw(String(b.value), s), s, u.id).run();
  }
  return J({ ok: true });
}

async function redeem(env, u, b, t) {
  const code = String(b.code || '').trim();
  if (u.role === 'owner' || u.status === 'blocked') return err('forbidden', 403);
  const key = 'code:' + u.id;
  if (await limited(env, key, 10)) return err('too_many', 429);
  const c = await env.DB.prepare('SELECT * FROM codes WHERE code=?1').bind(code).first();
  if (!c || c.status !== 'active' || (c.max_uses > 0 && c.uses >= c.max_uses)) {
    await failed(env, key); return err('bad_code', 400);
  }
  const used = await env.DB.prepare('SELECT 1 x FROM code_uses WHERE code=?1 AND user_id=?2').bind(code, u.id).first();
  if (used) return err('code_used', 400);
  const up = await env.DB.prepare("UPDATE codes SET uses=uses+1 WHERE code=?1 AND status='active' AND (max_uses=0 OR uses<max_uses)").bind(code).run();
  if (!up.meta || up.meta.changes !== 1) return err('bad_code', 400);
  const base = Math.max(t, u.expires_at || 0);
  const exp = c.permanent ? 0 : base + (DUR[c.duration] || DUR.month);
  await env.DB.batch([
    env.DB.prepare('INSERT OR IGNORE INTO code_uses VALUES(?1,?2,?3)').bind(code, u.id, t),
    env.DB.prepare("UPDATE users SET status='active', permanent=CASE WHEN ?1=1 THEN 1 ELSE permanent END, expires_at=CASE WHEN ?1=1 THEN expires_at ELSE ?2 END WHERE id=?3")
      .bind(c.permanent ? 1 : 0, exp, u.id)]);
  await cleared(env, key);
  const n = await env.DB.prepare('SELECT * FROM users WHERE id=?1').bind(u.id).first();
  return J({ user: userOut(n, t) });
}

async function dmChat(env, a, b, t) {
  const key = [a, b].sort().join(':');
  const bump = () => env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, a).run();
  let c = await env.DB.prepare('SELECT id FROM chats WHERE dm_key=?1').bind(key).first();
  if (c) {
    await env.DB.prepare('UPDATE chat_members SET gone=0, updated_at=?1 WHERE chat_id=?2 AND user_id=?3 AND gone=1').bind(t, c.id, a).run();
    await bump();
    return c.id;
  }
  const id = rid(10);
  await env.DB.batch([
    env.DB.prepare("INSERT OR IGNORE INTO chats(id,type,dm_key,created_by,created_at,updated_at) VALUES(?1,'dm',?2,?3,?4,?4)").bind(id, key, a, t),
    env.DB.prepare('INSERT OR IGNORE INTO chat_members(chat_id,user_id,joined_at,updated_at,read_upto) SELECT ?1,?2,?3,?3,?3-1 WHERE EXISTS(SELECT 1 FROM chats WHERE id=?1)').bind(id, a, t),
    env.DB.prepare('INSERT OR IGNORE INTO chat_members(chat_id,user_id,joined_at,updated_at,read_upto) SELECT ?1,?2,?3,?3,?3-1 WHERE EXISTS(SELECT 1 FROM chats WHERE id=?1)').bind(id, b, t)]);
  await bump();
  c = await env.DB.prepare('SELECT id FROM chats WHERE dm_key=?1').bind(key).first();
  return c.id;
}

async function addMessage(env, chatId, sid, b, t) {
  const type = String(b.type || 'text');
  if (!['text', 'image', 'video', 'audio', 'file', 'sys'].includes(type)) return null;
  const id = /^[A-Za-z0-9_-]{8,40}$/.test(b.id || '') ? b.id : rid(12);
  let text = String(b.body || '').slice(0, 4000);
  if (type === 'text' && !text.trim()) return null;
  let media = null;
  if (b.media && type !== 'text' && type !== 'sys') {
    const m = b.media;
    const ex = await env.DB.prepare('SELECT 1 x FROM media WHERE id=?1').bind(String(m.id)).first();
    if (!ex) return null;
    media = JSON.stringify({
      id: String(m.id), mime: String(m.mime || '').slice(0, 80), size: +m.size || 0, name: String(m.name || '').slice(0, 120),
      chunks: +m.chunks || 1, dur: +m.dur || 0, w: +m.w || 0, h: +m.h || 0
    });
  }
  let reply = null;
  if (b.reply_to) {
    const r = await env.DB.prepare('SELECT id,sender_id,type,body FROM messages WHERE id=?1 AND chat_id=?2').bind(String(b.reply_to), chatId).first();
    if (r) reply = JSON.stringify({ id: r.id, sid: r.sender_id, type: r.type, body: String(r.body || '').slice(0, 120) });
  }
  await env.DB.batch([
    env.DB.prepare('INSERT OR IGNORE INTO messages(id,chat_id,sender_id,type,body,media,reply,created_at,updated_at) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?8)')
      .bind(id, chatId, sid, type, text, media, reply, t),
    env.DB.prepare('INSERT OR IGNORE INTO receipts(message_id,user_id,updated_at) SELECT ?1,user_id,?2 FROM chat_members WHERE chat_id=?3 AND gone=0 AND user_id!=?4')
      .bind(id, t, chatId, sid),
    env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, chatId),
    env.DB.prepare(bumpSql).bind(t, chatId)]);
  const row = await env.DB.prepare('SELECT * FROM messages WHERE id=?1').bind(id).first();
  return row;
}
const sysMsg = (env, chatId, actor, obj, t) => addMessage(env, chatId, actor, { type: 'sys', body: JSON.stringify(obj) }, t);

async function memberRow(env, chatId, uid) {
  return env.DB.prepare('SELECT * FROM chat_members WHERE chat_id=?1 AND user_id=?2 AND gone=0').bind(chatId, uid).first();
}
async function findUser(env, q, t) {
  q = String(q || '').trim().toLowerCase().replace(/^@/, '');
  if (!q) return null;
  const ph = normPhone(q);
  const u = await env.DB.prepare('SELECT * FROM users WHERE username=?1 OR phone=?2').bind(q, ph || '-').first();
  if (!u || accessOf(u, t) !== 'ok') return null;
  return u;
}
const uBrief = (u) => ({ id: u.id, full_name: u.full_name, username: u.username });

async function userInfo(env, me, id) {
  const u = await env.DB.prepare('SELECT * FROM users WHERE id=?1').bind(id).first();
  if (!u) return err('not_found', 404);
  const bl = await env.DB.prepare('SELECT 1 x FROM blocks WHERE blocker_id=?1 AND blocked_id=?2').bind(me.id, id).first();
  return J({ id: u.id, full_name: u.full_name, username: u.username, phone: u.phone, role: u.role, last_seen: u.last_seen, blocked: !!bl });
}

async function sync(env, u, url) {
  const inc = url.searchParams.has('since');
  const since = +url.searchParams.get('since') || 0;
  const chatId = url.searchParams.get('chat');
  const ver = u.inbox_ver || 0;
  const out = { ver, now: Date.now() };
  if (chatId) {
    const [ty, pe] = await env.DB.batch([
      env.DB.prepare('SELECT x.full_name n FROM typing ty JOIN users x ON x.id=ty.user_id WHERE ty.chat_id=?1 AND ty.until>?2 AND ty.user_id!=?3 AND EXISTS(SELECT 1 FROM chat_members WHERE chat_id=?1 AND user_id=?3 AND gone=0)').bind(chatId, out.now, u.id),
      env.DB.prepare('SELECT x.id,x.last_seen FROM chat_members cm JOIN users x ON x.id=cm.user_id WHERE cm.chat_id=?1 AND cm.gone=0 AND cm.user_id!=?2 AND EXISTS(SELECT 1 FROM chat_members WHERE chat_id=?1 AND user_id=?2 AND gone=0) LIMIT 3').bind(chatId, u.id)]);
    out.typing = ty.results.map((r) => r.n);
    out.seen = pe.results;
  }
  if (inc && ver <= since) return J(out);
  const lb = inc ? Math.max(1, since - 3000) : 0;
  const chats = (await env.DB.prepare(
    "SELECT c.id,c.type,c.name,c.created_by,c.updated_at,me.role my_role,me.muted,me.locked,me.read_upto,me.gone," +
    "(SELECT COUNT(*) FROM messages m WHERE m.chat_id=c.id AND m.sender_id!=?1 AND m.deleted=0 AND m.type!='sys' AND m.created_at>me.read_upto AND " + HID + " AND " + BLK + ") unread," +
    "(SELECT m.id FROM messages m WHERE m.chat_id=c.id AND " + HID + " AND " + BLK + " ORDER BY m.created_at DESC LIMIT 1) last_id " +
    "FROM chats c JOIN chat_members me ON me.chat_id=c.id AND me.user_id=?1 " +
    "WHERE (?2=0 OR c.updated_at>?2 OR me.updated_at>?2) AND (me.gone=0 OR ?2>0) AND (c.type='group' OR c.created_by=?1 OR EXISTS(SELECT 1 FROM messages x WHERE x.chat_id=c.id))").bind(u.id, lb).all()).results;
  const lastIds = chats.map((c) => c.last_id).filter(Boolean);
  const st = [
    env.DB.prepare('SELECT cm.chat_id,cm.user_id,cm.role,x.full_name,x.username FROM chat_members cm JOIN users x ON x.id=cm.user_id WHERE cm.gone=0 AND cm.chat_id IN (SELECT c.id FROM chats c JOIN chat_members me ON me.chat_id=c.id AND me.user_id=?1 WHERE (?2=0 OR c.updated_at>?2 OR me.updated_at>?2))').bind(u.id, lb),
    env.DB.prepare('SELECT blocked_id FROM blocks WHERE blocker_id=?1').bind(u.id)
  ];
  if (inc) {
    st.push(env.DB.prepare('SELECT m.* FROM messages m JOIN chat_members me ON me.chat_id=m.chat_id AND me.user_id=?1 AND me.gone=0 WHERE m.updated_at>?2 AND ' + HID + ' AND ' + BLK + ' ORDER BY m.updated_at LIMIT 300').bind(u.id, lb));
    st.push(env.DB.prepare('SELECT r.message_id,r.user_id,r.delivered_at,r.read_at FROM receipts r JOIN messages m ON m.id=r.message_id WHERE m.sender_id=?1 AND r.updated_at>?2').bind(u.id, lb));
  }
  for (const part of chunks(lastIds, 80)) {
    st.push(env.DB.prepare('SELECT * FROM messages WHERE id IN (' + inList(part) + ')').bind(...part));
    st.push(env.DB.prepare('SELECT message_id,user_id,delivered_at,read_at FROM receipts WHERE message_id IN (' + inList(part) + ')').bind(...part));
  }
  const rs = await env.DB.batch(st);
  const members = rs[0].results, blocked = rs[1].results.map((r) => r.blocked_id);
  let k = 2, newMsgs = [], rcs = [];
  if (inc) { newMsgs = rs[k++].results; rcs = rs[k++].results; }
  const lastMsgs = {}, lastRc = [];
  while (k < rs.length) {
    for (const r of rs[k++].results) lastMsgs[r.id] = r;
    lastRc.push(...rs[k++].results);
  }
  const mem = {};
  for (const m of members) (mem[m.chat_id] = mem[m.chat_id] || []).push({ id: m.user_id, role: m.role, full_name: m.full_name, username: m.username });
  out.full = !inc;
  out.blocked = blocked;
  out.chats = chats.map((c) => ({
    id: c.id, type: c.type, name: c.name, by: c.created_by, up: c.updated_at, role: c.my_role, muted: c.muted, locked: c.locked,
    read_upto: c.read_upto, gone: c.gone, unread: c.unread, members: mem[c.id] || [],
    last: c.last_id && lastMsgs[c.last_id] ? msgOut(lastMsgs[c.last_id]) : null
  }));
  out.msgs = newMsgs.map(msgOut);
  out.rcs = [...rcs, ...lastRc].map((r) => [r.message_id, r.user_id, r.delivered_at, r.read_at]);
  // mark delivered
  const t = Date.now();
  const und = await env.DB.prepare('SELECT DISTINCT m.sender_id s FROM receipts r JOIN messages m ON m.id=r.message_id WHERE r.user_id=?1 AND r.delivered_at IS NULL AND NOT EXISTS (SELECT 1 FROM blocks b WHERE b.blocker_id=?1 AND b.blocked_id=m.sender_id)').bind(u.id).all();
  if (und.results.length) {
    const ids = und.results.map((r) => r.s);
    await env.DB.batch([
      env.DB.prepare('UPDATE receipts SET delivered_at=?1, updated_at=?1 WHERE user_id=?2 AND delivered_at IS NULL AND NOT EXISTS (SELECT 1 FROM messages m JOIN blocks b ON b.blocker_id=?2 AND b.blocked_id=m.sender_id WHERE m.id=receipts.message_id)').bind(t, u.id),
      env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id IN (' + inList(ids, 2) + ')').bind(t, ...ids)]);
  }
  return J(out);
}

async function chatsApi(env, u, P, M, b, url, t) {
  const id = P[2];
  if (!id && M === 'POST') return J({ error: 'not_found' }, 404);
  if (id === 'dm' && M === 'POST') {
    let other = null;
    if (b.user_id) other = await env.DB.prepare('SELECT * FROM users WHERE id=?1').bind(String(b.user_id)).first();
    else other = await findUser(env, b.query, t);
    if (!other || other.id === u.id) return err('user_not_found', 404);
    if (accessOf(other, t) !== 'ok' && u.role !== 'owner') return err('user_not_found', 404);
    return J({ chat_id: await dmChat(env, u.id, other.id, t) });
  }
  if (id === 'group' && M === 'POST') {
    const name = String(b.name || '').trim().slice(0, 60);
    if (!name) return err('bad_name');
    const ids = [...new Set((b.members || []).map(String))].filter((x) => x !== u.id).slice(0, 255);
    const cid = rid(10);
    const sts = [
      env.DB.prepare("INSERT INTO chats(id,type,name,created_by,created_at,updated_at) VALUES(?1,'group',?2,?3,?4,?4)").bind(cid, name, u.id, t),
      env.DB.prepare("INSERT INTO chat_members(chat_id,user_id,role,joined_at,updated_at,read_upto) VALUES(?1,?2,'admin',?3,?3,?3)").bind(cid, u.id, t)];
    for (const x of ids) {
      sts.push(env.DB.prepare("INSERT OR IGNORE INTO chat_members(chat_id,user_id,joined_at,updated_at,read_upto) SELECT ?1,id,?3,?3,?3 FROM users WHERE id=?2 AND (role='owner' OR (status='active' AND (permanent=1 OR expires_at>?3)))").bind(cid, x, t));
    }
    await env.DB.batch(sts);
    await sysMsg(env, cid, u.id, { k: 'created', a: u.full_name, name }, t);
    return J({ chat_id: cid });
  }
  const me = await memberRow(env, id, u.id);
  if (!me) return err('not_member', 403);
  const chat = await env.DB.prepare('SELECT * FROM chats WHERE id=?1').bind(id).first();
  const sub = P[3];
  if (!sub && M === 'PATCH') {
    if (chat.type !== 'group' || me.role !== 'admin') return err('forbidden', 403);
    const name = String(b.name || '').trim().slice(0, 60);
    if (!name) return err('bad_name');
    await env.DB.prepare('UPDATE chats SET name=?1, updated_at=?2 WHERE id=?3').bind(name, t, id).run();
    await env.DB.prepare(bumpSql).bind(t, id).run();
    await sysMsg(env, id, u.id, { k: 'rename', a: u.full_name, name }, t);
    return J({ ok: true });
  }
  if (sub === 'me' && M === 'PATCH') {
    await env.DB.prepare('UPDATE chat_members SET muted=COALESCE(?1,muted), locked=COALESCE(?2,locked), updated_at=?3 WHERE chat_id=?4 AND user_id=?5')
      .bind(b.muted === undefined ? null : (b.muted ? 1 : 0), b.locked === undefined ? null : (b.locked ? 1 : 0), t, id, u.id).run();
    await env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, u.id).run();
    return J({ ok: true });
  }
  if (sub === 'read' && M === 'POST') {
    await env.DB.batch([
      env.DB.prepare('UPDATE chat_members SET read_upto=?1, updated_at=?1 WHERE chat_id=?2 AND user_id=?3').bind(t, id, u.id),
      env.DB.prepare('UPDATE receipts SET read_at=?1, delivered_at=COALESCE(delivered_at,?1), updated_at=?1 WHERE user_id=?2 AND read_at IS NULL AND message_id IN (SELECT id FROM messages WHERE chat_id=?3)').bind(t, u.id, id),
      env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id IN (SELECT user_id FROM chat_members WHERE chat_id=?2 AND gone=0)').bind(t, id)]);
    return J({ ok: true });
  }
  if (sub === 'typing' && M === 'POST') {
    await env.DB.prepare('INSERT OR REPLACE INTO typing VALUES(?1,?2,?3)').bind(id, u.id, t + 4500).run();
    return J({ ok: true });
  }
  if (sub === 'clear' && M === 'POST') {
    await env.DB.prepare('INSERT OR IGNORE INTO hidden_msgs SELECT ?1, id FROM messages WHERE chat_id=?2').bind(u.id, id).run();
    await env.DB.prepare('UPDATE chat_members SET read_upto=?1, updated_at=?1 WHERE chat_id=?2 AND user_id=?3').bind(t, id, u.id).run();
    await env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, u.id).run();
    return J({ ok: true });
  }
  if (sub === 'messages' && M === 'GET') {
    const before = +url.searchParams.get('before') || 0;
    const lim = Math.min(+url.searchParams.get('limit') || 40, 100);
    const [a, r] = await env.DB.batch([
      env.DB.prepare('SELECT m.* FROM messages m WHERE m.chat_id=?2 AND (?3=0 OR m.created_at<?3) AND ' + HID + ' AND ' + BLK + ' ORDER BY m.created_at DESC LIMIT ?4').bind(u.id, id, before, lim),
      env.DB.prepare('SELECT r.message_id,r.user_id,r.delivered_at,r.read_at FROM receipts r WHERE r.message_id IN (SELECT m.id FROM messages m WHERE m.chat_id=?2 AND m.sender_id=?1 AND (?3=0 OR m.created_at<?3) ORDER BY m.created_at DESC LIMIT ?4)').bind(u.id, id, before, lim)]);
    return J({ msgs: a.results.map(msgOut).reverse(), rcs: r.results.map((x) => [x.message_id, x.user_id, x.delivered_at, x.read_at]), more: a.results.length === lim });
  }
  if (sub === 'messages' && M === 'POST') {
    if (chat.type === 'dm') {
      const peer = await env.DB.prepare('SELECT user_id FROM chat_members WHERE chat_id=?1 AND user_id!=?2').bind(id, u.id).first();
      if (peer) {
        const bl = await env.DB.prepare('SELECT 1 x FROM blocks WHERE blocker_id=?1 AND blocked_id=?2').bind(u.id, peer.user_id).first();
        if (bl) return err('you_blocked', 403);
        await env.DB.prepare('UPDATE chat_members SET gone=0, updated_at=?1 WHERE chat_id=?2 AND user_id=?3 AND gone=1').bind(t, id, peer.user_id).run();
      }
    }
    const row = await addMessage(env, id, u.id, b, t);
    if (!row) return err('bad_message');
    return J({ msg: msgOut(row) });
  }
  if (chat.type === 'group') {
    if (sub === 'members' && M === 'POST') {
      if (me.role !== 'admin') return err('forbidden', 403);
      const x = b.user_id ? await env.DB.prepare('SELECT * FROM users WHERE id=?1').bind(String(b.user_id)).first() : await findUser(env, b.query, t);
      if (!x || accessOf(x, t) !== 'ok') return err('user_not_found', 404);
      await env.DB.prepare('INSERT INTO chat_members(chat_id,user_id,joined_at,updated_at,read_upto) VALUES(?1,?2,?3,?3,?3) ON CONFLICT(chat_id,user_id) DO UPDATE SET gone=0, role=\'member\', updated_at=?3, read_upto=?3').bind(id, x.id, t).run();
      await env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, id).run();
      await sysMsg(env, id, u.id, { k: 'add', a: u.full_name, b: x.full_name }, t);
      return J({ ok: true });
    }
    if (sub === 'members' && M === 'DELETE' && P[4]) {
      const target = P[4];
      if (target !== u.id && me.role !== 'admin') return err('forbidden', 403);
      const tm = await memberRow(env, id, target);
      if (!tm) return err('not_found', 404);
      const tu = await env.DB.prepare('SELECT full_name FROM users WHERE id=?1').bind(target).first();
      await env.DB.batch([
        env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, target),
        env.DB.prepare('UPDATE chat_members SET gone=1, updated_at=?1 WHERE chat_id=?2 AND user_id=?3').bind(t, id, target),
        env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, id)]);
      await sysMsg(env, id, u.id, target === u.id ? { k: 'left', a: u.full_name } : { k: 'remove', a: u.full_name, b: tu.full_name }, t);
      return J({ ok: true });
    }
    if (sub === 'admin' && M === 'POST') {
      if (me.role !== 'admin') return err('forbidden', 403);
      await env.DB.prepare('UPDATE chat_members SET role=?1, updated_at=?2 WHERE chat_id=?3 AND user_id=?4 AND gone=0').bind(b.admin ? 'admin' : 'member', t, id, String(b.user_id)).run();
      await env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, id).run();
      await env.DB.prepare(bumpSql).bind(t, id).run();
      return J({ ok: true });
    }
  }
  return err('not_found', 404);
}

async function messageApi(env, u, P, M, b, t) {
  const m = await env.DB.prepare('SELECT * FROM messages WHERE id=?1').bind(P[2]).first();
  if (!m) return err('not_found', 404);
  const me = await memberRow(env, m.chat_id, u.id);
  if (!me) return err('not_member', 403);
  const bump = () => env.DB.prepare(bumpSql).bind(t, m.chat_id);
  if (P[3] === 'react' && M === 'POST') {
    const rx = JSON.parse(m.reactions || '{}');
    const e = String(b.emoji || '').slice(0, 16);
    if (!e || rx[u.id] === e) delete rx[u.id]; else rx[u.id] = e;
    await env.DB.batch([
      env.DB.prepare('UPDATE messages SET reactions=?1, updated_at=?2 WHERE id=?3').bind(JSON.stringify(rx), t, m.id), bump()]);
    return J({ ok: true });
  }
  if (!P[3] && M === 'PATCH') {
    if (m.sender_id !== u.id || m.type !== 'text' || m.deleted) return err('forbidden', 403);
    if (t - m.created_at > 15 * 60 * 1000) return err('too_late', 403);
    const text = String(b.body || '').slice(0, 4000);
    if (!text.trim()) return err('bad_message');
    await env.DB.batch([
      env.DB.prepare('UPDATE messages SET body=?1, edited_at=?2, updated_at=?2 WHERE id=?3').bind(text, t, m.id),
      env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, m.chat_id), bump()]);
    return J({ ok: true });
  }
  if (P[3] === 'delete' && M === 'POST') {
    if (b.scope === 'all') {
      if (m.sender_id !== u.id) return err('forbidden', 403);
      await env.DB.batch([
        env.DB.prepare("UPDATE messages SET deleted=1, body='', updated_at=?1 WHERE id=?2").bind(t, m.id),
        env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, m.chat_id), bump()]);
      if (m.media) {
        const mid = JSON.parse(m.media).id;
        const other = await env.DB.prepare("SELECT 1 x FROM messages WHERE id!=?1 AND deleted=0 AND media LIKE ?2 LIMIT 1").bind(m.id, '%"id":"' + mid + '"%').first();
        if (!other) await env.DB.batch([
          env.DB.prepare('DELETE FROM media_chunks WHERE media_id=?1').bind(mid), env.DB.prepare('DELETE FROM media WHERE id=?1').bind(mid)]);
      }
    } else {
      await env.DB.batch([
        env.DB.prepare('INSERT OR IGNORE INTO hidden_msgs VALUES(?1,?2)').bind(u.id, m.id),
        env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, u.id)]);
    }
    return J({ ok: true });
  }
  return err('not_found', 404);
}

async function mediaApi(env, u, P, M, req, b, t) {
  if (!P[2] && M === 'POST') {
    const j = b;
    const size = +j.size || 0, n = +j.chunks || 0;
    if (size < 1 || size > MAX_MEDIA || n < 1 || n > 90) return err('too_big', 413);
    const id = rid(16);
    await env.DB.prepare('INSERT INTO media(id,owner_id,mime,size,name,chunks,created_at) VALUES(?1,?2,?3,?4,?5,?6,?7)')
      .bind(id, u.id, String(j.mime || '').slice(0, 80), size, String(j.name || '').slice(0, 120), n, t).run();
    return J({ id });
  }
  const id = P[2], idx = parseInt(P[3], 10);
  if (!id || !(idx >= 0)) return err('bad_request');
  if (M === 'PUT') {
    const md = await env.DB.prepare('SELECT * FROM media WHERE id=?1 AND owner_id=?2').bind(id, u.id).first();
    if (!md || idx >= md.chunks) return err('not_found', 404);
    const data = await req.text();
    if (data.length > 460000) return err('too_big', 413);
    await env.DB.prepare('INSERT OR REPLACE INTO media_chunks VALUES(?1,?2,?3)').bind(id, idx, data).run();
    return J({ ok: true });
  }
  if (M === 'GET') {
    const r = await env.DB.prepare('SELECT data FROM media_chunks WHERE media_id=?1 AND idx=?2').bind(id, idx).first();
    if (!r) return err('not_found', 404);
    return new Response(r.data, { headers: { ...CORS, 'content-type': 'text/plain', 'cache-control': 'private, max-age=31536000, immutable' } });
  }
  return err('not_found', 404);
}

async function ownerChat(env, u, M, b, t) {
  const o = await env.DB.prepare("SELECT id,full_name FROM users WHERE role='owner' LIMIT 1").first();
  if (!o || u.role === 'owner') return err('forbidden', 403);
  if (u.status === 'blocked') return err('blocked', 403);
  const cid = await dmChat(env, u.id, o.id, t);
  if (M === 'POST') {
    const recent = await env.DB.prepare('SELECT COUNT(*) c FROM messages WHERE sender_id=?1 AND created_at>?2').bind(u.id, t - 60000).first();
    if (recent.c >= 8) return err('too_many', 429);
    const row = await addMessage(env, cid, u.id, { type: 'text', body: String(b.text || '').slice(0, 600), id: b.id }, t);
    if (!row) return err('bad_message');
    return J({ msg: msgOut(row) });
  }
  const rs = await env.DB.batch([
    env.DB.prepare('SELECT m.* FROM messages m WHERE m.chat_id=?2 AND m.type=\'text\' AND ' + HID + ' ORDER BY m.created_at DESC LIMIT 60').bind(u.id, cid),
    env.DB.prepare('SELECT r.message_id,r.user_id,r.delivered_at,r.read_at FROM receipts r WHERE r.message_id IN (SELECT id FROM messages WHERE chat_id=?2 AND sender_id=?1 ORDER BY created_at DESC LIMIT 60)').bind(u.id, cid),
    env.DB.prepare('UPDATE receipts SET read_at=?1, delivered_at=COALESCE(delivered_at,?1), updated_at=?1 WHERE user_id=?2 AND read_at IS NULL AND message_id IN (SELECT id FROM messages WHERE chat_id=?3)').bind(t, u.id, cid)]);
  return J({ owner: { id: o.id, full_name: o.full_name }, msgs: rs[0].results.map(msgOut).reverse(), rcs: rs[1].results.map((x) => [x.message_id, x.user_id, x.delivered_at, x.read_at]) });
}

async function ownerApi(env, u, P, M, b, t) {
  const sub = P[2], act = P[3];
  if (sub === 'codes' && M === 'GET') {
    const cs = (await env.DB.prepare('SELECT * FROM codes ORDER BY created_at DESC').all()).results;
    const us = (await env.DB.prepare('SELECT cu.code,x.full_name n,cu.used_at at FROM code_uses cu JOIN users x ON x.id=cu.user_id ORDER BY cu.used_at').all()).results;
    return J({ codes: cs.map((c) => ({ ...c, used_by: us.filter((x) => x.code === c.code).map((x) => ({ name: x.n, at: x.at })) })) });
  }
  if (sub === 'codes' && M === 'POST' && !act) {
    const code = String(b.code || '');
    if (code.length < 4 || code.length > 64 || /\s/.test(code)) return err('bad_code_format');
    const perm = b.permanent ? 1 : 0;
    const dur = perm ? 'year' : String(b.duration);
    if (!DUR[dur]) return err('bad_request');
    const max = b.unlimited ? 0 : Math.max(1, Math.min(10000, parseInt(b.max_uses, 10) || 1));
    try {
      await env.DB.prepare('INSERT INTO codes(code,duration,permanent,max_uses,note,created_at) VALUES(?1,?2,?3,?4,?5,?6)')
        .bind(code, dur, perm, max, String(b.note || '').slice(0, 80), t).run();
    } catch (e) {
      if (/UNIQUE|PRIMARY/i.test(String(e && e.message || e))) return err('code_exists', 409);
      throw e;
    }
    return J({ ok: true });
  }
  if (sub === 'codes' && act === 'cancel' && M === 'POST') {
    await env.DB.prepare("UPDATE codes SET status=CASE WHEN status='active' THEN 'cancelled' ELSE 'active' END WHERE code=?1").bind(String(b.code)).run();
    return J({ ok: true });
  }
  if (sub === 'codes' && act === 'delete' && M === 'POST') {
    await env.DB.batch([
      env.DB.prepare('DELETE FROM codes WHERE code=?1').bind(String(b.code)),
      env.DB.prepare('DELETE FROM code_uses WHERE code=?1').bind(String(b.code))]);
    return J({ ok: true });
  }
  if (sub === 'members' && M === 'GET') {
    const r = (await env.DB.prepare("SELECT * FROM users WHERE role!='owner' ORDER BY created_at DESC").all()).results;
    return J({ members: r.map((x) => ({
      id: x.id, full_name: x.full_name, username: x.username, phone: x.phone, status: x.status, access: accessOf(x, t),
      permanent: !!x.permanent, expires_at: x.expires_at, last_seen: x.last_seen, created_at: x.created_at
    })) });
  }
  if (sub === 'members' && M === 'POST' && b.id) {
    if (act === 'block') await env.DB.prepare("UPDATE users SET status='blocked' WHERE id=?1 AND role!='owner'").bind(b.id).run();
    else if (act === 'unblock') await env.DB.prepare("UPDATE users SET status=CASE WHEN permanent=1 OR expires_at>0 THEN 'active' ELSE 'pending' END WHERE id=?1 AND status='blocked'").bind(b.id).run();
    else if (act === 'revoke') await env.DB.prepare("UPDATE users SET status='pending', permanent=0, expires_at=0 WHERE id=?1 AND role!='owner'").bind(b.id).run();
    else return err('bad_request');
    return J({ ok: true });
  }
  if (sub === 'settings' && M === 'POST') {
    await env.DB.prepare("INSERT OR REPLACE INTO settings VALUES('allow_screens',?1)").bind(b.allow_screens ? '1' : '0').run();
    return J({ ok: true });
  }
  return err('not_found', 404);
}
