// Calculator chat server - Cloudflare Worker + D1 (binding name: DB).
// Keep this file ASCII only (safe to paste from a phone).
const ITER = 10000; // PBKDF2 rounds (free plan CPU is small; raise on paid plan)
const DUR = { day: 864e5, week: 6048e5, month: 2592e6, year: 31536e6 };
const MAX_MEDIA = 64 * 1024 * 1024;
const CHUNK_BLOB = 2 * 1024 * 1024;   // media piece size when R2 / KV is used (fewer writes than 240 KB pieces)
const LOOK = 15000;                   // sync look-back (ms) so a slow writer is never missed
const SESSION_TTL = 90 * 864e5;       // old logins are removed on the next login of that user
const SCHEMA = [
  "CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, full_name TEXT NOT NULL, name_key TEXT NOT NULL, phone TEXT NOT NULL UNIQUE, username TEXT NOT NULL UNIQUE, pass_hash TEXT, pass_salt TEXT, rec_hash TEXT, rec_salt TEXT, role TEXT NOT NULL DEFAULT 'user', status TEXT NOT NULL DEFAULT 'pending', expires_at INTEGER DEFAULT 0, permanent INTEGER DEFAULT 0, created_at INTEGER, last_seen INTEGER DEFAULT 0, inbox_ver INTEGER DEFAULT 0, lock_hash TEXT, lock_salt TEXT, lock_hidden INTEGER DEFAULT 0)",
  "CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_at INTEGER)",
  "CREATE INDEX IF NOT EXISTS ix_sess_user ON sessions(user_id)",
  "CREATE TABLE IF NOT EXISTS codes (code TEXT PRIMARY KEY, duration TEXT NOT NULL, permanent INTEGER DEFAULT 0, max_uses INTEGER DEFAULT 1, uses INTEGER DEFAULT 0, note TEXT DEFAULT '', status TEXT DEFAULT 'active', created_at INTEGER)",
  "CREATE TABLE IF NOT EXISTS code_uses (code TEXT, user_id TEXT, used_at INTEGER, PRIMARY KEY(code,user_id))",
  "CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)",
  "CREATE TABLE IF NOT EXISTS chats (id TEXT PRIMARY KEY, type TEXT NOT NULL, name TEXT, dm_key TEXT UNIQUE, created_by TEXT, created_at INTEGER, updated_at INTEGER)",
  "CREATE TABLE IF NOT EXISTS chat_members (chat_id TEXT, user_id TEXT, role TEXT DEFAULT 'member', muted INTEGER DEFAULT 0, locked INTEGER DEFAULT 0, read_upto INTEGER DEFAULT 0, gone INTEGER DEFAULT 0, joined_at INTEGER, updated_at INTEGER, PRIMARY KEY(chat_id,user_id))",
  "CREATE INDEX IF NOT EXISTS ix_cm_user ON chat_members(user_id)",
  "CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, sender_id TEXT NOT NULL, type TEXT NOT NULL, body TEXT DEFAULT '', media TEXT, reply TEXT, reactions TEXT DEFAULT '{}', deleted INTEGER DEFAULT 0, created_at INTEGER, updated_at INTEGER, edited_at INTEGER DEFAULT 0)",
  "CREATE INDEX IF NOT EXISTS ix_msg_chat ON messages(chat_id, created_at)",
  "CREATE TABLE IF NOT EXISTS receipts (message_id TEXT, user_id TEXT, delivered_at INTEGER, read_at INTEGER, updated_at INTEGER, PRIMARY KEY(message_id,user_id))",
  "CREATE INDEX IF NOT EXISTS ix_rc_user ON receipts(user_id, delivered_at)",
  "CREATE INDEX IF NOT EXISTS ix_rc_upd ON receipts(updated_at)",
  "CREATE TABLE IF NOT EXISTS hidden_msgs (user_id TEXT, message_id TEXT, PRIMARY KEY(user_id,message_id))",
  "CREATE TABLE IF NOT EXISTS blocks (blocker_id TEXT, blocked_id TEXT, PRIMARY KEY(blocker_id,blocked_id))",
  "CREATE TABLE IF NOT EXISTS media (id TEXT PRIMARY KEY, owner_id TEXT, mime TEXT, size INTEGER, name TEXT, chunks INTEGER, created_at INTEGER)",
  "CREATE TABLE IF NOT EXISTS media_chunks (media_id TEXT, idx INTEGER, data TEXT, PRIMARY KEY(media_id,idx))",
  "CREATE TABLE IF NOT EXISTS typing (chat_id TEXT, user_id TEXT, until INTEGER, PRIMARY KEY(chat_id,user_id))",
  "CREATE TABLE IF NOT EXISTS attempts (k TEXT PRIMARY KEY, n INTEGER, ts INTEGER)"
];
const SCHEMA_V = '5';
const DROPS = ['DROP INDEX IF EXISTS ix_msg_upd'];
const EXTRA_SCHEMA = [
  "CREATE TABLE IF NOT EXISTS contacts (owner_id TEXT, contact_id TEXT, name TEXT, PRIMARY KEY(owner_id,contact_id))"
];
const COLS = {
  users: [['id', 'TEXT'], ['full_name', 'TEXT'], ['name_key', 'TEXT'], ['phone', 'TEXT'], ['username', 'TEXT'], ['pass_hash', 'TEXT'], ['pass_salt', 'TEXT'],
    ['rec_hash', 'TEXT'], ['rec_salt', 'TEXT'], ['role', "TEXT DEFAULT 'user'"], ['status', "TEXT DEFAULT 'pending'"], ['expires_at', 'INTEGER DEFAULT 0'],
    ['permanent', 'INTEGER DEFAULT 0'], ['created_at', 'INTEGER'], ['last_seen', 'INTEGER DEFAULT 0'], ['inbox_ver', 'INTEGER DEFAULT 0'], ['lock_hash', 'TEXT'],
    ['lock_salt', 'TEXT'], ['lock_hidden', 'INTEGER DEFAULT 0'], ['pubkey', 'TEXT'], ['key_blob', 'TEXT'], ['key_blob_rec', 'TEXT'], ['auth_v', 'INTEGER DEFAULT 0'],
    ['show_seen', 'INTEGER DEFAULT 1'], ['show_read', 'INTEGER DEFAULT 1'], ['show_typing', 'INTEGER DEFAULT 1'], ['about', 'TEXT'], ['avatar', 'TEXT'], ['avatar_ver', 'INTEGER DEFAULT 0'], ['kdf_salt', 'TEXT']],
  sessions: [['token_hash', 'TEXT'], ['user_id', 'TEXT'], ['created_at', 'INTEGER'], ['ua', 'TEXT'], ['last_used', 'INTEGER']],
  codes: [['code', 'TEXT'], ['duration', 'TEXT'], ['permanent', 'INTEGER DEFAULT 0'], ['max_uses', 'INTEGER DEFAULT 1'], ['uses', 'INTEGER DEFAULT 0'], ['note', "TEXT DEFAULT ''"], ['status', "TEXT DEFAULT 'active'"], ['created_at', 'INTEGER']],
  code_uses: [['code', 'TEXT'], ['user_id', 'TEXT'], ['used_at', 'INTEGER']],
  settings: [['k', 'TEXT'], ['v', 'TEXT']],
  chats: [['id', 'TEXT'], ['type', 'TEXT'], ['name', 'TEXT'], ['dm_key', 'TEXT'], ['created_by', 'TEXT'], ['created_at', 'INTEGER'], ['updated_at', 'INTEGER']],
  chat_members: [['chat_id', 'TEXT'], ['user_id', 'TEXT'], ['role', "TEXT DEFAULT 'member'"], ['muted', 'INTEGER DEFAULT 0'], ['locked', 'INTEGER DEFAULT 0'], ['read_upto', 'INTEGER DEFAULT 0'],
    ['gone', 'INTEGER DEFAULT 0'], ['joined_at', 'INTEGER'], ['updated_at', 'INTEGER'], ['pinned', 'INTEGER DEFAULT 0'], ['clear_at', 'INTEGER DEFAULT 0'], ['archived', 'INTEGER DEFAULT 0']],
  messages: [['id', 'TEXT'], ['chat_id', 'TEXT'], ['sender_id', 'TEXT'], ['type', 'TEXT'], ['body', "TEXT DEFAULT ''"], ['media', 'TEXT'], ['reply', 'TEXT'], ['reactions', "TEXT DEFAULT '{}'"],
    ['deleted', 'INTEGER DEFAULT 0'], ['created_at', 'INTEGER'], ['updated_at', 'INTEGER'], ['edited_at', 'INTEGER DEFAULT 0'], ['enc', 'INTEGER DEFAULT 0'], ['media_id', 'TEXT']],
  receipts: [['message_id', 'TEXT'], ['user_id', 'TEXT'], ['delivered_at', 'INTEGER'], ['read_at', 'INTEGER'], ['updated_at', 'INTEGER']],
  hidden_msgs: [['user_id', 'TEXT'], ['message_id', 'TEXT']],
  blocks: [['blocker_id', 'TEXT'], ['blocked_id', 'TEXT']],
  media: [['id', 'TEXT'], ['owner_id', 'TEXT'], ['mime', 'TEXT'], ['size', 'INTEGER'], ['name', 'TEXT'], ['chunks', 'INTEGER'], ['created_at', 'INTEGER'], ['store', 'TEXT']],
  media_chunks: [['media_id', 'TEXT'], ['idx', 'INTEGER'], ['data', 'TEXT']],
  typing: [['chat_id', 'TEXT'], ['user_id', 'TEXT'], ['until', 'INTEGER']],
  attempts: [['k', 'TEXT'], ['n', 'INTEGER'], ['ts', 'INTEGER']],
  contacts: [['owner_id', 'TEXT'], ['contact_id', 'TEXT'], ['name', 'TEXT']]
};
const INDEXES = [
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_settings_k ON settings(k)', 'CREATE UNIQUE INDEX IF NOT EXISTS ux_attempts_k ON attempts(k)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_typing ON typing(chat_id,user_id)', 'CREATE UNIQUE INDEX IF NOT EXISTS ux_cm ON chat_members(chat_id,user_id)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_rc ON receipts(message_id,user_id)', 'CREATE UNIQUE INDEX IF NOT EXISTS ux_blocks ON blocks(blocker_id,blocked_id)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_hidden ON hidden_msgs(user_id,message_id)', 'CREATE UNIQUE INDEX IF NOT EXISTS ux_cu ON code_uses(code,user_id)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_mc ON media_chunks(media_id,idx)', 'CREATE UNIQUE INDEX IF NOT EXISTS ux_sess ON sessions(token_hash)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_codes ON codes(code)', 'CREATE UNIQUE INDEX IF NOT EXISTS ux_contacts ON contacts(owner_id,contact_id)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_chatid ON chats(id)', 'CREATE UNIQUE INDEX IF NOT EXISTS ux_msgid ON messages(id)',
  'CREATE INDEX IF NOT EXISTS ix_users_phone ON users(phone)', 'CREATE INDEX IF NOT EXISTS ix_users_username ON users(username)',
  /* v4: the indexes that keep every hot query from scanning a whole table */
  'CREATE INDEX IF NOT EXISTS ix_users_role ON users(role)',
  'CREATE INDEX IF NOT EXISTS ix_msg_chat_upd ON messages(chat_id, updated_at)',
  'CREATE INDEX IF NOT EXISTS ix_msg_media ON messages(media_id) WHERE media_id IS NOT NULL'
];
/* every users column except the avatar picture, so a normal request never drags the picture along */
const UCOLS = COLS.users.map((c) => c[0]).filter((c) => c !== 'avatar');
const UC = UCOLS.join(',');
const UCU = UCOLS.map((c) => 'u.' + c).join(',');
let schemaOk = false, needRepair = false, schemaP = null, schemaFailUntil = 0;

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'authorization,content-type',
  'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
  'access-control-expose-headers': 'x-enc,retry-after',
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
  'x-frame-options': 'DENY',
  'strict-transport-security': 'max-age=63072000; includeSubDomains'
};
const MSG = {
  bad_request: 'The request is invalid.', unauthorized: 'Please sign in again.', forbidden: 'You are not allowed to do that.', not_found: 'Not found.',
  bad_name: 'Enter four names (letters only).', bad_phone: 'Enter a valid phone number.', bad_username: 'Username must be 3-24 letters, digits, _ or .',
  weak_password: 'Password is too weak.', weak_recovery: 'Recovery password is too short.', phone_taken: 'This phone number is already registered.',
  username_taken: 'This username is taken.', bad_login: 'The details or password are incorrect.', bad_recovery: 'The details or recovery password are incorrect.',
  too_many: 'Too many attempts. Try again in 15 minutes.', bad_code: 'Invalid or used-up code.', code_used: 'You already used this code.',
  code_exists: 'This code already exists.', bad_code_format: 'Code must be 4-64 characters without spaces.', user_not_found: 'No active user with this number or username.',
  you_blocked: 'Unblock this contact to send messages.', not_member: 'You are not in this chat.', need_code: 'Activation required.', blocked: 'Account blocked.',
  too_big: 'File is too big.', too_late: 'Editing is only possible for 15 minutes.', bad_message: 'Message could not be sent.', db_error: 'Database problem. The server tried to repair it, please try again.',
  server_error: 'Unexpected server error.', upgrade_required: 'Please update your security settings first.', bad_ticket: 'The recovery session expired. Start again.',
  no_key: 'This contact has not enabled encryption yet.', quota: 'The free daily limit of the server was reached. It resets at 00:00 UTC. Try again later.',
  no_storage: 'File storage is not set up on the server yet.'
};
const J = (o, s = 200) => new Response(JSON.stringify(o), {
  status: s, headers: { ...CORS, 'content-type': 'application/json', 'cache-control': 'no-store' }
});
const err = (m, s = 400, extra) => { const r = J({ error: m, message: MSG[m] || m, ...(extra || {}) }, s); if (s === 503) r.headers.set('retry-after', '20'); return r; };
const enc = new TextEncoder();
const hex = (b) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
const rid = (n = 16) => hex(crypto.getRandomValues(new Uint8Array(n)));
const sha = async (s) => hex(await crypto.subtle.digest('SHA-256', enc.encode(s)));
const hashD = (pw, salt) => sha('calc-d1:' + salt + ':' + pw);
async function hashPw(pw, salt) {
  const k = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: ITER }, k, 256);
  return hex(bits);
}
const eq = (a, b) => typeof a === 'string' && typeof b === 'string' && a.length === b.length && a === b;
const strong = (p) => typeof p === 'string' && p.length >= 8 && p.length <= 100 &&
  /[A-Z]/.test(p) && /[a-z]/.test(p) && /[0-9]/.test(p) && /[^A-Za-z0-9]/.test(p);
const isHex = (s) => typeof s === 'string' && /^[0-9a-f]{64}$/.test(s);
const okPub = (s) => typeof s === 'string' && /^[A-Za-z0-9+\/=]{80,160}$/.test(s);
const okSalt = (s) => typeof s === 'string' && /^[0-9a-f]{16,64}$/.test(s);
const okBlob = (s) => typeof s === 'string' && s.length > 20 && s.length < 8000;
const normName = (n) => String(n || '').normalize('NFC').trim().replace(/\s+/g, ' ');
const nameKey = (n) => normName(n).toLowerCase();
function normPhone(p) {
  p = String(p || '').replace(/[\u0660-\u0669]/g, (d) => d.charCodeAt(0) - 0x660)
    .replace(/[\u06F0-\u06F9]/g, (d) => d.charCodeAt(0) - 0x6F0).replace(/[\s\-()]/g, '');
  return /^\+?[0-9]{8,15}$/.test(p) ? p : null;
}
function b64ToBytes(b64) {
  const bin = atob(b64); const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}
function parseDataUrl(s) {
  const m = /^data:(image\/[a-z]+);base64,(.+)$/.exec(String(s || ''));
  return m ? { mime: m[1], b64: m[2] } : null;
}
/* ---- file storage: R2 first, then KV (both free), never D1 for new files ---- */
const blobKind = (env) => (env.R2 ? 'r2' : (env.KV ? 'kv' : 'none'));
async function blobPut(env, key, data, meta) {
  if (env.R2) { await env.R2.put(key, data, { customMetadata: meta || {} }); return true; }
  if (env.KV) { await env.KV.put(key, data, { metadata: meta || {} }); return true; }
  return false;
}
async function blobGet(env, key) {
  if (env.R2) { const o = await env.R2.get(key); return o ? { body: o.body, meta: o.customMetadata || {} } : null; }
  if (env.KV) { const r = await env.KV.getWithMetadata(key, 'arrayBuffer'); return r && r.value ? { body: r.value, meta: r.metadata || {} } : null; }
  return null;
}
async function blobDel(env, keys) {
  if (!keys.length) return;
  try {
    if (env.R2) await env.R2.delete(keys);
    else if (env.KV) for (const k of keys.slice(0, 40)) await env.KV.delete(k);
  } catch (e) { console.error('blob delete failed ' + e); }
}
const chunks = (a, n) => { const o = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };
const inList = (a, from = 1) => a.map((_, i) => '?' + (i + from)).join(',');

function accessOf(u, t) {
  if (u.role === 'owner') return 'ok';
  if (u.status === 'blocked') return 'blocked';
  if (u.status !== 'active') return 'need_code';
  if (u.permanent) return 'ok';
  return u.expires_at > t ? 'ok' : 'need_code';
}
function userOut(u, t) {
  return {
    id: u.id, full_name: u.full_name, username: u.username, phone: u.phone, role: u.role,
    access: accessOf(u, t), expires_at: u.expires_at, permanent: !!u.permanent,
    lock_hash: u.lock_hash || '', lock_salt: u.lock_salt || '', lock_hidden: !!u.lock_hidden,
    pubkey: u.pubkey || '', kdf: u.kdf_salt || '', auth_v: u.auth_v || 0, about: u.about || '', avatar_ver: u.avatar_ver || 0,
    show_seen: u.show_seen === 0 ? 0 : 1, show_read: u.show_read === 0 ? 0 : 1, show_typing: u.show_typing === 0 ? 0 : 1
  };
}
function msgOut(r) {
  const d = !!r.deleted;
  const pj = (s, f) => { try { return JSON.parse(s); } catch (e) { return f; } };
  return {
    id: r.id, chat_id: r.chat_id, sid: r.sender_id, type: r.type, body: d ? '' : r.body, enc: r.enc ? 1 : 0,
    media: d || !r.media ? null : pj(r.media, null), reply: d || !r.reply ? null : pj(r.reply, null),
    rx: d ? {} : pj(r.reactions || '{}', {}), del: d ? 1 : 0, at: r.created_at, up: r.updated_at, ed: r.edited_at || 0
  };
}
const HID = 'NOT EXISTS (SELECT 1 FROM hidden_msgs h WHERE h.user_id=?1 AND h.message_id=m.id)';
const BLK = 'NOT EXISTS (SELECT 1 FROM blocks b WHERE b.blocker_id=?1 AND b.blocked_id=m.sender_id)';

function ensureSchema(env, force) {
  if (schemaOk && !force) return Promise.resolve();
  if (!force && Date.now() < schemaFailUntil) return Promise.reject(new HttpError(503, 'db_error', { detail: 'database is recovering, retry in a few seconds' }));
  if (!schemaP) {
    schemaP = ensureSchemaNow(env, force).then(() => { schemaP = null; }, (e) => { schemaP = null; schemaFailUntil = Date.now() + 5000; throw e; });
  }
  return schemaP;
}
async function ensureSchemaNow(env, force) {
  let v = null;
  if (!force) {
    try { const r = await env.DB.prepare("SELECT v FROM settings WHERE k='schema_v'").first(); v = r && r.v; } catch (e) { v = null; }
  }
  if (v === SCHEMA_V && !force) { schemaOk = true; return; }
  await env.DB.batch(SCHEMA.concat(EXTRA_SCHEMA).map((s) => env.DB.prepare(s)));
  const names = Object.keys(COLS);
  let infos = [];
  try { infos = await env.DB.batch(names.map((n) => env.DB.prepare('PRAGMA table_info(' + n + ')'))); } catch (e) { infos = []; }
  const alters = [];
  names.forEach((n, i) => {
    if (!infos[i] || !infos[i].results || !infos[i].results.length) return;
    const have = new Set(infos[i].results.map((r) => r.name));
    for (const [c, d] of COLS[n]) if (!have.has(c)) alters.push('ALTER TABLE ' + n + ' ADD COLUMN ' + c + ' ' + d);
  });
  for (const s of alters) { try { await env.DB.prepare(s).run(); } catch (e) { console.error('alter failed: ' + s + ' ' + e); } }
  try { await env.DB.batch(INDEXES.map((s) => env.DB.prepare(s))); } catch (e) {
    for (const s of INDEXES) { try { await env.DB.prepare(s).run(); } catch (e2) { console.error('index failed: ' + s + ' ' + e2); } }
  }
  for (const s of DROPS) { try { await env.DB.prepare(s).run(); } catch (e) { console.error('drop failed: ' + s + ' ' + e); } }
  /* one time: remember which file each old media message points to, so deleting never needs a full scan */
  if (alters.some((s) => s.includes('media_id'))) {
    try { await env.DB.prepare("UPDATE messages SET media_id=json_extract(media,'$.id') WHERE media IS NOT NULL AND media_id IS NULL").run(); } catch (e) { console.error('media_id fill failed ' + e); }
  }
  try { await env.DB.prepare("INSERT OR REPLACE INTO settings(k,v) VALUES('schema_v',?1)").bind(SCHEMA_V).run(); } catch (e) { console.error('marker failed ' + e); }
  schemaOk = true;
}

/* Retries short D1 hiccups so one slow moment does not become a wave of 500 errors. */
const RETRY_ANY = /overloaded|queued too long|busy|locked|temporar|try again|unavailable|reset because/i;
const RETRY_READ = /network|timeout|timed out|connection|internal error|storage operation/i;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function withRetry(fn, write) {
  let last;
  for (let i = 0; i < 3; i++) {
    try { return await fn(); } catch (e) {
      last = e; const m = String(e && e.message || e);
      if (/UNIQUE|constraint|no such|has no column|exceeded/i.test(m)) throw e;
      if (!(RETRY_ANY.test(m) || (!write && RETRY_READ.test(m)))) throw e;
      await sleep(80 * (i + 1) * (i + 1));
    }
  }
  throw last;
}
function wrapDB(db) {
  return {
    prepare(sql) {
      const st = db.prepare(sql); let args = [];
      const bound = () => (args.length ? st.bind(...args) : st);
      const p = { sql, bind(...a) { args = a; return p; }, _st: bound,
        first: (...x) => withRetry(() => bound().first(...x), false), all: () => withRetry(() => bound().all(), false), run: () => withRetry(() => bound().run(), true) };
      return p;
    },
    batch(list) { return withRetry(() => db.batch(list.map((s) => (s._st ? s._st() : s))), true); }
  };
}

class HttpError extends Error { constructor(status, code, extra) { super(code); this.status = status; this.code = code; this.extra = extra; } }
const isDbErr = (e) => /D1_|SQLITE|no such (table|column)|has no column|constraint failed|database/i.test(String(e && e.message || e));

export default {
  async fetch(req, rawEnv, ctx) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const env = { DB: rawEnv.DB ? wrapDB(rawEnv.DB) : null, HUB: rawEnv.HUB, R2: rawEnv.R2 || null, KV: rawEnv.KV || null, ctx };
    try {
      if (!env.DB) return err('server_error', 500, { detail: 'The D1 binding named DB is missing on this Worker.' });
      await ensureSchema(env, needRepair); needRepair = false;
      return await route(req, env);
    } catch (e) {
      if (e instanceof HttpError) return err(e.code, e.status, e.extra);
      const detail = String(e && e.message || e).slice(0, 300);
      console.error('request failed: ' + req.method + ' ' + new URL(req.url).pathname + ' :: ' + (e && e.stack || e));
      if (/exceeded|free tier|quota|daily|limit/i.test(detail) && isDbErr(e)) return err('quota', 503, { detail, quota: true });
      if (isDbErr(e)) { needRepair = /no such (table|column)|has no column/i.test(detail); return err('db_error', 503, { detail }); }
      return err('server_error', 500, { detail });
    }
  }
};

async function body(req) { try { return await req.json(); } catch (e) { return {}; } }
async function newSession(env, uid, req) {
  const tok = rid(32);
  const ua = String((req && req.headers.get('user-agent')) || '').slice(0, 140);
  const t = Date.now();
  await env.DB.batch([
    env.DB.prepare('DELETE FROM sessions WHERE user_id=?1 AND COALESCE(last_used,created_at)<?2').bind(uid, t - SESSION_TTL),
    env.DB.prepare('INSERT INTO sessions(token_hash,user_id,created_at,ua,last_used) VALUES(?1,?2,?3,?4,?3)').bind(await sha(tok), uid, t, ua)]);
  return tok;
}
/* sessions seen in the last seconds: sending a message, typing and reacting skip the database lookup for them */
const AUTH_CACHE = new Map();
const FAST_PATH = /^\/api\/(chats\/[^/]+\/(messages|typing)|messages\/[^/]+\/react)$/;
async function auth(env, req) {
  const m = /^Bearer (.+)$/.exec(req.headers.get('authorization') || '');
  if (!m) return null;
  const th = await sha(m[1]);
  const now = Date.now();
  if (req.method === 'POST') {
    const hit = AUTH_CACHE.get(th);
    if (hit && hit.exp > now) { let p = ''; try { p = new URL(req.url).pathname; } catch (e) { /* ignore */ } if (FAST_PATH.test(p)) return Object.assign({}, hit.u); }
  }
  const u = await env.DB.prepare('SELECT ' + UCU + ' FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?1').bind(th).first();
  if (!u) { AUTH_CACHE.delete(th); return null; }
  u._th = th;
  if (AUTH_CACHE.size > 400) AUTH_CACHE.clear();
  AUTH_CACHE.set(th, { u: Object.assign({}, u), exp: now + 15000 });
  const t = Date.now();
  if ((u.last_seen || 0) < t - 300000) {
    try {
      await env.DB.prepare('UPDATE users SET last_seen=?1 WHERE id=?2').bind(t, u.id).run();
      u.last_seen = t;
    } catch (e) { console.error('last_seen update failed ' + e); }
  }
  return u;
}
async function limited(env, k, max = 8) {
  try {
    const r = await env.DB.prepare('SELECT n,ts FROM attempts WHERE k=?1').bind(k).first();
    (env._att = env._att || {})[k] = !!r;
    return !!(r && r.ts > Date.now() - 900000 && r.n >= max);
  } catch (e) { return false; }
}
async function failed(env, k) {
  const t = Date.now();
  try {
    await env.DB.prepare('INSERT INTO attempts(k,n,ts) VALUES(?1,1,?2) ON CONFLICT(k) DO UPDATE SET n=CASE WHEN ts<?3 THEN 1 ELSE n+1 END, ts=?2').bind(k, t, t - 900000).run();
  } catch (e) { console.error('attempt log failed ' + e); }
}
const cleared = async (env, k) => { if (env._att && env._att[k] === false) return; try { await env.DB.prepare('DELETE FROM attempts WHERE k=?1').bind(k).run(); } catch (e) { /* ignore */ } };
const bumpSql = 'UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id IN (SELECT user_id FROM chat_members WHERE chat_id=?2 AND gone=0)';

/* ---- realtime push through the Hub Durable Object (optional) ---- */
function ping(env, ids, msg) {
  ids = [...new Set(ids.filter(Boolean))];
  if (!env.HUB || !ids.length) return;
  try {
    const p = env.HUB.get(env.HUB.idFromName('main')).fetch('https://hub/notify', { method: 'POST', body: JSON.stringify({ ids, msg: msg || '{"k":"v"}' }) }).catch(() => {});
    if (env.ctx && env.ctx.waitUntil) env.ctx.waitUntil(p);
  } catch (e) { /* ignore */ }
}
async function pingChat(env, chatId, msg) {
  if (!env.HUB) return;
  try {
    const r = await env.DB.prepare('SELECT user_id FROM chat_members WHERE chat_id=?1 AND gone=0').bind(chatId).all();
    ping(env, r.results.map((x) => x.user_id), msg);
  } catch (e) { /* ignore */ }
}

async function route(req, env) {
  const url = new URL(req.url);
  const M = req.method;
  const P = url.pathname.split('/').filter(Boolean);
  if (P[0] !== 'api') return new Response('calc-chat ok', { headers: CORS });
  const A = P[1];
  const t = Date.now();

  if (A === 'ping') {
    const o = await env.DB.prepare("SELECT 1 x FROM users WHERE role='owner' LIMIT 1").first();
    return J({ ok: true, owner: !!o, push: !!env.HUB, v: '2.3', store: blobKind(env), chunk: CHUNK_BLOB });
  }
  if (A === 'health') return await health(env, url.searchParams.get('counts') === '1');
  if (A === 'salt' && M === 'GET') {
    const un = String(url.searchParams.get('username') || '').trim().toLowerCase();
    const r = un ? await env.DB.prepare('SELECT kdf_salt FROM users WHERE username=?1').bind(un).first() : null;
    return J({ ks: r && r.kdf_salt ? r.kdf_salt : (await sha('fake-salt:' + un)).slice(0, 32) });
  }
  if (A === 'ws') return await wsRoute(req, env);
  if (A === 'register' && M === 'POST') return await register(env, await body(req), t, req);
  if (A === 'login' && M === 'POST') return await login(env, await body(req), t, req);
  if (A === 'recover' && P[2] === 'start' && M === 'POST') return await recoverStart(env, await body(req), t);
  if (A === 'recover' && P[2] === 'finish' && M === 'POST') return await recoverFinish(env, await body(req), t);

  const u = await auth(env, req);
  if (!u) return err('unauthorized', 401);
  const acc = accessOf(u, t);
  const b = (M === 'GET' || M === 'DELETE') ? {} : (A === 'media' && M === 'PUT' ? {} : await body(req));

  if (A === 'me') return J({ user: userOut(u, t), key_blob: u.key_blob || null, settings: await settings(env), now: t });
  if (A === 'logout') {
    await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?1').bind(u._th).run();
    return J({ ok: true });
  }
  if (A === 'password' && M === 'POST') return await changePw(env, u, b, 'pass');
  if (A === 'recovery' && M === 'POST') return await changePw(env, u, b, 'rec');
  if (A === 'auth' && P[2] === 'upgrade' && M === 'POST') return await upgrade(env, u, b, t);
  if (A === 'lock' && P[2] === 'reset' && M === 'POST') {
    if ((u.auth_v | 0) !== 1) return err('upgrade_required', 409);
    const key = 'lockrst:' + u.id;
    if (await limited(env, key)) return err('too_many', 429);
    const cur = String(b.password || '');
    if (!isHex(cur) || !eq(u.pass_hash, await hashD(cur, u.pass_salt))) { await failed(env, key); return err('bad_login', 401); }
    await cleared(env, key);
    await env.DB.prepare('UPDATE users SET lock_hash=NULL, lock_salt=NULL, lock_hidden=0 WHERE id=?1').bind(u.id).run();
    return J({ ok: true });
  }
  if (A === 'lock' && M === 'POST') {
    await env.DB.prepare('UPDATE users SET lock_hash=COALESCE(?1,lock_hash), lock_salt=COALESCE(?2,lock_salt), lock_hidden=COALESCE(?3,lock_hidden) WHERE id=?4')
      .bind(b.hash || null, b.salt || null, b.hidden === undefined ? null : (b.hidden ? 1 : 0), u.id).run();
    return J({ ok: true });
  }
  if (A === 'privacy' && M === 'POST') {
    const f = (x) => (x === undefined ? null : (x ? 1 : 0));
    await env.DB.prepare('UPDATE users SET show_seen=COALESCE(?1,show_seen), show_read=COALESCE(?2,show_read), show_typing=COALESCE(?3,show_typing) WHERE id=?4')
      .bind(f(b.show_seen), f(b.show_read), f(b.show_typing), u.id).run();
    return J({ ok: true });
  }
  if (A === 'sessions') return await sessionsApi(env, u, P, M, b);
  if (A === 'pubkeys' && M === 'GET') {
    const ids = String(url.searchParams.get('ids') || '').split(',').filter((x) => /^[0-9a-f]{8,32}$/.test(x)).slice(0, 80);
    if (!ids.length) return J({ keys: {} });
    const r = await env.DB.prepare('SELECT id,pubkey,avatar_ver FROM users WHERE id IN (' + inList(ids) + ')').bind(...ids).all();
    const keys = {};
    for (const x of r.results) keys[x.id] = { pk: x.pubkey || '', av: x.avatar_ver || 0 };
    return J({ keys });
  }
  if (A === 'avatar' && P[2] && M === 'GET') return await avatarGet(env, P[2]);
  if (A === 'profile' && M === 'PATCH') return await profile(env, u, b, t);
  if (A === 'redeem' && M === 'POST') return await redeem(env, u, b, t);
  if (A === 'owner-chat') return await ownerChat(env, u, M, b, t);

  if (A === 'owner') {
    if (u.role !== 'owner') return err('forbidden', 403);
    return await ownerApi(env, u, P, M, b, t);
  }
  if (acc !== 'ok') return err(acc, 403);

  if (A === 'sync') return await sync(env, u, url);
  if (A === 'users' && P[2] && M === 'GET') return await userInfo(env, u, P[2]);
  if (A === 'contacts') return await contactsApi(env, u, P, M, b, t);
  if (A === 'lookup' && M === 'GET') {
    const x = await findUser(env, url.searchParams.get('q'), t);
    if (!x || x.id === u.id) return err('user_not_found', 404);
    return J({ user: uBrief(x) });
  }
  if (A === 'blocks' && M === 'POST') {
    if (!b.user_id || b.user_id === u.id) return err('bad_request');
    if (b.block) await env.DB.prepare('INSERT OR IGNORE INTO blocks VALUES(?1,?2)').bind(u.id, b.user_id).run();
    else await env.DB.prepare('DELETE FROM blocks WHERE blocker_id=?1 AND blocked_id=?2').bind(u.id, b.user_id).run();
    await env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, u.id).run();
    return J({ ok: true });
  }
  if (A === 'chats') return await chatsApi(env, u, P, M, b, url, t);
  if (A === 'messages' && P[2]) return await messageApi(env, u, P, M, b, t);
  if (A === 'media') return await mediaApi(env, u, P, M, req, b, t);
  return err('not_found', 404);
}

async function health(env, counts) {
  const out = { ok: true, schema_v: SCHEMA_V, push: !!env.HUB, store: blobKind(env), tables: {}, now: Date.now() };
  for (const n of Object.keys(COLS)) out.tables[n] = {};
  try { await env.DB.prepare('SELECT 1 x').first(); } catch (e) { out.ok = false; out.db = String(e && e.message || e).slice(0, 160); }
  if (counts) {
    /* counting rows reads every row of every table: only on request */
    for (const n of Object.keys(COLS)) {
      try { const r = await env.DB.prepare('SELECT COUNT(*) c FROM ' + n).first(); out.tables[n].rows = r.c; } catch (e) { out.tables[n].error = String(e && e.message || e).slice(0, 160); out.ok = false; }
    }
  }
  try {
    const info = await env.DB.batch(Object.keys(COLS).map((n) => env.DB.prepare('PRAGMA table_info(' + n + ')')));
    Object.keys(COLS).forEach((n, i) => {
      const have = new Set(((info[i] && info[i].results) || []).map((r) => r.name));
      if (!have.size) { out.tables[n].error = 'table missing'; out.ok = false; needRepair = true; return; }
      const miss = COLS[n].map((c) => c[0]).filter((c) => !have.has(c));
      if (miss.length) { out.tables[n].missing = miss; out.ok = false; needRepair = true; }
    });
  } catch (e) { out.pragma = String(e && e.message || e).slice(0, 160); }
  try { const h = await hashD('test', 'salt'); out.hash_ok = h.length === 64; } catch (e) { out.hash_ok = false; out.hash_error = String(e).slice(0, 160); out.ok = false; }
  return J(out, out.ok ? 200 : 503);
}

async function wsRoute(req, env) {
  if (req.headers.get('Upgrade') !== 'websocket') return err('bad_request', 426);
  if (!env.HUB) return err('not_found', 404);
  const proto = (req.headers.get('Sec-WebSocket-Protocol') || '').split(',').map((s) => s.trim()).find((s) => s.startsWith('bearer.'));
  if (!proto) return err('unauthorized', 401);
  const row = await env.DB.prepare('SELECT user_id FROM sessions WHERE token_hash=?1').bind(await sha(proto.slice(7))).first();
  if (!row) return err('unauthorized', 401);
  const h = new Headers(req.headers); h.set('x-uid', row.user_id);
  return env.HUB.get(env.HUB.idFromName('main')).fetch(new Request(req, { headers: h }));
}

let settingsC = { v: null, at: 0 };
async function settings(env) {
  if (settingsC.v && Date.now() - settingsC.at < 60000) return settingsC.v;
  try {
    const r = await env.DB.prepare("SELECT v FROM settings WHERE k='allow_screens'").first();
    settingsC = { v: { allow_screens: !!(r && r.v === '1') }, at: Date.now() };
    return settingsC.v;
  } catch (e) { console.error('settings read failed ' + e); return { allow_screens: false }; }
}

async function register(env, b, t, req) {
  const name = normName(b.full_name), phone = normPhone(b.phone);
  const un = String(b.username || '').trim().toLowerCase();
  if (name.split(' ').length < 4 || name.length > 80 || !/^[\p{L}\p{M}' .-]+$/u.test(name)) return err('bad_name');
  if (!phone) return err('bad_phone');
  if (!/^[a-z0-9_.]{3,24}$/.test(un)) return err('bad_username');
  const derived = isHex(b.password);
  if (derived) {
    if (!isHex(b.recovery) || !okPub(b.pubkey) || !okBlob(b.key_blob) || !okBlob(b.key_blob_rec) || !okSalt(b.kdf_salt)) return err('bad_request');
  } else {
    if (!strong(b.password)) return err('weak_password');
    if (!b.recovery || String(b.recovery).length < 4 || String(b.recovery).length > 100) return err('weak_recovery');
  }
  const dupP = await env.DB.prepare('SELECT 1 x FROM users WHERE phone=?1').bind(phone).first();
  if (dupP) return err('phone_taken', 409);
  const dupU = await env.DB.prepare('SELECT 1 x FROM users WHERE username=?1').bind(un).first();
  if (dupU) return err('username_taken', 409);
  const ps = rid(8), rs = rid(8), id = rid(8);
  try {
    await env.DB.prepare(
      "INSERT INTO users(id,full_name,name_key,phone,username,pass_hash,pass_salt,rec_hash,rec_salt,role,status,created_at,last_seen,inbox_ver,pubkey,key_blob,key_blob_rec,auth_v,kdf_salt) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9," +
      "CASE WHEN NOT EXISTS (SELECT 1 FROM users) THEN 'owner' ELSE 'user' END," +
      "CASE WHEN NOT EXISTS (SELECT 1 FROM users) THEN 'active' ELSE 'pending' END,?10,?10,?10,?11,?12,?13,?14,?15)")
      .bind(id, name, nameKey(name), phone, un, derived ? await hashD(b.password, ps) : await hashPw(b.password, ps), ps,
        derived ? await hashD(String(b.recovery), rs) : await hashPw(String(b.recovery), rs), rs, t, derived ? b.pubkey : null, derived ? b.key_blob : null, derived ? b.key_blob_rec : null, derived ? 1 : 0, derived ? b.kdf_salt : null).run();
  } catch (e) {
    const m = String(e && e.message || e);
    if (/users\.phone/.test(m)) return err('phone_taken', 409);
    if (/users\.username/.test(m)) return err('username_taken', 409);
    throw e;
  }
  const u = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE id=?1').bind(id).first();
  return J({ token: await newSession(env, id, req), user: userOut(u, t), settings: await settings(env) });
}

async function login(env, b, t, req) {
  const un = String(b.username || '').trim().toLowerCase();
  const key = 'login:' + un;
  if (await limited(env, key)) return err('too_many', 429);
  const u = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE username=?1').bind(un).first();
  const idOk = !!(u && eq(u.name_key, nameKey(b.full_name)) && u.phone === normPhone(b.phone));
  let ok = false, upgrade = false;
  if (idOk) {
    const pw = String(b.password || '');
    const v = (u.auth_v | 0);
    if (isHex(pw) && v === 1) ok = eq(u.pass_hash, await hashD(pw, u.pass_salt));
    else if (!isHex(pw) && v === 0 && b.legacy) { ok = eq(u.pass_hash, await hashPw(pw, u.pass_salt)); upgrade = ok; }
    else if (isHex(pw) && v === 0) return err('bad_login', 401, { legacy: true });
  }
  if (!ok) { await failed(env, key); return err('bad_login', 401); }
  await cleared(env, key);
  return J({ token: await newSession(env, u.id, req), user: userOut(u, t), settings: await settings(env), key_blob: u.key_blob || null, upgrade });
}

async function recoverStart(env, b, t) {
  const un = String(b.username || '').trim().toLowerCase();
  const key = 'rec:' + un;
  if (await limited(env, key, 6)) return err('too_many', 429);
  const u = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE username=?1').bind(un).first();
  const idOk = !!(u && eq(u.name_key, nameKey(b.full_name)) && u.phone === normPhone(b.phone));
  const rc = String(b.recovery || '');
  let ok = false, legacy = false;
  if (idOk) {
    const v = (u.auth_v | 0);
    if (isHex(rc) && v === 1) ok = eq(u.rec_hash, await hashD(rc, u.rec_salt));
    else if (!isHex(rc) && v === 0) { ok = eq(u.rec_hash, await hashPw(rc, u.rec_salt)); legacy = ok; }
    else if (isHex(rc) && v === 0) return err('bad_recovery', 401, { legacy: true });
  }
  if (!ok) { await failed(env, key); return err('bad_recovery', 401); }
  await cleared(env, key);
  const ticket = rid(16);
  await env.DB.prepare('INSERT OR REPLACE INTO settings(k,v) VALUES(?1,?2)').bind('tk:' + await sha(ticket), u.id + '|' + (t + 600000)).run();
  return J({ ticket, legacy, key_blob_rec: u.key_blob_rec || null });
}

async function recoverFinish(env, b, t) {
  const k = 'tk:' + await sha(String(b.ticket || ''));
  const row = await env.DB.prepare('SELECT v FROM settings WHERE k=?1').bind(k).first();
  if (!row) return err('bad_ticket');
  await env.DB.prepare('DELETE FROM settings WHERE k=?1').bind(k).run();
  const [uid, exp] = String(row.v).split('|');
  if (+exp < t) return err('bad_ticket');
  const u = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE id=?1').bind(uid).first();
  if (!u || !isHex(b.password)) return err('weak_password');
  const ps = rid(8);
  const ph = await hashD(b.password, ps);
  if ((u.auth_v | 0) === 1) {
    if (!okBlob(b.key_blob)) return err('bad_request');
    await env.DB.prepare('UPDATE users SET pass_hash=?1, pass_salt=?2, key_blob=?3 WHERE id=?4').bind(ph, ps, b.key_blob, u.id).run();
  } else {
    if (!isHex(b.recovery) || !okPub(b.pubkey) || !okBlob(b.key_blob) || !okBlob(b.key_blob_rec) || !okSalt(b.kdf_salt)) return err('bad_request');
    const rs = rid(8);
    await env.DB.prepare('UPDATE users SET pass_hash=?1, pass_salt=?2, rec_hash=?3, rec_salt=?4, pubkey=?5, key_blob=?6, key_blob_rec=?7, auth_v=1, kdf_salt=?9 WHERE id=?8')
      .bind(ph, ps, await hashD(b.recovery, rs), rs, b.pubkey, b.key_blob, b.key_blob_rec, u.id, b.kdf_salt).run();
  }
  await env.DB.prepare('DELETE FROM sessions WHERE user_id=?1').bind(u.id).run();
  return J({ ok: true });
}

async function changePw(env, u, b, which) {
  if ((u.auth_v | 0) !== 1) return err('upgrade_required', 409);
  const key = 'chg:' + u.id;
  if (await limited(env, key)) return err('too_many', 429);
  const cur = String(b.current || '');
  if (!isHex(cur) || !eq(u.pass_hash, await hashD(cur, u.pass_salt))) { await failed(env, key); return err('bad_login', 401); }
  await cleared(env, key);
  const s = rid(8);
  if (which === 'pass') {
    if (!isHex(b.value) || !okBlob(b.key_blob)) return err('bad_request');
    await env.DB.batch([
      env.DB.prepare('UPDATE users SET pass_hash=?1, pass_salt=?2, key_blob=?3 WHERE id=?4').bind(await hashD(b.value, s), s, b.key_blob, u.id),
      env.DB.prepare('DELETE FROM sessions WHERE user_id=?1 AND token_hash!=?2').bind(u.id, u._th)]);
  } else {
    if (!isHex(b.value) || !okBlob(b.key_blob_rec)) return err('bad_request');
    await env.DB.prepare('UPDATE users SET rec_hash=?1, rec_salt=?2, key_blob_rec=?3 WHERE id=?4').bind(await hashD(b.value, s), s, b.key_blob_rec, u.id).run();
  }
  return J({ ok: true });
}

async function upgrade(env, u, b, t) {
  if ((u.auth_v | 0) === 1) return err('bad_request');
  const key = 'up:' + u.id;
  if (await limited(env, key)) return err('too_many', 429);
  /* two requests, one slow password check each: keeps every request far below the free CPU limit */
  if (b.step === 1) {
    if (!eq(u.pass_hash, await hashPw(String(b.current || ''), u.pass_salt))) { await failed(env, key); return err('bad_login', 401); }
    const ticket = rid(16);
    await env.DB.prepare('INSERT OR REPLACE INTO settings(k,v) VALUES(?1,?2)').bind('up:' + await sha(ticket), u.id + '|' + (t + 600000)).run();
    return J({ ticket });
  }
  const tk = 'up:' + await sha(String(b.ticket || ''));
  const row = await env.DB.prepare('SELECT v FROM settings WHERE k=?1').bind(tk).first();
  if (!row) return err('bad_ticket');
  const [tuid, texp] = String(row.v).split('|');
  if (tuid !== u.id || +texp < t) return err('bad_ticket');
  if (!eq(u.rec_hash, await hashPw(String(b.rec_current || ''), u.rec_salt))) { await failed(env, key); return err('bad_login', 401); }
  if (!isHex(b.password) || !isHex(b.recovery) || !okPub(b.pubkey) || !okBlob(b.key_blob) || !okBlob(b.key_blob_rec) || !okSalt(b.kdf_salt)) return err('bad_request');
  await env.DB.prepare('DELETE FROM settings WHERE k=?1').bind(tk).run();
  await cleared(env, key);
  const ps = rid(8), rs = rid(8);
  await env.DB.prepare('UPDATE users SET pass_hash=?1, pass_salt=?2, rec_hash=?3, rec_salt=?4, pubkey=?5, key_blob=?6, key_blob_rec=?7, auth_v=1, kdf_salt=?9 WHERE id=?8')
    .bind(await hashD(b.password, ps), ps, await hashD(b.recovery, rs), rs, b.pubkey, b.key_blob, b.key_blob_rec, u.id, b.kdf_salt).run();
  const n = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE id=?1').bind(u.id).first();
  return J({ user: userOut(n, t) });
}

async function profile(env, u, b, t) {
  const sets = [], vals = [];
  const add = (col, v) => { vals.push(v); sets.push(col + '=?' + vals.length); };
  if (b.full_name !== undefined) {
    const name = normName(b.full_name);
    if (name.split(' ').length < 4 || name.length > 80 || !/^[\p{L}\p{M}' .-]+$/u.test(name)) return err('bad_name');
    add('full_name', name); add('name_key', nameKey(name));
  }
  if (b.username !== undefined) {
    const un = String(b.username).trim().toLowerCase();
    if (!/^[a-z0-9_.]{3,24}$/.test(un)) return err('bad_username');
    const dup = await env.DB.prepare('SELECT 1 x FROM users WHERE username=?1 AND id!=?2').bind(un, u.id).first();
    if (dup) return err('username_taken', 409);
    add('username', un);
  }
  if (b.about !== undefined) add('about', String(b.about).slice(0, 140));
  if (b.avatar !== undefined) {
    if (b.avatar === null || b.avatar === '') { add('avatar', null); add('avatar_ver', t); await blobDel(env, ['av/' + u.id]); }
    else {
      if (typeof b.avatar !== 'string' || b.avatar.length > 90000 || !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(b.avatar)) return err('bad_request');
      const x = parseDataUrl(b.avatar);
      if (blobKind(env) !== 'none' && x) { await blobPut(env, 'av/' + u.id, b64ToBytes(x.b64), { mime: x.mime }); add('avatar', 'blob'); }
      else add('avatar', b.avatar);
      add('avatar_ver', t);
    }
  }
  if (!sets.length) return err('bad_request');
  vals.push(u.id);
  await env.DB.prepare('UPDATE users SET ' + sets.join(', ') + ' WHERE id=?' + vals.length).bind(...vals).run();
  await env.DB.batch([
    env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id IN (SELECT chat_id FROM chat_members WHERE user_id=?2)').bind(t, u.id),
    env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2 OR id IN (SELECT user_id FROM chat_members WHERE gone=0 AND chat_id IN (SELECT chat_id FROM chat_members WHERE user_id=?2))').bind(t, u.id)]);
  if (env.HUB) {
    const r = await env.DB.prepare('SELECT DISTINCT user_id FROM chat_members WHERE chat_id IN (SELECT chat_id FROM chat_members WHERE user_id=?1)').bind(u.id).all();
    ping(env, r.results.map((x) => x.user_id));
  }
  const n = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE id=?1').bind(u.id).first();
  return J({ user: userOut(n, t) });
}

async function avatarGet(env, id) {
  const hd = (mime) => ({ ...CORS, 'content-type': mime, 'cache-control': 'private, max-age=31536000, immutable' });
  const o = await blobGet(env, 'av/' + id);
  if (o) return new Response(o.body, { headers: hd(o.meta.mime || 'image/jpeg') });
  /* an old picture still stored as text in D1: serve it and move it to file storage */
  const r = await env.DB.prepare('SELECT avatar FROM users WHERE id=?1').bind(id).first();
  const x = r && r.avatar ? parseDataUrl(r.avatar) : null;
  if (!x) return err('not_found', 404);
  const u8 = b64ToBytes(x.b64);
  if (blobKind(env) !== 'none') {
    try { await blobPut(env, 'av/' + id, u8, { mime: x.mime }); await env.DB.prepare("UPDATE users SET avatar='blob' WHERE id=?1").bind(id).run(); } catch (e) { console.error('avatar move failed ' + e); }
  }
  return new Response(u8, { headers: hd(x.mime) });
}

async function sessionsApi(env, u, P, M, b) {
  if (M === 'GET') {
    const r = await env.DB.prepare('SELECT token_hash,ua,created_at,last_used FROM sessions WHERE user_id=?1 ORDER BY last_used DESC').bind(u.id).all();
    return J({ sessions: r.results.map((s) => ({ id: s.token_hash.slice(0, 12), ua: s.ua || '', created_at: s.created_at, last_used: s.last_used || s.created_at, current: s.token_hash === u._th })) });
  }
  if (M === 'POST') {
    if (b.others) await env.DB.prepare('DELETE FROM sessions WHERE user_id=?1 AND token_hash!=?2').bind(u.id, u._th).run();
    else if (b.id) await env.DB.prepare('DELETE FROM sessions WHERE user_id=?1 AND substr(token_hash,1,12)=?2 AND token_hash!=?3').bind(u.id, String(b.id), u._th).run();
    else return err('bad_request');
    return J({ ok: true });
  }
  return err('not_found', 404);
}

async function contactsApi(env, u, P, M, b, t) {
  const id = P[2];
  if (!id && M === 'GET') {
    const r = await env.DB.prepare('SELECT c.contact_id id, c.name, x.full_name, x.username, x.phone, x.avatar_ver av, x.pubkey pk FROM contacts c JOIN users x ON x.id=c.contact_id WHERE c.owner_id=?1').bind(u.id).all();
    return J({ contacts: r.results });
  }
  if (!id && M === 'POST') {
    let x = null;
    if (b.user_id) x = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE id=?1').bind(String(b.user_id)).first();
    else x = await findUser(env, b.query, t);
    if (!x || x.id === u.id) return err('user_not_found', 404);
    if (accessOf(x, t) !== 'ok' && u.role !== 'owner') return err('user_not_found', 404);
    const name = normName(b.name || x.full_name).slice(0, 60) || x.full_name;
    await env.DB.prepare('INSERT OR REPLACE INTO contacts(owner_id,contact_id,name) VALUES(?1,?2,?3)').bind(u.id, x.id, name).run();
    return J({ contact: { id: x.id, name, full_name: x.full_name, username: x.username, phone: x.phone, av: x.avatar_ver || 0, pk: x.pubkey || '' } });
  }
  if (id && M === 'PATCH') {
    const name = normName(b.name).slice(0, 60);
    if (!name) return err('bad_name');
    await env.DB.prepare('UPDATE contacts SET name=?1 WHERE owner_id=?2 AND contact_id=?3').bind(name, u.id, id).run();
    return J({ ok: true });
  }
  if (id && M === 'DELETE') {
    await env.DB.prepare('DELETE FROM contacts WHERE owner_id=?1 AND contact_id=?2').bind(u.id, id).run();
    return J({ ok: true });
  }
  return err('not_found', 404);
}

async function touchOwnerChat(env, userId, t) {
  try {
    const o = await env.DB.prepare("SELECT id FROM users WHERE role='owner' LIMIT 1").first();
    if (!o) return;
    await env.DB.batch([
      env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE dm_key=?2').bind(t, [o.id, userId].sort().join(':')),
      env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, o.id)]);
    ping(env, [o.id, userId]);
  } catch (e) { console.error('touchOwnerChat ' + e); }
}

async function dmChat(env, a, b, t, quiet) {
  const key = [a, b].sort().join(':');
  const bump = () => env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, a).run();
  let c = await env.DB.prepare('SELECT id FROM chats WHERE dm_key=?1').bind(key).first();
  if (c) {
    const up = await env.DB.prepare('UPDATE chat_members SET gone=0, updated_at=?1 WHERE chat_id=?2 AND user_id=?3 AND gone=1').bind(t, c.id, a).run();
    if (!quiet || (up.meta && up.meta.changes > 0)) await bump();
    return c.id;
  }
  const id = rid(10);
  await env.DB.batch([
    env.DB.prepare("INSERT OR IGNORE INTO chats(id,type,dm_key,created_by,created_at,updated_at) VALUES(?1,'dm',?2,?3,?4,?4)").bind(id, key, a, t),
    env.DB.prepare('INSERT OR IGNORE INTO chat_members(chat_id,user_id,joined_at,updated_at,read_upto) SELECT ?1,?2,?3,?3,?3-1 WHERE EXISTS(SELECT 1 FROM chats WHERE id=?1)').bind(id, a, t),
    env.DB.prepare('INSERT OR IGNORE INTO chat_members(chat_id,user_id,joined_at,updated_at,read_upto) SELECT ?1,?2,?3,?3,?3-1 WHERE EXISTS(SELECT 1 FROM chats WHERE id=?1)').bind(id, b, t)]);
  await bump();
  c = await env.DB.prepare('SELECT id FROM chats WHERE dm_key=?1').bind(key).first();
  return c.id;
}

async function addMessage(env, chatId, sid, b, t) {
  const type = String(b.type || 'text');
  if (!['text', 'image', 'video', 'audio', 'file', 'sys'].includes(type)) return null;
  const id = /^[A-Za-z0-9_-]{8,40}$/.test(b.id || '') ? b.id : rid(12);
  const encFlag = b.enc && type !== 'sys' ? 1 : 0;
  const text = String(b.body || '').slice(0, encFlag ? 150000 : 4000);
  if (type === 'text' && !encFlag && !text.trim()) return null;
  if (encFlag && !text) return null;
  let media = null, mediaId = null;
  if (b.media && type !== 'text' && type !== 'sys') {
    const m = b.media;
    const ex = await env.DB.prepare('SELECT 1 x FROM media WHERE id=?1').bind(String(m.id)).first();
    if (!ex) return null;
    mediaId = String(m.id);
    media = JSON.stringify({
      id: String(m.id), mime: String(m.mime || '').slice(0, 80), size: +m.size || 0, name: String(m.name || '').slice(0, 120),
      chunks: +m.chunks || 1, dur: encFlag ? 0 : (+m.dur || 0), w: encFlag ? 0 : (+m.w || 0), h: encFlag ? 0 : (+m.h || 0)
    });
  }
  let reply = null;
  if (b.reply_to && !encFlag) {
    const r = await env.DB.prepare('SELECT id,sender_id,type,body FROM messages WHERE id=?1 AND chat_id=?2').bind(String(b.reply_to), chatId).first();
    if (r && !r.enc) reply = JSON.stringify({ id: r.id, sid: r.sender_id, type: r.type, body: String(r.body || '').slice(0, 120) });
  }
  const res = await env.DB.batch([
    env.DB.prepare('INSERT OR IGNORE INTO messages(id,chat_id,sender_id,type,body,media,reply,created_at,updated_at,enc,media_id) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?8,?9,?10)')
      .bind(id, chatId, sid, type, text, media, reply, t, encFlag, mediaId),
    env.DB.prepare('INSERT OR IGNORE INTO receipts(message_id,user_id,updated_at) SELECT ?1,user_id,?2 FROM chat_members WHERE chat_id=?3 AND gone=0 AND user_id!=?4')
      .bind(id, t, chatId, sid),
    env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, chatId),
    env.DB.prepare(bumpSql).bind(t, chatId),
    env.DB.prepare('SELECT user_id FROM chat_members WHERE chat_id=?1 AND gone=0').bind(chatId)]);
  const fresh = !!(res[0] && res[0].meta && res[0].meta.changes === 1);
  const ids = ((res[4] && res[4].results) || []).map((x) => x.user_id);
  const row = fresh
    ? { id, chat_id: chatId, sender_id: sid, type, body: text, media, reply, created_at: t, updated_at: t, enc: encFlag, media_id: mediaId }
    : await env.DB.prepare('SELECT * FROM messages WHERE id=?1').bind(id).first();
  if (env.HUB && row) {
    /* the encrypted message itself goes to the other members right now: their phones show it and save it without asking the server again */
    let msg = '{"k":"v"}';
    if (fresh) { try { const s = JSON.stringify({ k: 'm', m: msgOut(row) }); if (s.length < 90000) msg = s; } catch (e) { /* only a ping */ } }
    ping(env, ids.filter((x) => x !== sid), msg);
    ping(env, [sid], '{"k":"v"}');
  }
  return row;
}
function pingChatBg(env, chatId, msg) {
  if (!env.HUB) return;
  const p = pingChat(env, chatId, msg);
  if (env.ctx && env.ctx.waitUntil) env.ctx.waitUntil(p);
}
const sysMsg = (env, chatId, actor, obj, t) => addMessage(env, chatId, actor, { type: 'sys', body: JSON.stringify(obj) }, t);

async function userInfo(env, me, id) {
  const u = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE id=?1').bind(id).first();
  if (!u) return err('not_found', 404);
  const [bl, gr] = await env.DB.batch([
    env.DB.prepare('SELECT 1 x FROM blocks WHERE blocker_id=?1 AND blocked_id=?2').bind(me.id, id),
    env.DB.prepare("SELECT c.id,c.name FROM chats c JOIN chat_members a ON a.chat_id=c.id AND a.user_id=?1 AND a.gone=0 JOIN chat_members b ON b.chat_id=c.id AND b.user_id=?2 AND b.gone=0 WHERE c.type='group'").bind(me.id, id)]);
  return J({
    id: u.id, full_name: u.full_name, username: u.username, phone: u.phone, role: u.role, about: u.about || '', av: u.avatar_ver || 0, pk: u.pubkey || '',
    last_seen: u.show_seen === 0 ? 0 : u.last_seen, blocked: bl.results.length > 0, groups: gr.results
  });
}

/* Durable Object: keeps the open WebSockets and pushes small "something changed" pings. */
export class Hub {
  constructor(state, env) { this.state = state; this.env = env; }
  att(ws) { try { return ws.deserializeAttachment() || {}; } catch (e) { return {}; } }
  uid(ws) { try { return this.state.getTags(ws)[0] || ''; } catch (e) { return ''; } }
  isOn(a) { return !!(a && a.fg && a.show); }
  online(uid, skip) {
    for (const s of this.state.getWebSockets(uid)) { if (s !== skip && this.isOn(this.att(s))) return true; }
    return false;
  }
  /* sockets allowed to see uid's status: they watch uid, and uid watches them back */
  watchers(uid, skip, wl) {
    const mine = new Set(wl || []);
    if (!wl) for (const s of this.state.getWebSockets(uid)) { if (s !== skip) for (const x of this.att(s).w || []) mine.add(x); }
    const out = [];
    for (const s of this.state.getWebSockets()) {
      if (s === skip) continue;
      const u = this.uid(s);
      if (u && u !== uid && mine.has(u) && (this.att(s).w || []).includes(uid)) out.push(s);
    }
    return out;
  }
  broadcast(uid, on, skip, wl) {
    const msg = JSON.stringify({ k: 'p', u: uid, o: on ? 1 : 0, t: Date.now() });
    for (const s of this.watchers(uid, skip, wl)) { try { s.send(msg); } catch (e) { /* closed */ } }
  }
  snapshot(ws) {
    const uid = this.uid(ws), on = [];
    for (const x of this.att(ws).w || []) {
      if (x === uid || !this.online(x)) continue;
      for (const s of this.state.getWebSockets(x)) { if ((this.att(s).w || []).includes(uid)) { on.push(x); break; } }
    }
    try { ws.send(JSON.stringify({ k: 'ps', l: on })); } catch (e) { /* closed */ }
  }
  seen(uid) {
    try { this.state.waitUntil(this.env.DB.prepare('UPDATE users SET last_seen=?1 WHERE id=?2').bind(Date.now(), uid).run().catch(() => {})); } catch (e) { /* ignore */ }
  }
  async arm() { try { if (!(await this.state.storage.getAlarm())) await this.state.storage.setAlarm(Date.now() + 20000); } catch (e) { /* ignore */ } }
  async fetch(req) {
    const url = new URL(req.url);
    if (url.pathname === '/ws') {
      if (req.headers.get('Upgrade') !== 'websocket') return new Response('expected websocket', { status: 426 });
      const uid = req.headers.get('x-uid') || '';
      const pair = new WebSocketPair();
      const client = pair[0], server = pair[1];
      this.state.acceptWebSocket(server, [uid]);
      try { server.serializeAttachment({ ts: Date.now(), fg: 0, show: 0, w: [] }); } catch (e) { /* ignore */ }
      await this.arm();
      return new Response(null, { status: 101, webSocket: client, headers: { 'Sec-WebSocket-Protocol': 'calc' } });
    }
    if (url.pathname === '/notify') {
      const j = await req.json();
      for (const id of j.ids || []) {
        for (const ws of this.state.getWebSockets(id)) { try { ws.send(j.msg || '{"k":"v"}'); } catch (e) { /* closed */ } }
      }
      return new Response('ok');
    }
    return new Response('not found', { status: 404 });
  }
  webSocketMessage(ws, m) {
    if (typeof m !== 'string') return;
    const a0 = this.att(ws);
    if (m === 'ping') { a0.ts = Date.now(); try { ws.serializeAttachment(a0); ws.send('pong'); } catch (e) { /* ignore */ } return; }
    let j; try { j = JSON.parse(m); } catch (e) { return; }
    if (!j || j.a !== 'p') return;
    const uid = this.uid(ws);
    if (!uid) return;
    const prev = this.online(uid);
    if (j.fg !== undefined) a0.fg = j.fg ? 1 : 0;
    if (j.show !== undefined) a0.show = j.show ? 1 : 0;
    if (Array.isArray(j.w)) a0.w = j.w.filter((x) => typeof x === 'string' && x.length < 40).slice(0, 300);
    a0.ts = Date.now();
    try { ws.serializeAttachment(a0); } catch (e) { /* ignore */ }
    const now = this.online(uid);
    if (prev !== now) { this.broadcast(uid, now); if (!now) this.seen(uid); }
    if (j.hello || Array.isArray(j.w)) this.snapshot(ws);
    this.arm();
  }
  closed(ws) {
    const uid = this.uid(ws);
    if (uid && this.isOn(this.att(ws)) && !this.online(uid, ws)) { this.broadcast(uid, false, ws, this.att(ws).w); this.seen(uid); }
  }
  webSocketClose(ws, code) { this.closed(ws); try { ws.close(code, 'bye'); } catch (e) { /* ignore */ } }
  webSocketError(ws) { this.closed(ws); try { ws.close(1011, 'error'); } catch (e) { /* ignore */ } }
  /* a phone that vanished without saying goodbye (no signal, battery out) is noticed within a minute */
  async alarm() {
    const now = Date.now(); let any = false;
    for (const s of this.state.getWebSockets()) {
      if (now - (this.att(s).ts || 0) > 50000) { this.closed(s); try { s.close(1001, 'timeout'); } catch (e) { /* ignore */ } } else any = true;
    }
    if (any) await this.arm();
  }
}

async function redeem(env, u, b, t) {
  const code = String(b.code || '').trim();
  if (u.role === 'owner' || u.status === 'blocked') return err('forbidden', 403);
  const key = 'code:' + u.id;
  if (await limited(env, key, 10)) return err('too_many', 429);
  const c = await env.DB.prepare('SELECT * FROM codes WHERE code=?1').bind(code).first();
  if (!c || c.status !== 'active' || (c.max_uses > 0 && c.uses >= c.max_uses)) {
    await failed(env, key); return err('bad_code', 400);
  }
  const used = await env.DB.prepare('SELECT 1 x FROM code_uses WHERE code=?1 AND user_id=?2').bind(code, u.id).first();
  if (used) return err('code_used', 400);
  const up = await env.DB.prepare("UPDATE codes SET uses=uses+1 WHERE code=?1 AND status='active' AND (max_uses=0 OR uses<max_uses)").bind(code).run();
  if (!up.meta || up.meta.changes !== 1) return err('bad_code', 400);
  const base = Math.max(t, u.expires_at || 0);
  const exp = c.permanent ? 0 : base + (DUR[c.duration] || DUR.month);
  await env.DB.batch([
    env.DB.prepare('INSERT OR IGNORE INTO code_uses VALUES(?1,?2,?3)').bind(code, u.id, t),
    env.DB.prepare("UPDATE users SET status='active', permanent=CASE WHEN ?1=1 THEN 1 ELSE permanent END, expires_at=CASE WHEN ?1=1 THEN expires_at ELSE ?2 END WHERE id=?3")
      .bind(c.permanent ? 1 : 0, exp, u.id)]);
  await cleared(env, key);
  await touchOwnerChat(env, u.id, t);
  const n = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE id=?1').bind(u.id).first();
  return J({ user: userOut(n, t) });
}

async function memberRow(env, chatId, uid) {
  return env.DB.prepare('SELECT * FROM chat_members WHERE chat_id=?1 AND user_id=?2 AND gone=0').bind(chatId, uid).first();
}
async function findUser(env, q, t) {
  q = String(q || '').trim().toLowerCase().replace(/^@/, '');
  if (!q) return null;
  const ph = normPhone(q);
  const u = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE username=?1 OR phone=?2').bind(q, ph || '-').first();
  if (!u || accessOf(u, t) !== 'ok') return null;
  return u;
}
const uBrief = (u) => ({ id: u.id, full_name: u.full_name, username: u.username });

async function sync(env, u, url) {
  const q = url.searchParams;
  const inc = q.has('since');
  const since = +q.get('since') || 0;
  const cur = +q.get('cur') || 0;
  const chatId = q.get('chat');
  const ver = u.inbox_ver || 0;
  const out = { ver, now: Date.now() };
  if (chatId) {
    const st = [], wantT = q.get('typ') !== '0', wantS = q.get('seen') !== '0';
    if (wantT) st.push(env.DB.prepare('SELECT x.full_name n FROM typing ty JOIN users x ON x.id=ty.user_id WHERE ty.chat_id=?1 AND ty.until>?2 AND ty.user_id!=?3 AND EXISTS(SELECT 1 FROM chat_members WHERE chat_id=?1 AND user_id=?3 AND gone=0)').bind(chatId, out.now, u.id));
    if (wantS) st.push(env.DB.prepare('SELECT x.id, CASE WHEN x.show_seen=0 THEN 0 ELSE x.last_seen END last_seen FROM chat_members cm JOIN users x ON x.id=cm.user_id WHERE cm.chat_id=?1 AND cm.gone=0 AND cm.user_id!=?2 AND EXISTS(SELECT 1 FROM chat_members WHERE chat_id=?1 AND user_id=?2 AND gone=0) LIMIT 3').bind(chatId, u.id));
    if (st.length) {
      const rs = await env.DB.batch(st); let i = 0;
      if (wantT) out.typing = rs[i++].results.map((r) => r.n);
      if (wantS) out.seen = rs[i++].results;
    }
  }
  if (inc && ver <= since) return J(out);
  /* the phone tells us when it last synced (cur): we only look at the window since then */
  const lb = inc ? Math.max(1, cur ? cur - LOOK : since - 3000) : 0;
  const chats = (await env.DB.prepare(
    "SELECT c.id,c.type,c.name,c.created_by,c.updated_at,me.role my_role,me.muted,me.locked,me.read_upto,me.gone,me.pinned,me.archived,COALESCE(me.clear_at,0) clr," +
    "(SELECT COUNT(*) FROM (SELECT 1 FROM messages m WHERE m.chat_id=c.id AND m.sender_id!=?1 AND m.deleted=0 AND m.type!='sys' AND m.created_at>me.read_upto AND m.created_at>COALESCE(me.clear_at,0) AND " + HID + " AND " + BLK + " LIMIT 100)) unread," +
    "(SELECT m.id FROM messages m WHERE m.chat_id=c.id AND m.created_at>COALESCE(me.clear_at,0) AND " + HID + " AND " + BLK + " ORDER BY m.created_at DESC LIMIT 1) last_id " +
    "FROM chats c JOIN chat_members me ON me.chat_id=c.id AND me.user_id=?1 " +
    "WHERE (?2=0 OR c.updated_at>?2 OR me.updated_at>?2) AND (me.gone=0 OR ?2>0) AND (c.type='group' OR c.created_by=?1 OR EXISTS(SELECT 1 FROM messages x WHERE x.chat_id=c.id))").bind(u.id, lb).all()).results;
  const lastIds = chats.map((c) => c.last_id).filter(Boolean);
  const st = [
    env.DB.prepare('SELECT cm.chat_id,cm.user_id,cm.role,x.full_name,x.username,x.pubkey pk,x.avatar_ver av,x.about,x.role urole,x.status ustatus,x.permanent upermanent,x.expires_at uexp FROM chat_members cm JOIN users x ON x.id=cm.user_id WHERE cm.gone=0 AND cm.chat_id IN (SELECT c.id FROM chats c JOIN chat_members me ON me.chat_id=c.id AND me.user_id=?1 WHERE (?2=0 OR c.updated_at>?2 OR me.updated_at>?2))').bind(u.id, lb),
    env.DB.prepare('SELECT blocked_id FROM blocks WHERE blocker_id=?1').bind(u.id)
  ];
  const MAXM = 300;
  if (inc) {
    /* start from my chats, then use the (chat, updated_at) index: reads only the changed rows */
    st.push(env.DB.prepare('SELECT m.* FROM chat_members me CROSS JOIN messages m ON m.chat_id=me.chat_id WHERE me.user_id=?1 AND me.gone=0 AND m.updated_at>?2 AND m.created_at+0>COALESCE(me.clear_at,0) AND ' + HID + ' AND ' + BLK + ' ORDER BY m.updated_at LIMIT ' + (MAXM + 1)).bind(u.id, lb));
    st.push(env.DB.prepare('SELECT r.message_id,r.user_id,r.delivered_at,r.read_at FROM receipts r JOIN messages m ON m.id=r.message_id WHERE r.updated_at>?2 AND m.sender_id=?1').bind(u.id, lb));
  }
  for (const part of chunks(lastIds, 80)) {
    st.push(env.DB.prepare('SELECT * FROM messages WHERE id IN (' + inList(part) + ')').bind(...part));
    st.push(env.DB.prepare('SELECT message_id,user_id,delivered_at,read_at FROM receipts WHERE message_id IN (' + inList(part) + ')').bind(...part));
  }
  const rs = await env.DB.batch(st);
  const members = rs[0].results, blocked = rs[1].results.map((r) => r.blocked_id);
  let k = 2, newMsgs = [], rcs = [];
  if (inc) { newMsgs = rs[k++].results; rcs = rs[k++].results; }
  const lastMsgs = {}, lastRc = [];
  while (k < rs.length) {
    for (const r of rs[k++].results) lastMsgs[r.id] = r;
    lastRc.push(...rs[k++].results);
  }
  if (newMsgs.length > MAXM) {
    /* too much at once: send the first part and ask the phone to come back right away */
    newMsgs = newMsgs.slice(0, MAXM);
    out.more = 1; out.ver = since; out.cur = newMsgs[MAXM - 1].updated_at + LOOK - 1;
  }
  const mem = {};
  for (const m of members) (mem[m.chat_id] = mem[m.chat_id] || []).push({ id: m.user_id, role: m.role, full_name: m.full_name, username: m.username, pk: m.pk || '', av: m.av || 0, about: m.about || '', acc: accessOf({ role: m.urole, status: m.ustatus, permanent: m.upermanent, expires_at: m.uexp }, out.now) });
  out.full = !inc;
  out.blocked = blocked;
  out.chats = chats.map((c) => ({
    id: c.id, type: c.type, name: c.name, by: c.created_by, up: c.updated_at, role: c.my_role, muted: c.muted, locked: c.locked,
    read_upto: c.read_upto, gone: c.gone, pinned: c.pinned || 0, archived: c.archived || 0, unread: c.unread, clr: c.clr || 0, members: mem[c.id] || [],
    last: c.last_id && lastMsgs[c.last_id] ? msgOut(lastMsgs[c.last_id]) : null
  }));
  out.msgs = newMsgs.map(msgOut);
  out.rcs = [...rcs, ...lastRc].map((r) => [r.message_id, r.user_id, r.delivered_at, r.read_at]);
  // mark delivered (a cheap look first: most of the time there is nothing to do)
  const t = Date.now();
  const any = await env.DB.prepare('SELECT 1 x FROM receipts WHERE user_id=?1 AND delivered_at IS NULL LIMIT 1').bind(u.id).first();
  if (any) {
    const und = await env.DB.prepare('SELECT DISTINCT m.sender_id s FROM receipts r JOIN messages m ON m.id=r.message_id WHERE r.user_id=?1 AND r.delivered_at IS NULL AND NOT EXISTS (SELECT 1 FROM blocks b WHERE b.blocker_id=?1 AND b.blocked_id=m.sender_id)').bind(u.id).all();
    if (und.results.length) {
      const ids = und.results.map((r) => r.s);
      await env.DB.batch([
        env.DB.prepare('UPDATE receipts SET delivered_at=?1, updated_at=?1 WHERE user_id=?2 AND delivered_at IS NULL AND NOT EXISTS (SELECT 1 FROM messages m JOIN blocks b ON b.blocker_id=?2 AND b.blocked_id=m.sender_id WHERE m.id=receipts.message_id)').bind(t, u.id),
        env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id IN (' + inList(ids, 2) + ')').bind(t, ...ids)]);
      ping(env, ids);
    }
  }
  return J(out);
}

async function chatsApi(env, u, P, M, b, url, t) {
  const id = P[2];
  if (!id && M === 'POST') return J({ error: 'not_found' }, 404);
  if (id === 'self' && M === 'POST') return J({ chat_id: await dmChat(env, u.id, u.id, t) });
  if (id === 'dm' && M === 'POST') {
    let other = null;
    if (b.user_id) other = await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE id=?1').bind(String(b.user_id)).first();
    else other = await findUser(env, b.query, t);
    if (!other || other.id === u.id) return err('user_not_found', 404);
    if (accessOf(other, t) !== 'ok' && u.role !== 'owner') return err('user_not_found', 404);
    return J({ chat_id: await dmChat(env, u.id, other.id, t) });
  }
  if (id === 'group' && M === 'POST') {
    const name = String(b.name || '').trim().slice(0, 60);
    if (!name) return err('bad_name');
    const ids = [...new Set((b.members || []).map(String))].filter((x) => x !== u.id).slice(0, 255);
    const cid = rid(10);
    const sts = [
      env.DB.prepare("INSERT INTO chats(id,type,name,created_by,created_at,updated_at) VALUES(?1,'group',?2,?3,?4,?4)").bind(cid, name, u.id, t),
      env.DB.prepare("INSERT INTO chat_members(chat_id,user_id,role,joined_at,updated_at,read_upto) VALUES(?1,?2,'admin',?3,?3,?3)").bind(cid, u.id, t)];
    for (const x of ids) {
      sts.push(env.DB.prepare("INSERT OR IGNORE INTO chat_members(chat_id,user_id,joined_at,updated_at,read_upto) SELECT ?1,id,?3,?3,?3 FROM users WHERE id=?2 AND (role='owner' OR (status='active' AND (permanent=1 OR expires_at>?3)))").bind(cid, x, t));
    }
    await env.DB.batch(sts);
    await sysMsg(env, cid, u.id, { k: 'created', a: u.full_name, name }, t);
    return J({ chat_id: cid });
  }
  const isSend = P[3] === 'messages' && M === 'POST';
  const pre = [
    env.DB.prepare('SELECT * FROM chat_members WHERE chat_id=?1 AND user_id=?2 AND gone=0').bind(id, u.id),
    env.DB.prepare('SELECT * FROM chats WHERE id=?1').bind(id)];
  if (isSend) pre.push(env.DB.prepare('SELECT cm.user_id, cm.gone, EXISTS(SELECT 1 FROM blocks b WHERE b.blocker_id=?2 AND b.blocked_id=cm.user_id) AS bl FROM chat_members cm WHERE cm.chat_id=?1 AND cm.user_id!=?2').bind(id, u.id));
  const preRes = await env.DB.batch(pre);
  const me = preRes[0].results[0];
  if (!me) return err('not_member', 403);
  const chat = preRes[1].results[0];
  const sub = P[3];
  if (!sub && M === 'PATCH') {
    if (chat.type !== 'group' || me.role !== 'admin') return err('forbidden', 403);
    const name = String(b.name || '').trim().slice(0, 60);
    if (!name) return err('bad_name');
    await env.DB.prepare('UPDATE chats SET name=?1, updated_at=?2 WHERE id=?3').bind(name, t, id).run();
    await env.DB.prepare(bumpSql).bind(t, id).run();
    await sysMsg(env, id, u.id, { k: 'rename', a: u.full_name, name }, t);
    return J({ ok: true });
  }
  if (sub === 'me' && M === 'PATCH') {
    await env.DB.prepare('UPDATE chat_members SET muted=COALESCE(?1,muted), locked=COALESCE(?2,locked), pinned=COALESCE(?6,pinned), archived=COALESCE(?7,archived), updated_at=?3 WHERE chat_id=?4 AND user_id=?5')
      .bind(b.muted === undefined ? null : (b.muted ? 1 : 0), b.locked === undefined ? null : (b.locked ? 1 : 0), t, id, u.id, b.pinned === undefined ? null : (b.pinned ? 1 : 0), b.archived === undefined ? null : (b.archived ? 1 : 0)).run();
    await env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, u.id).run();
    return J({ ok: true });
  }
  if (sub === 'read' && M === 'POST') {
    await env.DB.batch([
      env.DB.prepare('UPDATE chat_members SET read_upto=?1, updated_at=?1 WHERE chat_id=?2 AND user_id=?3').bind(t, id, u.id),
      /* only messages newer than the last time this chat was read can still be unread: never walk the whole chat */
      u.show_read === 0
        ? env.DB.prepare('UPDATE receipts SET delivered_at=COALESCE(delivered_at,?1), updated_at=?1 WHERE delivered_at IS NULL AND (message_id,user_id) IN (SELECT id,?2 FROM messages WHERE chat_id=?3 AND created_at>?4)').bind(t, u.id, id, Math.max(0, (me.read_upto || 0) - 60000))
        : env.DB.prepare('UPDATE receipts SET read_at=?1, delivered_at=COALESCE(delivered_at,?1), updated_at=?1 WHERE read_at IS NULL AND (message_id,user_id) IN (SELECT id,?2 FROM messages WHERE chat_id=?3 AND created_at>?4)').bind(t, u.id, id, Math.max(0, (me.read_upto || 0) - 60000)),
      env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id IN (SELECT user_id FROM chat_members WHERE chat_id=?2 AND gone=0)').bind(t, id)]);
    pingChatBg(env, id);
    return J({ ok: true });
  }
  if (sub === 'typing' && M === 'POST') {
    if (u.show_typing === 0) return J({ ok: true });
    await env.DB.prepare('INSERT OR REPLACE INTO typing VALUES(?1,?2,?3)').bind(id, u.id, t + 4500).run();
    pingChatBg(env, id, JSON.stringify({ k: 't', c: id, u: u.id, n: u.full_name }));
    return J({ ok: true });
  }
  if (sub === 'clear' && M === 'POST') {
    /* one timestamp instead of one hidden row per message: cheap to write, cheap to read */
    await env.DB.batch([
      env.DB.prepare('UPDATE chat_members SET clear_at=?1, read_upto=?1, updated_at=?1 WHERE chat_id=?2 AND user_id=?3').bind(t, id, u.id),
      env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, u.id)]);
    return J({ ok: true });
  }
  if (sub === 'messages' && M === 'GET') {
    const before = +url.searchParams.get('before') || 0;
    const cap = url.searchParams.get('big') === '1' ? 100 : 50;
    const lim = Math.max(1, Math.min(+url.searchParams.get('limit') || 30, cap));
    const clr = me.clear_at || 0;
    const [a, r] = await env.DB.batch([
      env.DB.prepare('SELECT m.* FROM messages m WHERE m.chat_id=?2 AND (?3=0 OR m.created_at<?3) AND m.created_at>?5 AND ' + HID + ' AND ' + BLK + ' ORDER BY m.created_at DESC LIMIT ?4').bind(u.id, id, before, lim, clr),
      env.DB.prepare('SELECT r.message_id,r.user_id,r.delivered_at,r.read_at FROM receipts r WHERE r.message_id IN (SELECT m.id FROM messages m WHERE m.chat_id=?2 AND m.sender_id=?1 AND (?3=0 OR m.created_at<?3) AND m.created_at>?5 ORDER BY m.created_at DESC LIMIT ?4)').bind(u.id, id, before, lim, clr)]);
    return J({ msgs: a.results.map(msgOut).reverse(), rcs: r.results.map((x) => [x.message_id, x.user_id, x.delivered_at, x.read_at]), more: a.results.length === lim });
  }
  if (sub === 'messages' && M === 'POST') {
    if (chat.type === 'dm') {
      const peer = preRes[2] && preRes[2].results[0];
      if (peer) {
        if (peer.bl) return err('you_blocked', 403);
        if (peer.gone) await env.DB.prepare('UPDATE chat_members SET gone=0, updated_at=?1 WHERE chat_id=?2 AND user_id=?3 AND gone=1').bind(t, id, peer.user_id).run();
      }
    }
    const row = await addMessage(env, id, u.id, b, t);
    if (!row) return err('bad_message');
    return J({ msg: msgOut(row) });
  }
  if (chat.type === 'group') {
    if (sub === 'members' && M === 'POST') {
      if (me.role !== 'admin') return err('forbidden', 403);
      const x = b.user_id ? await env.DB.prepare('SELECT ' + UC + ' FROM users WHERE id=?1').bind(String(b.user_id)).first() : await findUser(env, b.query, t);
      if (!x || accessOf(x, t) !== 'ok') return err('user_not_found', 404);
      await env.DB.prepare('INSERT INTO chat_members(chat_id,user_id,joined_at,updated_at,read_upto) VALUES(?1,?2,?3,?3,?3) ON CONFLICT(chat_id,user_id) DO UPDATE SET gone=0, role=\'member\', updated_at=?3, read_upto=?3').bind(id, x.id, t).run();
      await env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, id).run();
      await sysMsg(env, id, u.id, { k: 'add', a: u.full_name, b: x.full_name }, t);
      return J({ ok: true });
    }
    if (sub === 'members' && M === 'DELETE' && P[4]) {
      const target = P[4];
      if (target !== u.id && me.role !== 'admin') return err('forbidden', 403);
      const tm = await memberRow(env, id, target);
      if (!tm) return err('not_found', 404);
      const tu = await env.DB.prepare('SELECT full_name FROM users WHERE id=?1').bind(target).first();
      await env.DB.batch([
        env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, target),
        env.DB.prepare('UPDATE chat_members SET gone=1, updated_at=?1 WHERE chat_id=?2 AND user_id=?3').bind(t, id, target),
        env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, id)]);
      await sysMsg(env, id, u.id, target === u.id ? { k: 'left', a: u.full_name } : { k: 'remove', a: u.full_name, b: tu.full_name }, t);
      return J({ ok: true });
    }
    if (sub === 'admin' && M === 'POST') {
      if (me.role !== 'admin') return err('forbidden', 403);
      await env.DB.prepare('UPDATE chat_members SET role=?1, updated_at=?2 WHERE chat_id=?3 AND user_id=?4 AND gone=0').bind(b.admin ? 'admin' : 'member', t, id, String(b.user_id)).run();
      await env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, id).run();
      await env.DB.prepare(bumpSql).bind(t, id).run();
      return J({ ok: true });
    }
  }
  return err('not_found', 404);
}

async function dropMedia(env, m) {
  let mid = m.media_id, old = false;
  if (!mid) { try { mid = JSON.parse(m.media).id; old = true; } catch (e) { return; } }
  /* a forwarded copy may still use the same file */
  const other = old
    ? await env.DB.prepare('SELECT 1 x FROM messages WHERE id!=?1 AND deleted=0 AND media LIKE ?2 LIMIT 1').bind(m.id, '%"id":"' + mid + '"%').first()
    : await env.DB.prepare('SELECT 1 x FROM messages WHERE media_id=?1 AND id!=?2 AND deleted=0 LIMIT 1').bind(mid, m.id).first();
  if (other) return;
  const md = await env.DB.prepare('SELECT chunks,store FROM media WHERE id=?1').bind(mid).first();
  if (md && md.store) { const keys = []; for (let i = 0; i < md.chunks && i < 90; i++) keys.push('m/' + mid + '/' + i); await blobDel(env, keys); }
  await env.DB.batch([env.DB.prepare('DELETE FROM media_chunks WHERE media_id=?1').bind(mid), env.DB.prepare('DELETE FROM media WHERE id=?1').bind(mid)]);
}

async function messageApi(env, u, P, M, b, t) {
  const m = await env.DB.prepare('SELECT * FROM messages WHERE id=?1').bind(P[2]).first();
  if (!m) return err('not_found', 404);
  const me = await memberRow(env, m.chat_id, u.id);
  if (!me) return err('not_member', 403);
  const bump = () => env.DB.prepare(bumpSql).bind(t, m.chat_id);
  if (P[3] === 'react' && M === 'POST') {
    const rx = JSON.parse(m.reactions || '{}');
    const e = String(b.emoji || '').slice(0, 16);
    if (!e || rx[u.id] === e) delete rx[u.id]; else rx[u.id] = e;
    const rr = await env.DB.batch([
      env.DB.prepare('UPDATE messages SET reactions=?1, updated_at=?2 WHERE id=?3').bind(JSON.stringify(rx), t, m.id), bump(),
      env.DB.prepare('SELECT user_id FROM chat_members WHERE chat_id=?1 AND gone=0').bind(m.chat_id)]);
    if (env.HUB) {
      const ids = ((rr[2] && rr[2].results) || []).map((x) => x.user_id);
      ping(env, ids.filter((x) => x !== u.id), JSON.stringify({ k: 'x', c: m.chat_id, i: m.id, rx, u: t }));
      ping(env, [u.id], '{"k":"v"}');
    }
    return J({ ok: true });
  }
  if (!P[3] && M === 'PATCH') {
    if (m.sender_id !== u.id || m.type !== 'text' || m.deleted) return err('forbidden', 403);
    if (t - m.created_at > 15 * 60 * 1000) return err('too_late', 403);
    if ((m.enc ? 1 : 0) !== (b.enc ? 1 : 0)) return err('bad_message');
    const text = String(b.body || '').slice(0, m.enc ? 150000 : 4000);
    if (!text.trim()) return err('bad_message');
    await env.DB.batch([
      env.DB.prepare('UPDATE messages SET body=?1, edited_at=?2, updated_at=?2 WHERE id=?3').bind(text, t, m.id),
      env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, m.chat_id), bump()]);
    pingChatBg(env, m.chat_id);
    return J({ ok: true });
  }
  if (P[3] === 'delete' && M === 'POST') {
    if (b.scope === 'all') {
      if (m.sender_id !== u.id) return err('forbidden', 403);
      await env.DB.batch([
        env.DB.prepare("UPDATE messages SET deleted=1, body='', updated_at=?1 WHERE id=?2").bind(t, m.id),
        env.DB.prepare('UPDATE chats SET updated_at=?1 WHERE id=?2').bind(t, m.chat_id), bump()]);
      if (m.media) await dropMedia(env, m);
    } else {
      await env.DB.batch([
        env.DB.prepare('INSERT OR IGNORE INTO hidden_msgs VALUES(?1,?2)').bind(u.id, m.id),
        env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, u.id)]);
    }
    pingChatBg(env, m.chat_id);
    return J({ ok: true });
  }
  return err('not_found', 404);
}

async function mediaApi(env, u, P, M, req, b, t) {
  const kind = blobKind(env);
  if (!P[2] && M === 'POST') {
    if (kind === 'none') return err('no_storage', 503);
    const size = +b.size || 0;
    /* new apps send v2 and let the server pick the piece size; old apps send their own piece count */
    const n = b.v2 ? Math.max(1, Math.ceil(size / CHUNK_BLOB)) : (+b.chunks || 0);
    if (size < 1 || size > MAX_MEDIA || n < 1 || n > 90) return err('too_big', 413);
    const id = rid(16);
    await env.DB.prepare('INSERT INTO media(id,owner_id,mime,size,name,chunks,created_at,store) VALUES(?1,?2,?3,?4,?5,?6,?7,?8)')
      .bind(id, u.id, String(b.mime || '').slice(0, 80), size, String(b.name || '').slice(0, 120), n, t, kind).run();
    return J({ id, chunk: CHUNK_BLOB, chunks: n, bin: true });
  }
  const id = P[2], idx = parseInt(P[3], 10);
  if (!id || !(idx >= 0)) return err('bad_request');
  if (M === 'PUT') {
    if (kind === 'none') return err('no_storage', 503);
    const md = await env.DB.prepare('SELECT chunks FROM media WHERE id=?1 AND owner_id=?2').bind(id, u.id).first();
    if (!md || idx >= md.chunks) return err('not_found', 404);
    let data, meta = {};
    if (/octet-stream/i.test(req.headers.get('content-type') || '')) {
      data = await req.arrayBuffer();
      if (data.byteLength > CHUNK_BLOB + 1024) return err('too_big', 413);
    } else {
      data = await req.text();                 /* old apps: base64 text, stored as it is */
      if (data.length > 460000) return err('too_big', 413);
      meta = { e: 'b64' };
    }
    await blobPut(env, 'm/' + id + '/' + idx, data, meta);
    return J({ ok: true });
  }
  if (M === 'GET') {
    const hd = (txt) => ({ ...CORS, 'content-type': txt ? 'text/plain' : 'application/octet-stream', 'cache-control': 'private, max-age=31536000, immutable', ...(txt ? { 'x-enc': 'b64' } : {}) });
    const o = await blobGet(env, 'm/' + id + '/' + idx);
    if (o) return new Response(o.body, { headers: hd(o.meta.e === 'b64') });
    /* files uploaded before the move to R2 / KV are still in D1 until the owner moves them */
    const r = await env.DB.prepare('SELECT data FROM media_chunks WHERE media_id=?1 AND idx=?2').bind(id, idx).first();
    if (!r) return err('not_found', 404);
    return new Response(r.data, { headers: hd(true) });
  }
  return err('not_found', 404);
}

async function ownerChat(env, u, M, b, t) {
  const o = await env.DB.prepare("SELECT id,full_name,pubkey FROM users WHERE role='owner' LIMIT 1").first();
  if (!o || u.role === 'owner') return err('forbidden', 403);
  if (u.status === 'blocked') return err('blocked', 403);
  const cid = await dmChat(env, u.id, o.id, t, true);
  if (M === 'POST') {
    const recent = await env.DB.prepare('SELECT COUNT(*) c FROM messages WHERE chat_id=?3 AND sender_id=?1 AND created_at>?2').bind(u.id, t - 60000, cid).first();
    if (recent.c >= 8) return err('too_many', 429);
    const row = await addMessage(env, cid, u.id, { type: 'text', body: b.enc ? String(b.body || '') : String(b.text || '').slice(0, 600), enc: b.enc ? 1 : 0, id: b.id }, t);
    if (!row) return err('bad_message');
    return J({ msg: msgOut(row) });
  }
  const rs = await env.DB.batch([
    env.DB.prepare('SELECT m.* FROM messages m WHERE m.chat_id=?2 AND m.type=\'text\' AND ' + HID + ' ORDER BY m.created_at DESC LIMIT 60').bind(u.id, cid),
    env.DB.prepare('SELECT r.message_id,r.user_id,r.delivered_at,r.read_at FROM receipts r WHERE r.message_id IN (SELECT id FROM messages WHERE chat_id=?2 AND sender_id=?1 ORDER BY created_at DESC LIMIT 60)').bind(u.id, cid),
    env.DB.prepare('UPDATE receipts SET read_at=?1, delivered_at=COALESCE(delivered_at,?1), updated_at=?1 WHERE read_at IS NULL AND (message_id,user_id) IN (SELECT id,?2 FROM messages WHERE chat_id=?3 AND created_at>?4)').bind(t, u.id, cid, t - 3 * 864e5)]);
  return J({ chat_id: cid, owner: { id: o.id, full_name: o.full_name, pk: o.pubkey || '' }, msgs: rs[0].results.map(msgOut).reverse(), rcs: rs[1].results.map((x) => [x.message_id, x.user_id, x.delivered_at, x.read_at]) });
}

/* Moves a few old files per call from D1 to R2 / KV (a small batch keeps each call inside the free CPU and subrequest limits). */
async function migrateStep(env) {
  if (blobKind(env) === 'none') return err('no_storage', 503);
  let moved = 0, more = false;
  const av = (await env.DB.prepare("SELECT id,avatar FROM users WHERE avatar LIKE 'data:%' LIMIT 3").all()).results;
  for (const r of av) {
    const x = parseDataUrl(r.avatar);
    if (!x) { await env.DB.prepare("UPDATE users SET avatar=NULL WHERE id=?1").bind(r.id).run(); continue; }
    await blobPut(env, 'av/' + r.id, b64ToBytes(x.b64), { mime: x.mime });
    await env.DB.prepare("UPDATE users SET avatar='blob' WHERE id=?1").bind(r.id).run();
    moved++;
  }
  if (av.length === 3) more = true;
  const ch = (await env.DB.prepare('SELECT media_id,idx,data FROM media_chunks LIMIT 5').all()).results;
  const del = [];
  for (const r of ch) {
    await blobPut(env, 'm/' + r.media_id + '/' + r.idx, r.data, { e: 'b64' });
    del.push(env.DB.prepare('DELETE FROM media_chunks WHERE media_id=?1 AND idx=?2').bind(r.media_id, r.idx));
    del.push(env.DB.prepare('UPDATE media SET store=?2 WHERE id=?1 AND store IS NULL').bind(r.media_id, blobKind(env)));
    moved++;
  }
  if (del.length) await env.DB.batch(del);
  if (ch.length === 5) more = true;
  return J({ moved, more, store: blobKind(env) });
}

async function ownerApi(env, u, P, M, b, t) {
  const sub = P[2], act = P[3];
  if (sub === 'codes' && M === 'GET') {
    const cs = (await env.DB.prepare('SELECT * FROM codes ORDER BY created_at DESC LIMIT 300').all()).results;
    const us = (await env.DB.prepare('SELECT cu.code,x.full_name n,cu.used_at at FROM code_uses cu JOIN users x ON x.id=cu.user_id ORDER BY cu.used_at DESC LIMIT 600').all()).results;
    return J({ codes: cs.map((c) => ({ ...c, used_by: us.filter((x) => x.code === c.code).map((x) => ({ name: x.n, at: x.at })) })) });
  }
  if (sub === 'codes' && M === 'POST' && !act) {
    const code = String(b.code || '');
    if (code.length < 4 || code.length > 64 || /\s/.test(code)) return err('bad_code_format');
    const perm = b.permanent ? 1 : 0;
    const dur = perm ? 'year' : String(b.duration);
    if (!DUR[dur]) return err('bad_request');
    const max = b.unlimited ? 0 : Math.max(1, Math.min(10000, parseInt(b.max_uses, 10) || 1));
    try {
      await env.DB.prepare('INSERT INTO codes(code,duration,permanent,max_uses,note,created_at) VALUES(?1,?2,?3,?4,?5,?6)')
        .bind(code, dur, perm, max, String(b.note || '').slice(0, 80), t).run();
    } catch (e) {
      if (/UNIQUE|PRIMARY/i.test(String(e && e.message || e))) return err('code_exists', 409);
      throw e;
    }
    return J({ ok: true });
  }
  if (sub === 'codes' && act === 'cancel' && M === 'POST') {
    await env.DB.prepare("UPDATE codes SET status=CASE WHEN status='active' THEN 'cancelled' ELSE 'active' END WHERE code=?1").bind(String(b.code)).run();
    return J({ ok: true });
  }
  if (sub === 'codes' && act === 'delete' && M === 'POST') {
    await env.DB.batch([
      env.DB.prepare('DELETE FROM codes WHERE code=?1').bind(String(b.code)),
      env.DB.prepare('DELETE FROM code_uses WHERE code=?1').bind(String(b.code))]);
    return J({ ok: true });
  }
  if (sub === 'members' && M === 'GET') {
    const r = (await env.DB.prepare("SELECT " + UC + " FROM users WHERE role!='owner' ORDER BY created_at DESC LIMIT 500").all()).results;
    return J({ members: r.map((x) => ({
      id: x.id, full_name: x.full_name, username: x.username, phone: x.phone, status: x.status, access: accessOf(x, t),
      permanent: !!x.permanent, expires_at: x.expires_at, last_seen: x.last_seen, created_at: x.created_at
    })) });
  }
  if (sub === 'members' && M === 'POST' && b.id) {
    if (act === 'block') await env.DB.prepare("UPDATE users SET status='blocked' WHERE id=?1 AND role!='owner'").bind(b.id).run();
    else if (act === 'unblock') await env.DB.prepare("UPDATE users SET status=CASE WHEN permanent=1 OR expires_at>0 THEN 'active' ELSE 'pending' END WHERE id=?1 AND status='blocked'").bind(b.id).run();
    else if (act === 'revoke') await env.DB.prepare("UPDATE users SET status='pending', permanent=0, expires_at=0 WHERE id=?1 AND role!='owner'").bind(b.id).run();
    else if (act === 'lockreset') {
      if (!/^[0-9a-f]{8,64}$/.test(String(b.salt || '')) || !/^[0-9a-f]{64}$/.test(String(b.hash || ''))) return err('bad_request');
      await env.DB.prepare("UPDATE users SET lock_hash=?1, lock_salt=?2 WHERE id=?3 AND role!='owner'").bind(b.hash, b.salt, b.id).run();
      await env.DB.prepare('UPDATE users SET inbox_ver=MAX(inbox_ver+1,?1) WHERE id=?2').bind(t, b.id).run();
      ping(env, [b.id]);
      return J({ ok: true });
    } else return err('bad_request');
    await touchOwnerChat(env, b.id, t);
    return J({ ok: true });
  }
  if (sub === 'storage' && M === 'GET') {
    const c = await env.DB.prepare('SELECT 1 x FROM media_chunks LIMIT 1').first();
    const a = await env.DB.prepare("SELECT 1 x FROM users WHERE avatar LIKE 'data:%' LIMIT 1").first();
    return J({ store: blobKind(env), old_files: !!c, old_avatars: !!a });
  }
  if (sub === 'migrate' && M === 'POST') return await migrateStep(env);
  if (sub === 'settings' && M === 'POST') {
    await env.DB.prepare("INSERT OR REPLACE INTO settings VALUES('allow_screens',?1)").bind(b.allow_screens ? '1' : '0').run();
    settingsC = { v: null, at: 0 };
    return J({ ok: true });
  }
  return err('not_found', 404);
}
