'use strict';
/* ---------- themes & wallpapers ---------- */
const ACCENTS = {
  blue: ['#4da8ff', '#7cc4ff', '#06223f', '#2f7fd8'], emerald: ['#2fd19b', '#6ee7b7', '#052e22', '#1f9d73'], violet: ['#9b7bff', '#c0a8ff', '#1c0f4d', '#6d4fe0'],
  orange: ['#ffa24d', '#ffc285', '#3d1f00', '#d9822b'], rose: ['#ff6b9a', '#ff9bbd', '#4a0a22', '#d9457a'], teal: ['#2fc4d8', '#7ae3f0', '#04323a', '#1f9aae']
};
const PALETTES = {"classic":{"light":false,"v":{"bg":"#000000","card":"#0e0f13","card2":"#14161d","bd":"#1b2232","bd2":"#232a3b","inp":"#171a24","inp2":"#12151d","btn":"#1a1d27","tx":"#ffffff","tx2":"#c9d1e3","mu":"#8b93a7","ac":"#4da8ff","onac":"#06223f","dn":"#ff6b6b","bo":"#2f7fd8","botx":"#ffffff","bi":"#1c2030","bitx":"#ffffff","press":"#ffffff0d","press2":"#ffffff18","tickc":"#ffffffb0","quoteb":"#00000030","quotebar":"#ffffff","wallbg":"#090b10","bg2":"#07080b","ac2":"#7cc4ff","mu2":"#aeb6c9","lk":"#9fe0ff"}},"wa-dark":{"light":false,"v":{"bg":"#0b141a","card":"#111b21","card2":"#1f2c34","bd":"#222d34","bd2":"#2a3942","inp":"#202c33","inp2":"#1a252c","btn":"#202c33","tx":"#e9edef","tx2":"#c3ccd0","mu":"#8696a0","ac":"#00a884","onac":"#04251d","dn":"#f15c6d","bo":"#005c4b","botx":"#e9edef","bi":"#202c33","bitx":"#e9edef","press":"#ffffff0d","press2":"#ffffff18","tickc":"#8696a0","quoteb":"#00000033","quotebar":"#06cf9c","wallbg":"#0b141a","bg2":"#1f2c34","ac2":"#06cf9c","mu2":"#8696a0","lk":"#53bdeb"}},"wa-light":{"light":true,"v":{"bg":"#ffffff","card":"#f7f8fa","card2":"#ffffff","bd":"#e9edef","bd2":"#d1d7db","inp":"#f0f2f5","inp2":"#f7f8fa","btn":"#f0f2f5","tx":"#111b21","tx2":"#3b4a54","mu":"#667781","ac":"#00a884","onac":"#ffffff","dn":"#d93025","bo":"#d9fdd3","botx":"#111b21","bi":"#ffffff","bitx":"#111b21","press":"#0000000d","press2":"#00000014","tickc":"#667781","quoteb":"#00000012","quotebar":"#06cf9c","wallbg":"#efeae2","bg2":"#ffffff","ac2":"#06cf9c","mu2":"#54656f","lk":"#027eb5"}},"ocean":{"light":false,"v":{"bg":"#08161f","card":"#0d2330","card2":"#12303f","bd":"#173a4c","bd2":"#1f4a60","inp":"#12303f","inp2":"#0f2937","btn":"#12303f","tx":"#e9edef","tx2":"#c3ccd0","mu":"#8696a0","ac":"#29b6f6","onac":"#00222f","dn":"#f15c6d","bo":"#0a6a8f","botx":"#e9edef","bi":"#12303f","bitx":"#e9edef","press":"#ffffff0d","press2":"#ffffff18","tickc":"#8696a0","quoteb":"#00000033","quotebar":"#7fd8ff","wallbg":"#08161f","bg2":"#0d2a3a","ac2":"#7fd8ff","mu2":"#8696a0","lk":"#9fe6ff"}},"grape":{"light":false,"v":{"bg":"#130d22","card":"#1b1330","card2":"#241a3a","bd":"#2d2250","bd2":"#3a2d66","inp":"#2a1f45","inp2":"#221a3a","btn":"#2a1f45","tx":"#e9edef","tx2":"#c3ccd0","mu":"#8696a0","ac":"#a07bff","onac":"#1d0f3d","dn":"#f15c6d","bo":"#5b34b8","botx":"#e9edef","bi":"#2a1f45","bitx":"#e9edef","press":"#ffffff0d","press2":"#ffffff18","tickc":"#8696a0","quoteb":"#00000033","quotebar":"#c4a8ff","wallbg":"#130d22","bg2":"#241a3a","ac2":"#c4a8ff","mu2":"#8696a0","lk":"#cdb8ff"}},"rose":{"light":false,"v":{"bg":"#1a0c13","card":"#26101a","card2":"#35192a","bd":"#4a2238","bd2":"#5c2b45","inp":"#35192a","inp2":"#2c1422","btn":"#35192a","tx":"#e9edef","tx2":"#c3ccd0","mu":"#8696a0","ac":"#ff6b9a","onac":"#3a0d20","dn":"#f15c6d","bo":"#a82b5c","botx":"#e9edef","bi":"#35192a","bitx":"#e9edef","press":"#ffffff0d","press2":"#ffffff18","tickc":"#8696a0","quoteb":"#00000033","quotebar":"#ff9dbd","wallbg":"#1a0c13","bg2":"#3a1624","ac2":"#ff9dbd","mu2":"#8696a0","lk":"#ffc1d8"}},"forest":{"light":false,"v":{"bg":"#0b1a11","card":"#10241a","card2":"#16301f","bd":"#1f4230","bd2":"#2a5640","inp":"#1a3a28","inp2":"#14301f","btn":"#1a3a28","tx":"#e9edef","tx2":"#c3ccd0","mu":"#8696a0","ac":"#4cd37d","onac":"#05260f","dn":"#f15c6d","bo":"#1d6b3b","botx":"#e9edef","bi":"#1a3a28","bitx":"#e9edef","press":"#ffffff0d","press2":"#ffffff18","tickc":"#8696a0","quoteb":"#00000033","quotebar":"#7fe3a3","wallbg":"#0b1a11","bg2":"#16301f","ac2":"#7fe3a3","mu2":"#8696a0","lk":"#b6f5cd"}}};
const WALLS = {"dots":[null,"radial-gradient(#ffffff09 1px, transparent 1px)","22px 22px","radial-gradient(#00000012 1px, transparent 1px)"],"plain":[null,"none","auto"],"amoled":["#000","none","auto"],"doodle":[null,"url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180' viewBox='0 0 180 180' fill='none' stroke='%23ffffff' stroke-opacity='.045' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='24' cy='26' r='9'/%3E%3Cpath d='M70 20l6 12 13 2-9 9 2 13-12-6-12 6 2-13-9-9 13-2z'/%3E%3Cpath d='M130 30c0-9 14-9 14 0 0 8-14 16-14 16s-14-8-14-16c0-9 14-9 14 0z'/%3E%3Cpath d='M18 88h22M18 98h14'/%3E%3Crect x='72' y='80' width='24' height='18' rx='4'/%3E%3Cpath d='M108 90l12-8v16z'/%3E%3Ccircle cx='150' cy='92' r='6'/%3E%3Cpath d='M30 140c8-12 16 12 24 0'/%3E%3Cpath d='M84 140l8 8 14-16'/%3E%3Cpath d='M130 130l10 18M146 130l-10 18'/%3E%3C/svg%3E\")","180px 180px","url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180' viewBox='0 0 180 180' fill='none' stroke='%23000000' stroke-opacity='.07' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='24' cy='26' r='9'/%3E%3Cpath d='M70 20l6 12 13 2-9 9 2 13-12-6-12 6 2-13-9-9 13-2z'/%3E%3Cpath d='M130 30c0-9 14-9 14 0 0 8-14 16-14 16s-14-8-14-16c0-9 14-9 14 0z'/%3E%3Cpath d='M18 88h22M18 98h14'/%3E%3Crect x='72' y='80' width='24' height='18' rx='4'/%3E%3Cpath d='M108 90l12-8v16z'/%3E%3Ccircle cx='150' cy='92' r='6'/%3E%3Cpath d='M30 140c8-12 16 12 24 0'/%3E%3Cpath d='M84 140l8 8 14-16'/%3E%3Cpath d='M130 130l10 18M146 130l-10 18'/%3E%3C/svg%3E\")"],"aurora":["#0b1020","linear-gradient(160deg,#0b1020 0%,#0d2a3a 50%,#1a1038 100%)","cover"],"sunset":["#1a0f1f","linear-gradient(160deg,#1a0f1f,#3a1530 55%,#1f1018)","cover"],"forest":["#07140f","linear-gradient(160deg,#07140f,#0c2a1c 55%,#08140e)","cover"],"ocean":["#06121f","linear-gradient(170deg,#06121f,#0a2a4a 60%,#07192b)","cover"],"slate":["#10131a","linear-gradient(160deg,#10131a,#1b2230 60%,#10131a)","cover"],"dusk":["#2b1055","linear-gradient(160deg,#2b1055,#4b6cb7)","cover"],"mint":["#0f2a24","linear-gradient(160deg,#0f2a24,#1f6b57)","cover"],"sky":["#0d2a4a","linear-gradient(160deg,#0d2a4a,#3b82c4)","cover"],"rose":["#3a1624","linear-gradient(160deg,#3a1624,#a8386a)","cover"],"night":["#04060d","linear-gradient(180deg,#04060d,#161d3a)","cover"],"sand":["#efe3c8","linear-gradient(160deg,#efe3c8,#d6c29a)","cover"]};
const Theme = {
  get() { return Object.assign({ theme: 'classic', accent: null, wall: 'dots', custom: null, size: 'm' }, store.get('theme', {})); },
  set(patch) { store.set('theme', Object.assign(this.get(), patch)); this.apply(); },
  apply() {
    const c = this.get(), p = PALETTES[c.theme] || PALETTES.classic, r = document.documentElement.style;
    for (const k in p.v) r.setProperty('--' + k, p.v[k]);
    const a = c.accent && ACCENTS[c.accent];
    if (a) { r.setProperty('--ac', a[0]); r.setProperty('--ac2', a[1]); r.setProperty('--onac', a[2]); if (!p.light) r.setProperty('--bo', a[3]); }
    r.setProperty('--fs', { s: '14px', m: '15.5px', l: '17.5px' }[c.size] || '15.5px');
    r.colorScheme = p.light ? 'light' : 'dark';
    if (c.wall === 'custom' && c.custom) { r.setProperty('--wallbg', '#000'); r.setProperty('--wall', 'url(' + c.custom + ')'); r.setProperty('--wallsize', 'cover'); }
    else { const w = WALLS[c.wall] || WALLS.dots; r.setProperty('--wallbg', w[0] || p.v.wallbg); r.setProperty('--wall', (p.light && w[3]) ? w[3] : w[1]); r.setProperty('--wallsize', w[2]); }
    try { if (window.Android && Android.lightBars) Android.lightBars(!!p.light, p.v.bg); } catch (e) { /* old shell */ }
  },
  async fromFile(file, maxSide, quality) {
    const bmp = await createImageBitmap(file);
    const sc = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * sc), hh = Math.round(bmp.height * sc);
    const cv = h('canvas', { width: w, height: hh }); cv.getContext('2d').drawImage(bmp, 0, 0, w, hh);
    return cv.toDataURL('image/jpeg', quality);
  }
};

/* ---------- floating calculator button (the way back to the calculator) ---------- */
const Ball = {
  el: null, inset: { top: 0, bottom: 0 },
  cfg() { return Object.assign({ show: true, move: true, size: 48, fx: null, fy: null }, store.get('ball', {})); },
  save(p) { store.set('ball', Object.assign(this.cfg(), p)); },
  init() {
    const btn = h('button', { 'aria-label': 'Calculator' }, ic('calc', 22));
    this.el = h('div', { id: 'ball' }, btn);
    document.body.append(this.el);
    let sx = 0, sy = 0, ox = 0, oy = 0, drag = false, down = false;
    this.el.addEventListener('pointerdown', (e) => {
      down = true; drag = false; sx = e.clientX; sy = e.clientY;
      const r = this.el.getBoundingClientRect(); ox = r.left; oy = r.top;
      try { this.el.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ }
    });
    this.el.addEventListener('pointermove', (e) => {
      if (!down || !this.cfg().move) return;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (!drag && Math.hypot(dx, dy) > 6) { drag = true; this.el.classList.add('drag'); }
      if (drag) this.move(ox + dx, oy + dy);
    });
    const up = () => {
      if (!down) return; down = false; this.el.classList.remove('drag');
      if (drag) { const r = this.el.getBoundingClientRect(), p = this.bounds(); this.save({ fx: p.w > 0 ? (r.left - p.l) / p.w : 1, fy: p.h > 0 ? (r.top - p.t) / p.h : 0.12 }); }
      else App.lockApp();
    };
    this.el.addEventListener('pointerup', up);
    this.el.addEventListener('pointercancel', () => { down = false; this.el.classList.remove('drag'); });
    window.addEventListener('resize', () => this.place());
    this.place();
  },
  bounds() {
    const s = this.cfg().size, vw = window.innerWidth, vh = window.innerHeight;
    const l = 4, t = this.inset.top + 4, r = vw - s - 4, b = vh - s - this.inset.bottom - 4;
    return { l, t, w: Math.max(0, r - l), h: Math.max(0, b - t) };
  },
  move(x, y) {
    const p = this.bounds();
    this.el.style.left = Math.min(p.l + p.w, Math.max(p.l, x)) + 'px'; this.el.style.top = Math.min(p.t + p.h, Math.max(p.t, y)) + 'px';
  },
  place() {
    if (!this.el) return;
    const c = this.cfg(), p = this.bounds();
    this.el.style.width = this.el.style.height = c.size + 'px';
    const fx = c.fx == null ? 1 : c.fx, fy = c.fy == null ? 0.12 : c.fy;
    this.el.style.left = (p.l + p.w * fx) + 'px'; this.el.style.top = (p.t + p.h * fy) + 'px';
    this.el.classList.toggle('free', !!c.move);
  },
  reset() { store.del('ball'); this.place(); },
  show(on) { if (this.el) this.el.classList.toggle('show', !!on && this.cfg().show); }
};
window.__insets = (top, bottom) => {
  const r = document.documentElement.style;
  r.setProperty('--st', Math.max(0, top) + 'px'); r.setProperty('--sb', Math.max(0, bottom) + 'px');
  Ball.inset = { top: Math.max(0, top), bottom: Math.max(0, bottom) }; Ball.place();
};

/* ---------- emoji: recents + search ---------- */
const Emo = {
  recent() { return store.get('emo_recent', []); },
  add(e) { const l = [e, ...this.recent().filter((x) => x !== e)].slice(0, 36); store.set('emo_recent', l); },
  search(q) {
    q = q.trim().toLowerCase(); if (!q) return [];
    const out = [];
    for (const k in EMOJI_NAMES) { if (EMOJI_NAMES[k].includes(q)) out.push(k); if (out.length >= 120) break; }
    return out;
  }
};

/* ---------- WhatsApp style text: *bold* _italic_ ~strike~ `mono` + links ---------- */
function renderText(str) {
  const out = []; let last = 0;
  const re = /(https?:\/\/[^\s<]+)|\*([^*\n]+)\*|_([^_\n]+)_|~([^~\n]+)~|`([^`\n]+)`/g;
  let m;
  while ((m = re.exec(str))) {
    if (m.index > last) out.push(str.slice(last, m.index));
    if (m[1]) { const u = m[1]; out.push(h('a', { class: 'lk', onclick: (e) => { e.stopPropagation(); if (nat && nat.open) nat.open(u); else window.open(u, '_blank'); } }, u)); }
    else if (m[2]) out.push(h('b', null, m[2]));
    else if (m[3]) out.push(h('i', null, m[3]));
    else if (m[4]) out.push(h('s', null, m[4]));
    else out.push(h('code', null, m[5]));
    last = m.index + m[0].length;
  }
  if (last < str.length) out.push(str.slice(last));
  return out;
}

/* ---------- encrypted backup of contacts, settings and chat history ---------- */
async function backupKey(pw, salt) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 250000 }, k, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function makeBackup() {
  let pw;
  for (;;) {
    const v = await ask(t('backup_create'), [{ label: t('backup_pw'), pw: true, hint: t('backup_pw_hint') }, { label: t('f_pw2'), pw: true }], t('backup_make'), t('backup_text'));
    if (!v) return;
    if (v[0].length < 6) { toast(t('e_backup_short')); continue; }
    if (v[0] !== v[1]) { toast(t('e_pw_mismatch')); continue; }
    pw = v[0]; break;
  }
  const out = { v: 1, at: Date.now(), me: { id: S.me.id, username: S.me.username, full_name: S.me.full_name, about: S.me.about },
    contacts: [...S.contacts.entries()].map(([id, c]) => ({ id, name: c.name, username: c.username })),
    settings: { theme: Theme.get(), lang: S.lang, ball: store.get('ball', null), autolock: S.autoLock, recents: store.get('recents', 1) }, chats: [] };
  let total = 0;
  const chats = [...S.chats.values()];
  for (let i = 0; i < chats.length; i++) {
    const c = chats[i]; toast(t('backup_progress', { n: i + 1, m: chats.length }));
    /* whatever is already saved on the phone is used first: only missing older pages are asked from the server */
    let msgs = [];
    try { msgs = await Hist.all(c.id, 4000); } catch (e) { msgs = S.msgs.get(c.id) || []; }
    total += msgs.length;
    out.chats.push({ id: c.id, type: c.type, title: chatTitle(c), members: c.members.map((m) => displayName(m.id)),
      messages: msgs.filter((m) => m.type !== 'sys').map((m) => ({ at: m.at, from: displayName(m.sid), type: m.type, text: m.del ? '' : m.body, file: m.media && m.media.name ? m.media.name : undefined, deleted: !!m.del })) });
  }
  const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await backupKey(pw, salt), new TextEncoder().encode(JSON.stringify(out))));
  const magic = new TextEncoder().encode('CBK1');
  const file = new Uint8Array(4 + 16 + 12 + ct.length); file.set(magic, 0); file.set(salt, 4); file.set(iv, 20); file.set(ct, 32);
  const name = 'backup-' + new Date().toISOString().slice(0, 10) + '.cbk';
  if (nat && nat.save) { const ok = nat.save(name, 'application/octet-stream', E2E.b64(file)); toast(ok ? t('backup_done', { n: total }) : t('e_generic')); }
  else { const a = h('a', { href: URL.createObjectURL(new Blob([file])), download: name }); document.body.append(a); a.click(); a.remove(); toast(t('backup_done', { n: total })); }
  store.set('backup_at', Date.now());
  return file;
}
async function restoreBackup(file) {
  const buf = new Uint8Array(await file.arrayBuffer());
  if (new TextDecoder().decode(buf.subarray(0, 4)) !== 'CBK1') return toast(t('e_backup_bad'));
  const v = await ask(t('backup_restore'), [{ label: t('backup_pw'), pw: true }], t('backup_restore_go'));
  if (!v) return;
  let data;
  try { data = JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: buf.subarray(20, 32) }, await backupKey(v[0], buf.subarray(4, 20)), buf.subarray(32)))); }
  catch (e) { return toast(t('e_backup_pw')); }
  let n = 0;
  for (const c of data.contacts || []) { try { await api('/api/contacts', { body: { user_id: c.id, name: c.name }, quiet: true }); n++; } catch (e) { /* user no longer available */ } }
  const st = data.settings || {};
  if (st.theme) store.set('theme', st.theme);
  if (st.ball) store.set('ball', st.ball);
  if (st.lang) setLang(st.lang);
  Theme.apply(); await loadContacts();
  toast(t('backup_restored', { n }));
}
