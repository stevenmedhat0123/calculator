'use strict';
/* ---------- themes & wallpapers ---------- */
const ACCENTS = {
  blue: ['#4da8ff', '#7cc4ff', '#06223f', '#2f7fd8'], emerald: ['#2fd19b', '#6ee7b7', '#052e22', '#1f9d73'], violet: ['#9b7bff', '#c0a8ff', '#1c0f4d', '#6d4fe0'],
  orange: ['#ffa24d', '#ffc285', '#3d1f00', '#d9822b'], rose: ['#ff6b9a', '#ff9bbd', '#4a0a22', '#d9457a'], teal: ['#2fc4d8', '#7ae3f0', '#04323a', '#1f9aae']
};
const WALLS = {
  dots: ['#090b10', 'radial-gradient(#ffffff09 1px, transparent 1px)', '22px 22px'], plain: ['#090b10', 'none', 'auto'], amoled: ['#000', 'none', 'auto'],
  aurora: ['#0b1020', 'linear-gradient(160deg,#0b1020 0%,#0d2a3a 50%,#1a1038 100%)', 'cover'], sunset: ['#1a0f1f', 'linear-gradient(160deg,#1a0f1f,#3a1530 55%,#1f1018)', 'cover'],
  forest: ['#07140f', 'linear-gradient(160deg,#07140f,#0c2a1c 55%,#08140e)', 'cover'], ocean: ['#06121f', 'linear-gradient(170deg,#06121f,#0a2a4a 60%,#07192b)', 'cover'],
  slate: ['#10131a', 'linear-gradient(160deg,#10131a,#1b2230 60%,#10131a)', 'cover']
};
const Theme = {
  get() { return Object.assign({ accent: 'blue', wall: 'dots', custom: null, size: 'm' }, store.get('theme', {})); },
  set(patch) { store.set('theme', Object.assign(this.get(), patch)); this.apply(); },
  apply() {
    const c = this.get(), a = ACCENTS[c.accent] || ACCENTS.blue, r = document.documentElement.style;
    r.setProperty('--ac', a[0]); r.setProperty('--ac2', a[1]); r.setProperty('--onac', a[2]); r.setProperty('--bo', a[3]);
    r.setProperty('--fs', { s: '14px', m: '15.5px', l: '17.5px' }[c.size] || '15.5px');
    if (c.wall === 'custom' && c.custom) { r.setProperty('--wallbg', '#000'); r.setProperty('--wall', 'url(' + c.custom + ')'); r.setProperty('--wallsize', 'cover'); }
    else { const w = WALLS[c.wall] || WALLS.dots; r.setProperty('--wallbg', w[0]); r.setProperty('--wall', w[1]); r.setProperty('--wallsize', w[2]); }
  },
  async fromFile(file, maxSide, quality) {
    const bmp = await createImageBitmap(file);
    const sc = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * sc), hh = Math.round(bmp.height * sc);
    const cv = h('canvas', { width: w, height: hh }); cv.getContext('2d').drawImage(bmp, 0, 0, w, hh);
    return cv.toDataURL('image/jpeg', quality);
  }
};

/* ---------- floating calculator button (the way back to the calculator) ---------- */
const Ball = {
  el: null, inset: { top: 0, bottom: 0 },
  cfg() { return Object.assign({ show: true, move: true, size: 48, fx: null, fy: null }, store.get('ball', {})); },
  save(p) { store.set('ball', Object.assign(this.cfg(), p)); },
  init() {
    const btn = h('button', { 'aria-label': 'Calculator' }, ic('calc', 22));
    this.el = h('div', { id: 'ball' }, btn);
    document.body.append(this.el);
    let sx = 0, sy = 0, ox = 0, oy = 0, drag = false, down = false;
    this.el.addEventListener('pointerdown', (e) => {
      down = true; drag = false; sx = e.clientX; sy = e.clientY;
      const r = this.el.getBoundingClientRect(); ox = r.left; oy = r.top;
      try { this.el.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ }
    });
    this.el.addEventListener('pointermove', (e) => {
      if (!down || !this.cfg().move) return;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (!drag && Math.hypot(dx, dy) > 6) { drag = true; this.el.classList.add('drag'); }
      if (drag) this.move(ox + dx, oy + dy);
    });
    const up = () => {
      if (!down) return; down = false; this.el.classList.remove('drag');
      if (drag) { const r = this.el.getBoundingClientRect(), p = this.bounds(); this.save({ fx: p.w > 0 ? (r.left - p.l) / p.w : 1, fy: p.h > 0 ? (r.top - p.t) / p.h : 0.12 }); }
      else App.lockApp();
    };
    this.el.addEventListener('pointerup', up);
    this.el.addEventListener('pointercancel', () => { down = false; this.el.classList.remove('drag'); });
    window.addEventListener('resize', () => this.place());
    this.place();
  },
  bounds() {
    const s = this.cfg().size, vw = window.innerWidth, vh = window.innerHeight;
    const l = 4, t = this.inset.top + 4, r = vw - s - 4, b = vh - s - this.inset.bottom - 4;
    return { l, t, w: Math.max(0, r - l), h: Math.max(0, b - t) };
  },
  move(x, y) {
    const p = this.bounds();
    this.el.style.left = Math.min(p.l + p.w, Math.max(p.l, x)) + 'px'; this.el.style.top = Math.min(p.t + p.h, Math.max(p.t, y)) + 'px';
  },
  place() {
    if (!this.el) return;
    const c = this.cfg(), p = this.bounds();
    this.el.style.width = this.el.style.height = c.size + 'px';
    const fx = c.fx == null ? 1 : c.fx, fy = c.fy == null ? 0.12 : c.fy;
    this.el.style.left = (p.l + p.w * fx) + 'px'; this.el.style.top = (p.t + p.h * fy) + 'px';
    this.el.classList.toggle('free', !!c.move);
  },
  reset() { store.del('ball'); this.place(); },
  show(on) { if (this.el) this.el.classList.toggle('show', !!on && this.cfg().show); }
};
window.__insets = (top, bottom) => {
  const r = document.documentElement.style;
  r.setProperty('--st', Math.max(0, top) + 'px'); r.setProperty('--sb', Math.max(0, bottom) + 'px');
  Ball.inset = { top: Math.max(0, top), bottom: Math.max(0, bottom) }; Ball.place();
};

/* ---------- emoji: recents + search ---------- */
const Emo = {
  recent() { return store.get('emo_recent', []); },
  add(e) { const l = [e, ...this.recent().filter((x) => x !== e)].slice(0, 36); store.set('emo_recent', l); },
  search(q) {
    q = q.trim().toLowerCase(); if (!q) return [];
    const out = [];
    for (const k in EMOJI_NAMES) { if (EMOJI_NAMES[k].includes(q)) out.push(k); if (out.length >= 120) break; }
    return out;
  }
};

/* ---------- WhatsApp style text: *bold* _italic_ ~strike~ `mono` + links ---------- */
function renderText(str) {
  const out = []; let last = 0;
  const re = /(https?:\/\/[^\s<]+)|\*([^*\n]+)\*|_([^_\n]+)_|~([^~\n]+)~|`([^`\n]+)`/g;
  let m;
  while ((m = re.exec(str))) {
    if (m.index > last) out.push(str.slice(last, m.index));
    if (m[1]) { const u = m[1]; out.push(h('a', { class: 'lk', onclick: (e) => { e.stopPropagation(); if (nat && nat.open) nat.open(u); else window.open(u, '_blank'); } }, u)); }
    else if (m[2]) out.push(h('b', null, m[2]));
    else if (m[3]) out.push(h('i', null, m[3]));
    else if (m[4]) out.push(h('s', null, m[4]));
    else out.push(h('code', null, m[5]));
    last = m.index + m[0].length;
  }
  if (last < str.length) out.push(str.slice(last));
  return out;
}

/* ---------- encrypted backup of contacts, settings and chat history ---------- */
async function backupKey(pw, salt) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 250000 }, k, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function makeBackup() {
  let pw;
  for (;;) {
    const v = await ask(t('backup_create'), [{ label: t('backup_pw'), pw: true, hint: t('backup_pw_hint') }, { label: t('f_pw2'), pw: true }], t('backup_make'), t('backup_text'));
    if (!v) return;
    if (v[0].length < 6) { toast(t('e_backup_short')); continue; }
    if (v[0] !== v[1]) { toast(t('e_pw_mismatch')); continue; }
    pw = v[0]; break;
  }
  const out = { v: 1, at: Date.now(), me: { id: S.me.id, username: S.me.username, full_name: S.me.full_name, about: S.me.about },
    contacts: [...S.contacts.entries()].map(([id, c]) => ({ id, name: c.name, username: c.username })),
    settings: { theme: Theme.get(), lang: S.lang, ball: store.get('ball', null), autolock: S.autoLock, recents: store.get('recents', 1) }, chats: [] };
  let total = 0;
  const chats = [...S.chats.values()];
  for (let i = 0; i < chats.length; i++) {
    const c = chats[i]; toast(t('backup_progress', { n: i + 1, m: chats.length }));
    const msgs = []; let before = 0;
    for (let page = 0; page < 40; page++) {
      let r;
      try { r = await api('/api/chats/' + c.id + '/messages?limit=100&before=' + before); } catch (e) { break; }
      await decryptAll(r.msgs);
      msgs.unshift(...r.msgs);
      if (!r.more || !r.msgs.length) break;
      before = r.msgs[0].at;
    }
    total += msgs.length;
    out.chats.push({ id: c.id, type: c.type, title: chatTitle(c), members: c.members.map((m) => displayName(m.id)),
      messages: msgs.filter((m) => m.type !== 'sys').map((m) => ({ at: m.at, from: displayName(m.sid), type: m.type, text: m.del ? '' : m.body, file: m.media && m.media.name ? m.media.name : undefined, deleted: !!m.del })) });
  }
  const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await backupKey(pw, salt), new TextEncoder().encode(JSON.stringify(out))));
  const magic = new TextEncoder().encode('CBK1');
  const file = new Uint8Array(4 + 16 + 12 + ct.length); file.set(magic, 0); file.set(salt, 4); file.set(iv, 20); file.set(ct, 32);
  const name = 'backup-' + new Date().toISOString().slice(0, 10) + '.cbk';
  if (nat && nat.save) { const ok = nat.save(name, 'application/octet-stream', E2E.b64(file)); toast(ok ? t('backup_done', { n: total }) : t('e_generic')); }
  else { const a = h('a', { href: URL.createObjectURL(new Blob([file])), download: name }); document.body.append(a); a.click(); a.remove(); toast(t('backup_done', { n: total })); }
  return file;
}
async function restoreBackup(file) {
  const buf = new Uint8Array(await file.arrayBuffer());
  if (new TextDecoder().decode(buf.subarray(0, 4)) !== 'CBK1') return toast(t('e_backup_bad'));
  const v = await ask(t('backup_restore'), [{ label: t('backup_pw'), pw: true }], t('backup_restore_go'));
  if (!v) return;
  let data;
  try { data = JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: buf.subarray(20, 32) }, await backupKey(v[0], buf.subarray(4, 20)), buf.subarray(32)))); }
  catch (e) { return toast(t('e_backup_pw')); }
  let n = 0;
  for (const c of data.contacts || []) { try { await api('/api/contacts', { body: { user_id: c.id, name: c.name }, quiet: true }); n++; } catch (e) { /* user no longer available */ } }
  const st = data.settings || {};
  if (st.theme) store.set('theme', st.theme);
  if (st.ball) store.set('ball', st.ball);
  if (st.lang) setLang(st.lang);
  Theme.apply(); await loadContacts();
  toast(t('backup_restored', { n }));
}
