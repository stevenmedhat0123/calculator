'use strict';
/* ---------- tiny DOM helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
function add(el, kids) {
  for (const k of kids) {
    if (k == null || k === false) continue;
    if (Array.isArray(k)) add(el, k);
    else el.appendChild(k instanceof Node ? k : document.createTextNode(String(k)));
  }
}
/* make append/replaceChildren tolerant of false/null/arrays (conditional children) */
Element.prototype.append = function (...k) { add(this, k); };
Element.prototype.replaceChildren = function (...k) { this.textContent = ''; add(this, k); };
function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  if (props) {
    for (const k in props) {
      const v = props[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'html') el.innerHTML = v;
      else if (k in el) { try { el[k] = v; } catch (e) { el.setAttribute(k, v); } }
      else el.setAttribute(k, v === true ? '' : v);
    }
  }
  add(el, kids);
  return el;
}
const ICONS = {
  back: 'M15 18l-6-6 6-6', fwd: 'M9 18l6-6-6-6', close: 'M18 6L6 18M6 6l12 12', send: 'M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z',
  mic: 'M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3zM19 10v2a7 7 0 0 1-14 0v-2M12 19v3',
  clip: 'M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48',
  smile: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.35-4.35',
  pen: 'M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z', more: 'M12 5h.01M12 12h.01M12 19h.01',
  lock: 'M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4',
  calc: 'M5 2h14a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1zM8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h.01M12 19h.01M16 19h.01',
  plus: 'M12 5v14M5 12h14',
  image: 'M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zM8.5 10a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM21 15l-5-5L5 21',
  video: 'M23 7l-7 5 7 5V7zM3 5h11a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z',
  file: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6',
  trash: 'M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6',
  reply: 'M9 17l-5-5 5-5M4 12h11a5 5 0 0 1 5 5v2',
  copy: 'M9 9h11v11H9zM5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1',
  info: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 16v-4M12 8h.01',
  mute: 'M13.73 21a2 2 0 0 1-3.46 0M18.63 13A17.9 17.9 0 0 1 18 8M6.26 6.26A5.86 5.86 0 0 0 6 8c0 7-3 9-3 9h14M18 8a6 6 0 0 0-9.33-5M1 1l22 22',
  ban: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM4.93 4.93l14.14 14.14',
  users: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
  user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  sliders: 'M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6',
  download: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
  play: 'M6 3l14 9-14 9V3z', pause: 'M6 4h4v16H6zM14 4h4v16h-4z',
  clock: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z', share: 'M15 17l5-5-5-5M20 12H9a5 5 0 0 0-5 5v2',
  check: 'M20 6L9 17l-5-5', up: 'M12 19V5M5 12l7-7 7 7',
  globe: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20',
  eye: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  eyeoff: 'M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19M1 1l22 22',
  chat: 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z', crown: 'M2 8l5 4 5-8 5 8 5-4-2 11H4z',
  star: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z'
};
function ic(name, size = 22, extra) {
  const f = name === 'play' || name === 'star';
  const sw = name === 'more' ? 3 : 2;
  return h('span', {
    class: 'ic' + (extra ? ' ' + extra : ''), style: { width: size + 'px', height: size + 'px' },
    html: '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" fill="' + (f ? 'currentColor' : 'none') +
      '" stroke="currentColor" stroke-width="' + sw + '" stroke-linecap="round" stroke-linejoin="round"><path d="' + ICONS[name] + '"/></svg>'
  });
}
const STAR_SVG = '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="' + ICONS.star + '"/></svg>';

/* ---------- storage & state ---------- */
const store = {
  get(k, d) { try { const v = localStorage.getItem('c_' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('c_' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
  del(k) { try { localStorage.removeItem('c_' + k); } catch (e) { /* ignore */ } }
};
const S = {
  lang: store.get('lang', (navigator.language || '').toLowerCase().startsWith('ar') ? 'ar' : 'en'),
  token: store.get('token', null), me: null, settings: { allow_screens: false },
  chats: new Map(), msgs: new Map(), hist: new Map(), rc: new Map(), users: new Map(), blocked: new Set(),
  ver: null, openChat: null, active: false, typing: [], seen: [], update: null, lockOpen: false,
  autoLock: store.get('autolock', true)
};
const nat = window.Android || null;
const NV = {
  secure(on) { try { nat && nat.secure(!!on); } catch (e) { /* ignore */ } },
  version() { try { return nat ? nat.version() : '0.0.0'; } catch (e) { return '0.0.0'; } }
};
function serverUrl() {
  const o = store.get('server', '');
  const c = (window.CFG && window.CFG.server) || '';
  return String(o || (c.startsWith('http') ? c : '')).replace(/\/+$/, '');
}

/* ---------- i18n ---------- */
function t(k, v) {
  let s = (I18N[S.lang] && I18N[S.lang][k]) || I18N.en[k] || k;
  if (v) for (const x in v) s = s.split('{' + x + '}').join(v[x]);
  return s;
}
function setLang(l) {
  S.lang = l; store.set('lang', l);
  document.documentElement.lang = l; document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
}
const loc = () => (S.lang === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB');
const fmtTime = (ts) => new Date(ts).toLocaleTimeString(loc(), { hour: 'numeric', minute: '2-digit' });
const fmtDate = (ts) => new Date(ts).toLocaleDateString(loc(), { day: 'numeric', month: 'short', year: 'numeric' });
function fmtDay(ts) {
  const d = new Date(ts), n = new Date();
  const a = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const b = new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
  const diff = Math.round((b - a) / 864e5);
  if (diff === 0) return t('today');
  if (diff === 1) return t('yesterday');
  if (diff < 7) return d.toLocaleDateString(loc(), { weekday: 'long' });
  return fmtDate(ts);
}
const fmtList = (ts) => {
  const diff = Math.round((new Date(new Date().toDateString()) - new Date(new Date(ts).toDateString())) / 864e5);
  if (diff === 0) return fmtTime(ts);
  if (diff === 1) return t('yesterday');
  return new Date(ts).toLocaleDateString(loc(), { day: 'numeric', month: 'numeric', year: '2-digit' });
};
const fmtSize = (n) => n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
const fmtDur = (s) => { s = Math.round(s || 0); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const uid = () => (crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '').slice(0, 24) : String(Date.now()) + Math.random().toString(36).slice(2, 10));

/* ---------- api ---------- */
async function api(path, opt = {}) {
  const base = serverUrl();
  if (!base) { const e = new Error('no_server'); e.code = 'no_server'; throw e; }
  const ctl = new AbortController();
  const to = setTimeout(() => ctl.abort(), opt.timeout || 25000);
  const headers = {};
  if (S.token) headers.authorization = 'Bearer ' + S.token;
  let body;
  if (opt.raw !== undefined) body = opt.raw;
  else if (opt.body !== undefined) { body = JSON.stringify(opt.body); headers['content-type'] = 'application/json'; }
  let res;
  try {
    res = await fetch(base + path, { method: opt.method || (body !== undefined ? 'POST' : 'GET'), headers, body, signal: ctl.signal });
  } catch (e) { clearTimeout(to); const x = new Error('network'); x.code = 'network'; throw x; }
  clearTimeout(to);
  if (opt.text) { if (!res.ok) { const x = new Error('http'); x.code = 'http_' + res.status; throw x; } return res.text(); }
  let j = {};
  try { j = await res.json(); } catch (e) { /* ignore */ }
  if (!res.ok) {
    const x = new Error(j.error || 'http_' + res.status); x.code = j.error || 'http_' + res.status; x.status = res.status; x.detail = j.detail;
    if (res.status === 401 && S.token && !opt.quiet) App.sessionExpired();
    else if (res.status === 403 && (j.error === 'need_code' || j.error === 'blocked') && !opt.quiet) App.accessChanged(j.error);
    throw x;
  }
  return j;
}
const errText = (e) => {
  const k = 'e_' + (e && e.code);
  return I18N.en[k] ? t(k) : t('e_generic') + (e && e.detail ? ' (' + e.detail + ')' : '');
};

/* ---------- UI: toast / dialogs ---------- */
let toastT;
function toast(msg) {
  const el = $('#toast'); el.textContent = msg; el.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2400);
}
function overlay(content, opts = {}) {
  const ov = h('div', { class: 'ov' + (opts.center ? ' center' : '') });
  const close = (v) => { ov.classList.add('out'); setTimeout(() => ov.remove(), 160); if (opts.onclose) opts.onclose(v); };
  ov.addEventListener('click', (e) => { if (e.target === ov && !opts.sticky) close(null); });
  ov.append(content);
  document.body.append(ov);
  ov._close = close;
  return { ov, close };
}
function dialog({ title, text, ok, cancel, danger, body }) {
  return new Promise((res) => {
    let o;
    const done = (v) => { res(v); o.close(); };
    const card = h('div', { class: 'dlg' }, title && h('h3', null, title), text && h('p', { class: 'muted' }, text), body,
      h('div', { class: 'dlg-b' },
        cancel !== false && h('button', { class: 'btn ghost', onclick: () => done(false) }, cancel || t('cancel')),
        h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), onclick: () => done(true) }, ok || t('ok'))));
    o = overlay(card, { center: true, onclose: () => res(false) });
  });
}
function pwInput(props) {
  const inp = h('input', Object.assign({ type: 'password', autocomplete: 'off', autocapitalize: 'off', spellcheck: false }, props));
  const eye = h('button', { type: 'button', class: 'eye', tabindex: -1, onclick: () => { const s = inp.type === 'password'; inp.type = s ? 'text' : 'password'; eye.replaceChildren(ic(s ? 'eyeoff' : 'eye', 18)); } }, ic('eye', 18));
  return { inp, el: h('div', { class: 'pw' }, inp, eye) };
}
function field(label, input, hint) {
  return h('label', { class: 'fld' }, h('span', { class: 'fl' }, label), input, hint && h('span', { class: 'fh' }, hint));
}
function ask(title, defs, okLabel, text) {
  return new Promise((res) => {
    const inputs = defs.map((d) => {
      if (d.pw) { const p = pwInput({ placeholder: d.placeholder || '', value: d.value || '' }); p.def = d; return p; }
      return { inp: h('input', { type: d.type || 'text', placeholder: d.placeholder || '', value: d.value || '', inputMode: d.mode, maxLength: d.max }), def: d };
    });
    const err = h('div', { class: 'err' });
    let o;
    const go = () => { const vals = inputs.map((i) => i.inp.value); res(vals); o.close(); };
    const card = h('div', { class: 'dlg' }, h('h3', null, title), text && h('p', { class: 'muted' }, text),
      inputs.map((i) => field(i.def.label, i.el || i.inp, i.def.hint)), err,
      h('div', { class: 'dlg-b' }, h('button', { class: 'btn ghost', onclick: () => { o.close(); res(null); } }, t('cancel')),
        h('button', { class: 'btn primary', onclick: go }, okLabel || t('ok'))));
    o = overlay(card, { center: true, onclose: () => res(null) });
    card._err = err; ask.err = (m) => { err.textContent = m; };
    setTimeout(() => inputs[0] && inputs[0].inp.focus(), 100);
  });
}
function sheet(items) {
  return new Promise((res) => {
    let o;
    const list = h('div', { class: 'sheet' }, items.filter(Boolean).map((it) => it.sep ? h('div', { class: 'sep' }) :
      h('button', { class: 'sheet-i' + (it.danger ? ' danger' : ''), onclick: () => { res(it.v); o.close(); } }, it.icon && ic(it.icon, 20), h('span', null, it.label))));
    o = overlay(list, { onclose: () => res(null) });
  });
}

/* ---------- avatars / misc ---------- */
const PAL = ['#e0576b', '#d9822b', '#c9a227', '#3fae6a', '#2f9fb5', '#4f8cf0', '#8b6cf0', '#c05cc9', '#e0607e', '#5b8c5a'];
function initials(n) {
  const w = String(n || '?').trim().split(/\s+/);
  return ((w[0] || '?')[0] + (w.length > 1 ? w[1][0] : '')).toUpperCase();
}
function avatar(name, size = 46, group) {
  let hsh = 0; for (const c of String(name || '')) hsh = (hsh * 31 + c.charCodeAt(0)) >>> 0;
  return h('div', { class: 'av', style: { width: size + 'px', height: size + 'px', background: PAL[hsh % PAL.length], fontSize: Math.round(size * 0.38) + 'px' } },
    group ? ic('users', Math.round(size * 0.5)) : initials(name));
}
async function sha256(s) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
}
async function pbk(pw, salt) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: new TextEncoder().encode(salt), iterations: 60000 }, k, 256);
  return [...new Uint8Array(bits)].map((x) => x.toString(16).padStart(2, '0')).join('');
}
async function copyText(s) {
  try { await navigator.clipboard.writeText(s); } catch (e) {
    const ta = h('textarea', { value: s, style: { position: 'fixed', opacity: 0 } }); document.body.append(ta); ta.select();
    try { document.execCommand('copy'); } catch (e2) { /* ignore */ } ta.remove();
  }
  toast(t('copied'));
}
const strongPw = (p) => p.length >= 8 && /[A-Z]/.test(p) && /[a-z]/.test(p) && /[0-9]/.test(p) && /[^A-Za-z0-9]/.test(p);

/* ---------- screens ---------- */
const Nav = {
  stack: [],
  push(el, name) {
    const top = this.stack[this.stack.length - 1];
    el.classList.add('screen', 'enter'); el._name = name;
    $('#root').append(el);
    requestAnimationFrame(() => el.classList.remove('enter'));
    if (top) top.el.classList.add('under');
    this.stack.push({ el, name });
    return el;
  },
  pop() {
    if (this.stack.length <= 1) return false;
    const { el } = this.stack.pop();
    if (el._leave) el._leave();
    el.classList.add('leave'); setTimeout(() => el.remove(), 200);
    const top = this.stack[this.stack.length - 1];
    if (top) { top.el.classList.remove('under'); if (top.el._show) top.el._show(); }
    return true;
  },
  popTo(n) { while (this.stack.length > n && this.pop()); },
  top() { return this.stack[this.stack.length - 1]; },
  replaceAll(el, name) {
    while (this.stack.length) { const { el: e } = this.stack.pop(); if (e._leave) e._leave(); e.remove(); }
    this.push(el, name);
  }
};
function header(title, opts = {}) {
  return h('div', { class: 'hdr' },
    opts.noBack ? null : h('button', { class: 'ib', onclick: opts.onBack || (() => Nav.pop()) }, ic('back', 24, 'flip')),
    opts.lead, h('div', { class: 'hdr-t' }, typeof title === 'string' ? h('div', { class: 'ttl' }, title) : title),
    opts.actions);
}
const App = {};
