'use strict';
/*
  End-to-end encryption (runs only on the device):
  - Every account has one ECDH P-256 key pair. The private key never leaves the device unencrypted.
  - Passwords are never sent to the server: the server only receives a slow PBKDF2 hash made on the device.
  - The private key is also backed up on the server, but encrypted with a key derived from the password
    (and a second copy from the recovery password). The server cannot open either copy.
  - Each message gets a random AES-256-GCM key. That key is wrapped separately for every member of the chat
    with a key made from ECDH(sender private, member public) + HKDF, so only chat members can read it.
  - Photos, videos, voice notes and files are encrypted in chunks with their own random key before upload.
*/
const E2E = (() => {
  const te = new TextEncoder(), td = new TextDecoder();
  const subtle = crypto.subtle;
  const ECDH = { name: 'ECDH', namedCurve: 'P-256' };
  function b64(u8) { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
  function unb64(s) { const bin = atob(s); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i); return u8; }
  const hex = (buf) => [...new Uint8Array(buf)].map((x) => x.toString(16).padStart(2, '0')).join('');
  const rnd = (n) => crypto.getRandomValues(new Uint8Array(n));
  async function pbkdf2(secret, salt, iters) {
    const k = await subtle.importKey('raw', te.encode(secret), 'PBKDF2', false, ['deriveBits']);
    return subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: te.encode(salt), iterations: iters }, k, 256);
  }
  const st = { id: null, priv: null, pub: '', pubs: new Map(), shared: new Map(), seen: new Map() };

  /* ----- passwords: what the server gets, and what protects the key backup ----- */
  const authHash = async (secret, username, label) => hex(await pbkdf2(secret, 'calc-auth-v1:' + label + ':' + String(username).toLowerCase(), 100000));
  async function wrapKeyOf(secret, username, label) {
    const raw = await pbkdf2(secret, 'calc-wrap-v1:' + label + ':' + String(username).toLowerCase(), 310000);
    return subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt']);
  }
  async function wrapBlob(pkcs8, wk) {
    const iv = rnd(12);
    const ct = new Uint8Array(await subtle.encrypt({ name: 'AES-GCM', iv }, wk, pkcs8));
    return JSON.stringify({ v: 1, i: b64(iv), c: b64(ct) });
  }
  async function unwrapBlob(blob, wk) {
    const o = JSON.parse(blob);
    return new Uint8Array(await subtle.decrypt({ name: 'AES-GCM', iv: unb64(o.i) }, wk, unb64(o.c)));
  }

  /* ----- identity key pair ----- */
  async function newIdentity() {
    const kp = await subtle.generateKey(ECDH, true, ['deriveBits']);
    const pkcs8 = new Uint8Array(await subtle.exportKey('pkcs8', kp.privateKey));
    const pub = b64(new Uint8Array(await subtle.exportKey('raw', kp.publicKey)));
    return { pkcs8, pub };
  }
  async function activate(userId, pkcs8, pub) {
    st.id = userId; st.pub = pub; st.shared.clear();
    st.priv = await subtle.importKey('pkcs8', pkcs8, ECDH, false, ['deriveBits']);
    st.pubs.set(userId, pub);
  }
  async function pubKeyObj(b) { return subtle.importKey('raw', unb64(b), ECDH, false, []); }
  function setPub(id, pk) { if (id && pk) st.pubs.set(id, pk); }
  const hasPub = (id) => !!st.pubs.get(id);
  async function sharedWith(id) {
    const pk = st.pubs.get(id);
    if (!pk) throw new Error('no_key');
    const ck = id + ':' + pk;
    let s = st.shared.get(ck);
    if (!s) { s = new Uint8Array(await subtle.deriveBits({ name: 'ECDH', public: await pubKeyObj(pk) }, st.priv, 256)); st.shared.set(ck, s); }
    return s;
  }
  async function wrapKeyFor(id, salt, senderId, recvId) {
    const base = await subtle.importKey('raw', await sharedWith(id), 'HKDF', false, ['deriveKey']);
    return subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt, info: te.encode('calc-e2e-wrap-v1|' + senderId + '|' + recvId) }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }

  /* ----- messages ----- */
  async function encrypt(chatId, msgId, content, memberIds) {
    const ids = [...new Set([st.id, ...memberIds])];
    const missing = ids.filter((i) => !st.pubs.get(i));
    if (missing.length === ids.length - 1 && ids.length > 1) throw new Error('no_key');
    const mk = rnd(32), iv = rnd(12), salt = rnd(16);
    const key = await subtle.importKey('raw', mk, 'AES-GCM', false, ['encrypt']);
    const ct = new Uint8Array(await subtle.encrypt({ name: 'AES-GCM', iv, additionalData: te.encode(chatId + '|' + msgId) }, key, te.encode(JSON.stringify(content))));
    const k = {};
    for (const id of ids) {
      if (!st.pubs.get(id)) continue;
      const wk = await wrapKeyFor(id, salt, st.id, id);
      const wiv = rnd(12);
      const w = new Uint8Array(await subtle.encrypt({ name: 'AES-GCM', iv: wiv, additionalData: te.encode('w|' + st.id + '|' + id) }, wk, mk));
      const out = new Uint8Array(12 + w.length); out.set(wiv, 0); out.set(w, 12);
      k[id] = b64(out);
    }
    return { payload: JSON.stringify({ v: 1, s: st.id, n: b64(salt), i: b64(iv), c: b64(ct), k }), missing };
  }
  async function decrypt(chatId, msgId, payloadStr) {
    const p = JSON.parse(payloadStr);
    const mine = p.k && p.k[st.id];
    if (!mine) throw new Error('not_for_me');
    const w = unb64(mine);
    const wk = await wrapKeyFor(p.s, unb64(p.n), p.s, st.id);
    const mk = new Uint8Array(await subtle.decrypt({ name: 'AES-GCM', iv: w.subarray(0, 12), additionalData: te.encode('w|' + p.s + '|' + st.id) }, wk, w.subarray(12)));
    const key = await subtle.importKey('raw', mk, 'AES-GCM', false, ['decrypt']);
    const pt = await subtle.decrypt({ name: 'AES-GCM', iv: unb64(p.i), additionalData: te.encode(chatId + '|' + msgId) }, key, unb64(p.c));
    return { sender: p.s, content: JSON.parse(td.decode(pt)) };
  }

  /* ----- media (each chunk: 12 byte IV + AES-GCM ciphertext) ----- */
  const newMediaKey = () => b64(rnd(32));
  async function encChunk(keyB64, u8) {
    const key = await subtle.importKey('raw', unb64(keyB64), 'AES-GCM', false, ['encrypt']);
    const iv = rnd(12);
    const ct = new Uint8Array(await subtle.encrypt({ name: 'AES-GCM', iv }, key, u8));
    const out = new Uint8Array(12 + ct.length); out.set(iv, 0); out.set(ct, 12);
    return out;
  }
  async function decChunk(keyB64, u8) {
    const key = await subtle.importKey('raw', unb64(keyB64), 'AES-GCM', false, ['decrypt']);
    return new Uint8Array(await subtle.decrypt({ name: 'AES-GCM', iv: u8.subarray(0, 12) }, key, u8.subarray(12)));
  }

  /* ----- security code (like WhatsApp "verify security code") ----- */
  async function fingerprint(idA, idB) {
    const a = st.pubs.get(idA) || '', b = st.pubs.get(idB) || '';
    const sorted = [a, b].sort().join('|');
    const d = new Uint8Array(await subtle.digest('SHA-512', te.encode('calc-fp-v1|' + sorted)));
    const groups = [];
    for (let i = 0; i < 12; i++) groups.push(String(((d[i * 3] << 16) | (d[i * 3 + 1] << 8) | d[i * 3 + 2]) % 100000).padStart(5, '0'));
    return groups;
  }

  /* ----- keeping the private key on the device (non-extractable, in IndexedDB) ----- */
  function idb() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('calc-keys', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('k');
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    });
  }
  async function saveLocal(userId) {
    try {
      const db = await idb();
      await new Promise((res, rej) => { const tx = db.transaction('k', 'readwrite'); tx.objectStore('k').put({ priv: st.priv, pub: st.pub }, userId); tx.oncomplete = res; tx.onerror = () => rej(tx.error); });
    } catch (e) { /* storage not available */ }
  }
  async function loadLocal(userId, expectedPub) {
    try {
      const db = await idb();
      const v = await new Promise((res, rej) => { const r = db.transaction('k').objectStore('k').get(userId); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
      if (v && v.priv && (!expectedPub || v.pub === expectedPub)) { st.id = userId; st.priv = v.priv; st.pub = v.pub; st.shared.clear(); st.pubs.set(userId, v.pub); return true; }
    } catch (e) { /* ignore */ }
    return false;
  }
  async function clearLocal() {
    try { const db = await idb(); await new Promise((res) => { const tx = db.transaction('k', 'readwrite'); tx.objectStore('k').clear(); tx.oncomplete = res; tx.onerror = res; }); } catch (e) { /* ignore */ }
    st.id = null; st.priv = null; st.pub = ''; st.pubs.clear(); st.shared.clear();
  }
  const ready = () => !!st.priv;
  return { b64, unb64, hex, authHash, wrapKeyOf, wrapBlob, unwrapBlob, newIdentity, activate, setPub, hasPub, encrypt, decrypt, newMediaKey, encChunk, decChunk, fingerprint, saveLocal, loadLocal, clearLocal, ready, st };
})();
