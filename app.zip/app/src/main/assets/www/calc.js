'use strict';
const Calc = (() => {
  let expr = '', res = null, eqd = false, hist = [], sci = false, el = null;
  const OPS = '+\u2212\u00d7\u00f7^';
  const isOp = (c) => OPS.includes(c);

  /* --- expression evaluation (no eval) --- */
  function evaluate(src) {
    const tk = src.match(/\d*\.?\d+|\d+\.|[+\u2212\u00d7\u00f7^()%\u221a\u03c0e]/g) || [];
    let p = 0;
    const peek = () => tk[p];
    const isStart = (x) => x !== undefined && (/^[\d.]/.test(x) || x === '(' || x === '\u03c0' || x === 'e' || x === '\u221a');
    function primary() {
      const x = tk[p++];
      if (x === undefined) throw new Error('x');
      if (x === '(') { const v = expr_(); if (peek() === ')') p++; return v.v; }
      if (x === '\u03c0') return Math.PI;
      if (x === 'e') return Math.E;
      if (x === '\u221a') { const v = unary(); if (v < 0) throw new Error('x'); return Math.sqrt(v); }
      if (/^[\d.]/.test(x)) return parseFloat(x);
      throw new Error('x');
    }
    function postfix() {
      let v = primary(), pct = false;
      while (peek() === '%') { p++; v /= 100; pct = true; }
      postfix.pct = pct;
      return v;
    }
    function unary() {
      if (peek() === '\u2212') { p++; return -unary(); }
      if (peek() === '+') { p++; return unary(); }
      return postfix();
    }
    function power() {
      const b = unary(), pc = postfix.pct;
      if (peek() === '^') { p++; const e = power(); return { v: Math.pow(b, e), pct: false }; }
      return { v: b, pct: pc };
    }
    function term() {
      let l = power();
      for (;;) {
        const o = peek();
        if (o === '\u00d7') { p++; l = { v: l.v * power().v, pct: false }; }
        else if (o === '\u00f7') { p++; const r = power().v; if (r === 0) throw new Error('div'); l = { v: l.v / r, pct: false }; }
        else if (isStart(o)) l = { v: l.v * power().v, pct: false };
        else break;
      }
      return l;
    }
    function expr_() {
      let l = term();
      for (;;) {
        const o = peek();
        if (o === '+' || o === '\u2212') {
          p++; const r = term();
          const rv = r.pct ? l.v * r.v : r.v;
          l = { v: o === '+' ? l.v + rv : l.v - rv, pct: false };
        } else break;
      }
      return l;
    }
    const out = expr_();
    if (p < tk.length && !(tk[p] === ')')) { /* trailing junk */ }
    return out.v;
  }
  const closeParens = (s) => s + ')'.repeat(Math.max(0, (s.match(/\(/g) || []).length - (s.match(/\)/g) || []).length));
  function calc(s) {
    s = s.replace(/[+\u2212\u00d7\u00f7^]+$/, '');
    if (!s) return null;
    try {
      const v = evaluate(closeParens(s));
      return Number.isFinite(v) ? v : null;
    } catch (e) { return null; }
  }
  function group(n) { return n.replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function fmtNum(v) {
    if (v === null) return '';
    let s = String(Number(v.toPrecision(12)));
    if (/e/.test(s)) { const m = Number(v).toExponential(6).replace(/\.?0+e/, 'e').replace('e+', '\u00d710^'); return m.replace('e', '\u00d710^'); }
    const [i, f] = s.split('.');
    return (i.startsWith('-') ? '\u2212' + group(i.slice(1)) : group(i)) + (f ? '.' + f : '');
  }
  const fmtExpr = (s) => s.replace(/\d+(\.\d*)?/g, (m) => { const [i, f] = m.split('.'); return group(i) + (m.includes('.') ? '.' + (f || '') : ''); });
  const lastNum = () => (expr.match(/[\d.]*$/) || [''])[0];

  async function codeOk(s) {
    const stored = store.get('codeh', null);
    if (!stored) return s === '731905';
    return (await sha256('c:' + s)) === stored;
  }
  async function setCode(s) { store.set('codeh', await sha256('c:' + s)); }

  function press(k) {
    if (k === 'AC') { expr = ''; res = null; eqd = false; return draw(); }
    if (k === 'DEL') { if (eqd) { eqd = false; res = null; } expr = expr.slice(0, -1); return draw(); }
    if (k === '=') return equals();
    if (eqd) {
      if (/^[\d.]$|^00$|^[(\u03c0e\u221a]$/.test(k)) { expr = ''; }
      eqd = false;
    }
    const last = expr.slice(-1);
    if (/^\d$/.test(k) || k === '00') {
      const ln = lastNum();
      if (k === '00') { if (ln === '0') return draw(); if (ln === '') k = '0'; }
      else if (ln === '0') expr = expr.slice(0, -1);
      if (last === '%' || last === ')' || last === '\u03c0' || last === 'e') expr += '\u00d7';
      expr += k;
    } else if (k === '.') {
      const ln = lastNum();
      if (ln.includes('.')) return draw();
      expr += ln === '' ? '0.' : '.';
    } else if (isOp(k)) {
      if (!expr) { if (k === '\u2212') expr = '\u2212'; return draw(); }
      if (isOp(last) || last === '(' && k !== '\u2212') {
        if (last === '(') return draw();
        if (k === '\u2212' && (last === '\u00d7' || last === '\u00f7') ) expr += k;
        else expr = expr.slice(0, -1) + k;
      } else if (last !== '(' || k === '\u2212') expr += k;
    } else if (k === '%') {
      if (/[\d)%\u03c0e]$/.test(expr)) expr += '%';
    } else if (k === '(' || k === '\u221a') {
      if (/[\d)%\u03c0e]$/.test(expr)) expr += '\u00d7';
      expr += k;
    } else if (k === ')') {
      if ((expr.match(/\(/g) || []).length > (expr.match(/\)/g) || []).length && !isOp(last) && last !== '(') expr += ')';
    } else if (k === '\u03c0' || k === 'e') {
      if (/[\d)%\u03c0e]$/.test(expr)) expr += '\u00d7';
      expr += k;
    }
    draw();
  }
  async function equals() {
    if (/^\d{3,16}$/.test(expr) && await codeOk(expr)) { reset(); App.openSecret(); return; }
    const v = calc(expr);
    if (v === null) { if (expr) { el.querySelector('.cmain').classList.add('shake'); setTimeout(() => el.querySelector('.cmain').classList.remove('shake'), 300); } return; }
    hist.unshift({ e: expr, r: fmtNum(v) });
    hist = hist.slice(0, 50);
    res = { e: expr, r: fmtNum(v), raw: String(Number(v.toPrecision(12))) };
    eqd = true;
    draw();
    expr = res.raw.includes('e') ? '' : res.raw.replace('-', '\u2212');
  }
  function reset() { expr = ''; res = null; eqd = false; if (el) draw(); }

  function draw() {
    if (!el) return;
    const main = el.querySelector('.cmain'), sub = el.querySelector('.csub');
    let m, s;
    if (eqd && res) { m = res.r; s = fmtExpr(res.e); }
    else {
      m = fmtExpr(expr) || '0';
      const hasOp = /[+\u2212\u00d7\u00f7^%\u221a]/.test(expr.replace(/^\u2212/, ''));
      const v = hasOp ? calc(expr) : null;
      s = v === null ? '' : fmtNum(v);
    }
    main.textContent = m; sub.textContent = s;
    const n = m.length;
    main.style.fontSize = (n <= 8 ? 54 : n <= 10 ? 46 : n <= 13 ? 38 : n <= 17 ? 30 : 24) + 'px';
    sub.classList.toggle('big', false);
    sub.style.order = eqd ? '-1' : '0';
  }
  function showHistory() {
    let o;
    const list = h('div', { class: 'hist' }, hist.length ? hist.map((x) => h('button', { class: 'hrow', onclick: () => { expr = x.r.replace(/,/g, '').replace('\u2212', '-').replace('-', '\u2212'); eqd = false; res = null; o.close(); draw(); } },
      h('div', { class: 'he' }, fmtExpr(x.e)), h('div', { class: 'hr' }, x.r))) : h('div', { class: 'hempty' }, 'No history'),
      hist.length ? h('button', { class: 'hclr', onclick: () => { hist = []; o.close(); } }, 'Clear history') : null);
    o = overlay(list);
  }
  const SVG = (d) => '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg>';
  function build() {
    const key = (k, label, cls) => h('button', { class: 'ck ' + (cls || ''), 'data-k': k, onclick: () => press(k) }, label || k);
    const sciRow = h('div', { class: 'sci' }, ['(', ')', '\u221a', '\u03c0', 'e', '^'].map((k) => key(k, k, 'sk')));
    el = h('div', { class: 'calc' },
      h('div', { class: 'ctop' },
        h('button', { class: 'cib', html: SVG('<path d="M3 3l7 7M10 5v5H5M21 21l-7-7M14 19v-5h5"/>') , onclick: () => press('AC') }),
        h('span', { class: 'sp' }),
        h('button', { class: 'cib', html: '<span class="sciic">\u221a\u03c0<br>e=</span>', onclick: () => { sci = !sci; el.classList.toggle('sci-on', sci); } }),
        h('button', { class: 'cib', html: SVG('<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>'), onclick: showHistory }),
        h('button', { class: 'cib', html: SVG('<path d="M12 5h.01M12 12h.01M12 19h.01" stroke-width="3"/>'), onclick: () => { hist = []; toast('History cleared'); } })),
      h('div', { class: 'cdisp' }, h('div', { class: 'cmain' }, '0'), h('div', { class: 'csub' })),
      sciRow,
      h('div', { class: 'cpad' },
        key('AC', 'AC', 'fn bold'), key('%', '%', 'fn'), key('DEL', null, 'fn'), key('\u00f7', '\u00f7', 'fn'),
        key('7'), key('8'), key('9'), key('\u00d7', '\u00d7', 'fn'),
        key('4'), key('5'), key('6'), key('\u2212', '\u2212', 'fn'),
        key('1'), key('2'), key('3'), key('+', '+', 'fn'),
        key('00'), key('0'), key('.', '.'), key('=', '=', 'eq')));
    el.querySelector('[data-k=DEL]').innerHTML = SVG('<path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM18 9l-6 6M12 9l6 6"/>');
    draw();
    return el;
  }
  return { build, reset, setCode, codeOk };
})();
