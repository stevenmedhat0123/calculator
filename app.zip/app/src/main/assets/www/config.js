window.CFG = { server: "__SERVER__", repo: "__REPO__" };
