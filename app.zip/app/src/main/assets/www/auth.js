'use strict';
function authScreen(mode0) {
  let mode = mode0 || 'login';
  const el = h('div', { class: 'auth' });
  const body = h('div', { class: 'auth-b' });
  const hint = (ok, txt) => h('span', { class: 'rule' + (ok ? ' ok' : '') }, (ok ? '\u2713 ' : '\u2022 ') + txt);

  function render() {
    body.replaceChildren();
    const err = h('div', { class: 'err' });
    const name = h('input', { placeholder: t('f_name_ph'), autocomplete: 'off', value: store.get('last_name', '') });
    const phone = h('input', { type: 'tel', inputMode: 'tel', placeholder: '01xxxxxxxxx', autocomplete: 'off', value: store.get('last_phone', '') });
    const user = h('input', { placeholder: 'username', autocapitalize: 'off', autocomplete: 'off', spellcheck: false, value: store.get('last_user', '') });
    const pw = pwInput({ placeholder: '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022' });
    const pw2 = pwInput({ placeholder: '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022' });
    const rec = pwInput({ placeholder: t('f_rec_ph') });
    const rec2 = pwInput({ placeholder: t('f_rec_ph') });
    const rules = h('div', { class: 'rules' });
    const updRules = () => {
      const p = pw.inp.value;
      rules.replaceChildren(hint(p.length >= 8, '8+'), hint(/[A-Z]/.test(p), 'A-Z'), hint(/[a-z]/.test(p), 'a-z'), hint(/[0-9]/.test(p), '0-9'), hint(/[^A-Za-z0-9]/.test(p), '#@!'));
    };
    pw.inp.addEventListener('input', updRules); updRules();
    const btn = h('button', { class: 'btn primary wide' }, mode === 'login' ? t('sign_in') : mode === 'register' ? t('create_account') : t('reset_password'));
    const fail = (m) => { err.textContent = m; };
    const go = async () => {
      err.textContent = '';
      const nm = name.value.trim().replace(/\s+/g, ' '), ph = phone.value.trim(), un = user.value.trim().toLowerCase();
      if (nm.split(' ').length < 4) return fail(t('e_bad_name'));
      if (!/^\+?[0-9\u0660-\u0669 \-]{8,18}$/.test(ph)) return fail(t('e_bad_phone'));
      if (!/^[a-z0-9_.]{3,24}$/.test(un)) return fail(t('e_bad_username'));
      let payload, path;
      if (mode === 'login') {
        if (!pw.inp.value) return fail(t('e_bad_login'));
        path = '/api/login'; payload = { full_name: nm, phone: ph, username: un, password: pw.inp.value };
      } else if (mode === 'register') {
        if (!strongPw(pw.inp.value)) return fail(t('e_weak_password'));
        if (pw.inp.value !== pw2.inp.value) return fail(t('e_pw_mismatch'));
        if (rec.inp.value.length < 4) return fail(t('e_weak_recovery'));
        if (rec.inp.value !== rec2.inp.value) return fail(t('e_rec_mismatch'));
        path = '/api/register'; payload = { full_name: nm, phone: ph, username: un, password: pw.inp.value, recovery: rec.inp.value };
      } else {
        if (rec.inp.value.length < 4) return fail(t('e_bad_recovery'));
        if (!strongPw(pw.inp.value)) return fail(t('e_weak_password'));
        if (pw.inp.value !== pw2.inp.value) return fail(t('e_pw_mismatch'));
        path = '/api/recover'; payload = { full_name: nm, phone: ph, username: un, recovery: rec.inp.value, new_password: pw.inp.value };
      }
      btn.disabled = true; btn.classList.add('busy');
      try {
        const r = await api(path, { body: payload, quiet: true });
        store.set('last_name', nm); store.set('last_phone', ph); store.set('last_user', un);
        if (mode === 'recover') { toast(t('pw_reset_done')); mode = 'login'; return render(); }
        App.setSession(r);
        if (mode === 'register' && r.user.role === 'owner') toast(t('you_are_owner'));
        App.enter();
      } catch (e) { fail(errText(e)); btn.disabled = false; btn.classList.remove('busy'); }
    };
    btn.addEventListener('click', go);
    const tabs = h('div', { class: 'seg' },
      h('button', { class: mode === 'login' ? 'on' : '', onclick: () => { mode = 'login'; render(); } }, t('sign_in')),
      h('button', { class: mode === 'register' ? 'on' : '', onclick: () => { mode = 'register'; render(); } }, t('create_account')));
    body.append(mode === 'recover' ? h('h2', { class: 'auth-h' }, t('reset_password')) : tabs,
      mode === 'recover' && h('p', { class: 'muted' }, t('recover_hint')),
      field(t('f_name'), name, mode === 'register' ? t('f_name_hint') : null), field(t('f_phone'), phone), field(t('f_user'), user),
      mode === 'recover' && field(t('f_rec'), rec.el),
      mode !== 'recover' ? field(t('f_pw'), pw.el) : field(t('f_newpw'), pw.el),
      mode !== 'login' && rules,
      mode !== 'login' && field(t('f_pw2'), pw2.el),
      mode === 'register' && [field(t('f_rec'), rec.el, t('f_rec_hint')), field(t('f_rec2'), rec2.el)],
      err, btn,
      mode === 'login' && h('button', { class: 'lnk', onclick: () => { mode = 'recover'; render(); } }, t('forgot')),
      mode === 'recover' && h('button', { class: 'lnk', onclick: () => { mode = 'login'; render(); } }, t('back_to_login')));
  }
  const langBtn = h('button', { class: 'lnk sm', onclick: () => { setLang(S.lang === 'ar' ? 'en' : 'ar'); render(); langBtn.textContent = S.lang === 'ar' ? 'English' : '\u0627\u0644\u0639\u0631\u0628\u064a\u0629'; } }, S.lang === 'ar' ? 'English' : '\u0627\u0644\u0639\u0631\u0628\u064a\u0629');
  const srvBtn = h('button', { class: 'lnk sm', onclick: async () => {
    const v = await ask(t('server'), [{ label: t('server_url'), value: serverUrl(), placeholder: 'https://...workers.dev', type: 'url' }]);
    if (v) { store.set('server', v[0].trim()); toast(t('saved')); }
  } }, t('server'));
  el.append(h('div', { class: 'auth-top' }, h('div', { class: 'logo' }, ic('chat', 30)), h('div', null, h('h1', null, t('app_title')), h('p', { class: 'muted' }, t('app_sub')))), body, h('div', { class: 'auth-f' }, langBtn, srvBtn));
  render();
  return el;
}

function pendingScreen(kind) {
  const el = h('div', { class: 'auth' });
  const err = h('div', { class: 'err' });
  const code = h('input', { placeholder: t('code_ph'), autocapitalize: 'off', autocomplete: 'off', spellcheck: false, class: 'mono' });
  const btn = h('button', { class: 'btn primary wide' }, t('activate'));
  btn.addEventListener('click', async () => {
    err.textContent = ''; if (!code.value.trim()) return;
    btn.disabled = true;
    try { const r = await api('/api/redeem', { body: { code: code.value.trim() }, quiet: true }); S.me = r.user; toast(t('activated')); App.enter(); }
    catch (e) { err.textContent = errText(e); btn.disabled = false; }
  });
  const blocked = kind === 'blocked';
  const ended = S.me && S.me.status === 'active';
  el.append(h('div', { class: 'auth-top' }, h('div', { class: 'logo' }, ic(blocked ? 'ban' : 'lock', 30)),
    h('div', null, h('h1', null, blocked ? t('blocked_title') : ended ? t('ended_title') : t('need_title')), h('p', { class: 'muted' }, blocked ? t('blocked_text') : t('need_text')))),
    h('div', { class: 'auth-b' }, !blocked && [field(t('code'), code), err, btn,
      h('button', { class: 'btn ghost wide', onclick: () => Nav.push(ownerChatScreen(), 'ownerchat') }, ic('chat', 18), t('contact_owner'))],
      h('button', { class: 'lnk', onclick: () => App.signOut() }, t('sign_out'))));
  return el;
}

function ownerChatScreen() {
  const el = h('div', { class: 'chat oc' });
  const list = h('div', { class: 'msgs' });
  let msgs = [], rcs = {}, timer, ownerName = t('owner');
  const sending = new Set();
  const draw = () => {
    const near = list.scrollHeight - list.scrollTop - list.clientHeight < 80;
    list.replaceChildren(...msgs.map((m) => {
      const mine = m.sid === S.me.id;
      return h('div', { class: 'row ' + (mine ? 'out' : 'in') }, h('div', { class: 'bub ' + (mine ? 'out' : 'in') }, h('div', { class: 'txt' }, m.body),
        h('div', { class: 'meta' }, fmtTime(m.at), mine && tickEl(rcs[m.id] || [], sending.has(m.id)))));
    }));
    if (!msgs.length) list.append(h('div', { class: 'empty' }, t('oc_empty')));
    if (near) list.scrollTop = list.scrollHeight;
  };
  const load = async () => {
    try {
      const r = await api('/api/owner-chat', { quiet: true });
      ownerName = r.owner.full_name; msgs = r.msgs; rcs = {};
      for (const x of r.rcs) (rcs[x[0]] = rcs[x[0]] || []).push([x[1], x[2], x[3]]);
      title.textContent = ownerName; draw();
    } catch (e) { /* ignore */ }
  };
  const title = h('div', { class: 'ttl' }, t('owner'));
  const input = h('textarea', { rows: 1, placeholder: t('type_msg'), maxLength: 600 });
  const send = async () => {
    const text = input.value.trim(); if (!text) return;
    input.value = ''; input.style.height = '';
    const id = uid(); msgs.push({ id, sid: S.me.id, body: text, at: Date.now() }); sending.add(id); draw(); list.scrollTop = list.scrollHeight;
    try { await api('/api/owner-chat', { body: { text, id }, quiet: true }); sending.delete(id); await load(); }
    catch (e) { toast(errText(e)); }
  };
  input.addEventListener('input', () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 110) + 'px'; });
  el.append(header(h('div', null, title, h('div', { class: 'sub' }, t('oc_sub')))), list,
    h('div', { class: 'composer' }, h('div', { class: 'cbox' }, input), h('button', { class: 'sendb', onclick: send }, ic('send', 20, 'flip'))));
  el._show = () => {}; el._leave = () => clearInterval(timer);
  load(); timer = setInterval(() => { if (!document.hidden) load(); }, 3500);
  return el;
}
