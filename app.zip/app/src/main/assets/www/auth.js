'use strict';
/* Passwords never leave the phone: the server only gets a slow hash made here (see e2e.js). */
const newSalt = () => E2E.hex(crypto.getRandomValues(new Uint8Array(16)));
async function getSalt(username) {
  const r = await api('/api/salt?username=' + encodeURIComponent(username), { quiet: true });
  return r.ks;
}
async function makeKeyMaterial(pw, rec, un) {
  const idn = await E2E.newIdentity();
  const [a, r, wp, wr] = await Promise.all([E2E.authHash(pw, un, 'pw'), E2E.authHash(rec, un, 'rec'), E2E.wrapKeyOf(pw, un, 'pw'), E2E.wrapKeyOf(rec, un, 'rec')]);
  return { idn, password: a, recovery: r, pubkey: idn.pub, key_blob: await E2E.wrapBlob(idn.pkcs8, wp), key_blob_rec: await E2E.wrapBlob(idn.pkcs8, wr) };
}
async function unlockFromBlob(blob, pw, un, userId, pub) {
  let pkcs8;
  try { pkcs8 = await E2E.unwrapBlob(blob, await E2E.wrapKeyOf(pw, un, 'pw')); }
  catch (e) { const x = new Error('key_restore'); x.code = 'key_restore'; throw x; }
  await E2E.activate(userId, pkcs8, pub); await E2E.saveLocal(userId);
}

function authScreen(mode0) {
  let mode = mode0 || 'login';
  const el = h('div', { class: 'auth' });
  const body = h('div', { class: 'auth-b' });
  const hint = (ok, txt) => h('span', { class: 'rule' + (ok ? ' ok' : '') }, (ok ? '\u2713 ' : '\u2022 ') + txt);

  function render() {
    body.replaceChildren();
    const err = h('div', { class: 'err' });
    const name = h('input', { placeholder: t('f_name_ph'), autocomplete: 'off', value: store.get('last_name', '') });
    const phone = h('input', { type: 'tel', inputMode: 'tel', placeholder: '01xxxxxxxxx', autocomplete: 'off', value: store.get('last_phone', '') });
    const user = h('input', { placeholder: 'username', autocapitalize: 'off', autocomplete: 'off', spellcheck: false, value: store.get('last_user', '') });
    const pw = pwInput({ placeholder: '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022' });
    const pw2 = pwInput({ placeholder: '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022' });
    const rec = pwInput({ placeholder: t('f_rec_ph') });
    const rec2 = pwInput({ placeholder: t('f_rec_ph') });
    const rules = h('div', { class: 'rules' });
    const updRules = () => {
      const p = pw.inp.value;
      rules.replaceChildren(hint(p.length >= 8, '8+'), hint(/[A-Z]/.test(p), 'A-Z'), hint(/[a-z]/.test(p), 'a-z'), hint(/[0-9]/.test(p), '0-9'), hint(/[^A-Za-z0-9]/.test(p), '#@!'));
    };
    pw.inp.addEventListener('input', updRules); updRules();
    const label = mode === 'login' ? t('sign_in') : mode === 'register' ? t('create_account') : t('reset_password');
    const btn = h('button', { class: 'btn primary wide' }, label);
    const fail = (m) => { err.textContent = m; };
    const go = async () => {
      err.textContent = '';
      const nm = name.value.trim().replace(/\s+/g, ' '), ph = phone.value.trim(), un = user.value.trim().toLowerCase();
      if (nm.split(' ').length < 4) return fail(t('e_bad_name'));
      if (!/^\+?[0-9\u0660-\u0669 \-]{8,18}$/.test(ph)) return fail(t('e_bad_phone'));
      if (!/^[a-z0-9_.]{3,24}$/.test(un)) return fail(t('e_bad_username'));
      if (mode === 'login' && !pw.inp.value) return fail(t('e_bad_login'));
      if (mode === 'register') {
        if (!strongPw(pw.inp.value)) return fail(t('e_weak_password'));
        if (pw.inp.value !== pw2.inp.value) return fail(t('e_pw_mismatch'));
        if (rec.inp.value.length < 6) return fail(t('e_weak_recovery'));
        if (rec.inp.value !== rec2.inp.value) return fail(t('e_rec_mismatch'));
      }
      if (mode === 'recover') {
        if (rec.inp.value.length < 4) return fail(t('e_bad_recovery'));
        if (!strongPw(pw.inp.value)) return fail(t('e_weak_password'));
        if (pw.inp.value !== pw2.inp.value) return fail(t('e_pw_mismatch'));
      }
      btn.disabled = true; btn.classList.add('busy'); btn.textContent = t('securing');
      const id = { full_name: nm, phone: ph, username: un };
      try {
        if (mode === 'register') {
          const ks = newSalt();
          const k = await makeKeyMaterial(pw.inp.value, rec.inp.value, ks);
          const r = await api('/api/register', { body: { ...id, kdf_salt: ks, password: k.password, recovery: k.recovery, pubkey: k.pubkey, key_blob: k.key_blob, key_blob_rec: k.key_blob_rec }, quiet: true });
          await E2E.activate(r.user.id, k.idn.pkcs8, k.idn.pub); await E2E.saveLocal(r.user.id);
          store.set('last_name', nm); store.set('last_phone', ph); store.set('last_user', un);
          App.setSession(r);
          if (r.user.role === 'owner') toast(t('you_are_owner'));
          return App.enter();
        }
        if (mode === 'login') {
          let r;
          const ks = await getSalt(un);
          try { r = await api('/api/login', { body: { ...id, password: await E2E.authHash(pw.inp.value, ks, 'pw') }, quiet: true }); }
          catch (e) {
            if (!e.legacy) throw e;
            r = await api('/api/login', { body: { ...id, password: pw.inp.value, legacy: true }, quiet: true });
          }
          store.set('last_name', nm); store.set('last_phone', ph); store.set('last_user', un);
          App.setSession(r);
          if (r.upgrade) { S.upgradePw = pw.inp.value; return App.enter(); }
          await unlockFromBlob(r.key_blob, pw.inp.value, r.user.kdf, r.user.id, r.user.pubkey);
          return App.enter();
        }
        let s;
        const ks0 = await getSalt(un);
        try { s = await api('/api/recover/start', { body: { ...id, recovery: await E2E.authHash(rec.inp.value, ks0, 'rec') }, quiet: true }); }
        catch (e) { if (!e.legacy) throw e; s = await api('/api/recover/start', { body: { ...id, recovery: rec.inp.value }, quiet: true }); }
        const newPw = pw.inp.value;
        let fin;
        if (s.legacy) {
          const ks1 = newSalt();
          const k = await makeKeyMaterial(newPw, rec.inp.value, ks1);
          fin = { ticket: s.ticket, kdf_salt: ks1, password: k.password, recovery: k.recovery, pubkey: k.pubkey, key_blob: k.key_blob, key_blob_rec: k.key_blob_rec };
        } else {
          let pkcs8;
          try { pkcs8 = await E2E.unwrapBlob(s.key_blob_rec, await E2E.wrapKeyOf(rec.inp.value, ks0, 'rec')); } catch (e) { const x = new Error('key_restore'); x.code = 'key_restore'; throw x; }
          fin = { ticket: s.ticket, password: await E2E.authHash(newPw, ks0, 'pw'), key_blob: await E2E.wrapBlob(pkcs8, await E2E.wrapKeyOf(newPw, ks0, 'pw')) };
        }
        await api('/api/recover/finish', { body: fin, quiet: true });
        store.set('last_name', nm); store.set('last_phone', ph); store.set('last_user', un);
        toast(t('pw_reset_done')); mode = 'login'; render();
      } catch (e) { fail(errText(e)); btn.disabled = false; btn.classList.remove('busy'); btn.textContent = label; }
    };
    btn.addEventListener('click', go);
    const tabs = h('div', { class: 'seg' },
      h('button', { class: mode === 'login' ? 'on' : '', onclick: () => { mode = 'login'; render(); } }, t('sign_in')),
      h('button', { class: mode === 'register' ? 'on' : '', onclick: () => { mode = 'register'; render(); } }, t('create_account')));
    body.append(mode === 'recover' ? h('h2', { class: 'auth-h' }, t('reset_password')) : tabs,
      mode === 'recover' && h('p', { class: 'muted' }, t('recover_hint')),
      field(t('f_name'), name, mode === 'register' ? t('f_name_hint') : null), field(t('f_phone'), phone), field(t('f_user'), user),
      mode === 'recover' && field(t('f_rec'), rec.el),
      mode !== 'recover' ? field(t('f_pw'), pw.el) : field(t('f_newpw'), pw.el),
      mode !== 'login' && rules,
      mode !== 'login' && field(t('f_pw2'), pw2.el),
      mode === 'register' && [field(t('f_rec'), rec.el, t('f_rec_hint')), field(t('f_rec2'), rec2.el)],
      err, btn,
      mode === 'login' && h('button', { class: 'lnk', onclick: () => { mode = 'recover'; render(); } }, t('forgot')),
      mode === 'recover' && h('button', { class: 'lnk', onclick: () => { mode = 'login'; render(); } }, t('back_to_login')),
      mode === 'register' && h('p', { class: 'muted s center' }, ic('lock', 14), ' ', t('e2e_note')));
  }
  const langBtn = h('button', { class: 'lnk sm', onclick: () => { setLang(S.lang === 'ar' ? 'en' : 'ar'); render(); langBtn.textContent = S.lang === 'ar' ? 'English' : '\u0627\u0644\u0639\u0631\u0628\u064a\u0629'; } }, S.lang === 'ar' ? 'English' : '\u0627\u0644\u0639\u0631\u0628\u064a\u0629');
  const srvBtn = h('button', { class: 'lnk sm', onclick: async () => {
    const v = await ask(t('server'), [{ label: t('server_url'), value: serverUrl(), placeholder: 'https://...workers.dev', type: 'url' }]);
    if (v) { store.set('server', v[0].trim()); toast(t('saved')); }
  } }, t('server'));
  const diagBtn = h('button', { class: 'lnk sm', onclick: async () => {
    try {
      const r = await fetch(serverUrl() + '/api/health'); const j = await r.json();
      dialog({ title: t('diag'), text: (j.ok ? t('diag_ok') : t('diag_bad')) + '\n' + JSON.stringify(j.tables ? Object.fromEntries(Object.entries(j.tables).filter(([, v]) => v.error || v.missing)) : j).slice(0, 500), ok: t('ok'), cancel: false });
    } catch (e) { toast(t('e_network')); }
  } }, t('diag'));
  el.append(h('div', { class: 'auth-top' }, h('div', { class: 'logo' }, ic('chat', 30)), h('div', null, h('h1', null, t('app_title')), h('p', { class: 'muted' }, t('app_sub')))), body, h('div', { class: 'auth-f' }, langBtn, srvBtn, diagBtn));
  render();
  return el;
}

/* Accounts made before encryption existed must add it once. */
function upgradeScreen() {
  const el = h('div', { class: 'auth' });
  const err = h('div', { class: 'err' });
  const pw = pwInput({ value: S.upgradePw || '' }), rec = pwInput({});
  const btn = h('button', { class: 'btn primary wide' }, t('upgrade_go'));
  btn.addEventListener('click', async () => {
    err.textContent = '';
    if (!pw.inp.value || !rec.inp.value) return (err.textContent = t('e_bad_login'));
    btn.disabled = true; btn.textContent = t('securing');
    try {
      const ks = newSalt();
      const k = await makeKeyMaterial(pw.inp.value, rec.inp.value, ks);
      const s1 = await api('/api/auth/upgrade', { body: { step: 1, current: pw.inp.value }, quiet: true });
      const r = await api('/api/auth/upgrade', { body: { step: 2, ticket: s1.ticket, kdf_salt: ks, rec_current: rec.inp.value, password: k.password, recovery: k.recovery, pubkey: k.pubkey, key_blob: k.key_blob, key_blob_rec: k.key_blob_rec }, quiet: true });
      await E2E.activate(S.me.id, k.idn.pkcs8, k.idn.pub); await E2E.saveLocal(S.me.id);
      S.me = r.user; S.upgradePw = null; toast(t('upgrade_done')); App.enter();
    } catch (e) { err.textContent = errText(e); btn.disabled = false; btn.textContent = t('upgrade_go'); }
  });
  el.append(h('div', { class: 'auth-top' }, h('div', { class: 'logo' }, ic('shield', 30)), h('div', null, h('h1', null, t('upgrade_title')), h('p', { class: 'muted' }, t('upgrade_text')))),
    h('div', { class: 'auth-b' }, field(t('f_pw'), pw.el), field(t('cur_rec'), rec.el), err, btn, h('button', { class: 'lnk', onclick: () => App.signOut() }, t('sign_out'))));
  return el;
}

/* Logged in, but this phone does not have the private key (for example storage was cleared). */
function unlockScreen() {
  const el = h('div', { class: 'auth' });
  const err = h('div', { class: 'err' });
  const pw = pwInput({});
  const btn = h('button', { class: 'btn primary wide' }, t('unlock_go'));
  btn.addEventListener('click', async () => {
    err.textContent = ''; btn.disabled = true; btn.textContent = t('securing');
    try {
      const r = await api('/api/me', { quiet: true });
      await unlockFromBlob(r.key_blob, pw.inp.value, r.user.kdf, S.me.id, S.me.pubkey);
      App.enter();
    } catch (e) { err.textContent = e.code === 'key_restore' ? t('e_key_restore') : errText(e); btn.disabled = false; btn.textContent = t('unlock_go'); }
  });
  el.append(h('div', { class: 'auth-top' }, h('div', { class: 'logo' }, ic('lock', 30)), h('div', null, h('h1', null, t('unlock_title')), h('p', { class: 'muted' }, t('unlock_text')))),
    h('div', { class: 'auth-b' }, field(t('f_pw'), pw.el), err, btn, h('button', { class: 'lnk', onclick: () => App.signOut() }, t('sign_out'))));
  return el;
}

function pendingScreen(kind) {
  const el = h('div', { class: 'auth' });
  const err = h('div', { class: 'err' });
  const code = h('input', { placeholder: t('code_ph'), autocapitalize: 'off', autocomplete: 'off', spellcheck: false, class: 'mono' });
  const btn = h('button', { class: 'btn primary wide' }, t('activate'));
  btn.addEventListener('click', async () => {
    err.textContent = ''; if (!code.value.trim()) return;
    btn.disabled = true;
    try { const r = await api('/api/redeem', { body: { code: code.value.trim() }, quiet: true }); S.me = Object.assign(S.me, r.user); toast(t('activated')); App.enter(); }
    catch (e) { err.textContent = errText(e); btn.disabled = false; }
  });
  const blocked = kind === 'blocked';
  const ended = S.me && S.me.status === 'active';
  el.append(h('div', { class: 'auth-top' }, h('div', { class: 'logo' }, ic(blocked ? 'ban' : 'lock', 30)),
    h('div', null, h('h1', null, blocked ? t('blocked_title') : ended ? t('ended_title') : t('need_title')), h('p', { class: 'muted' }, blocked ? t('blocked_text') : t('need_text')))),
    h('div', { class: 'auth-b' }, !blocked && [field(t('code'), code), err, btn,
      h('button', { class: 'btn ghost wide', onclick: () => Nav.push(ownerChatScreen(), 'ownerchat') }, ic('chat', 18), t('contact_owner'))],
      h('button', { class: 'lnk', onclick: () => App.signOut() }, t('sign_out'))));
  return el;
}

function ownerChatScreen() {
  const el = h('div', { class: 'chat oc' });
  const list = h('div', { class: 'msgs' });
  let msgs = [], rcs = {}, timer, owner = null, chatId = null, keep = [];
  const sending = new Set();
  const draw = () => {
    const near = list.scrollHeight - list.scrollTop - list.clientHeight < 80;
    list.replaceChildren(...msgs.map((m) => {
      const mine = m.sid === S.me.id;
      return h('div', { class: 'row ' + (mine ? 'out' : 'in') }, h('div', { class: 'bub ' + (mine ? 'out' : 'in') }, h('div', { class: 'txt' }, m.body),
        h('div', { class: 'meta' }, fmtTime(m.at), mine && tickEl(rcs[m.id] || [], sending.has(m.id)))));
    }));
    if (!msgs.length) list.append(h('div', { class: 'empty' }, ic('lock', 30), h('p', null, t('oc_empty')), h('p', { class: 'muted s' }, t('e2e_note'))));
    if (near) list.scrollTop = list.scrollHeight;
  };
  const title = h('div', { class: 'ttl' }, t('owner'));
  const load = async () => {
    try {
      const r = await api('/api/owner-chat', { quiet: true });
      owner = r.owner; chatId = r.chat_id;
      E2E.setPub(owner.id, owner.pk); S.users.set(owner.id, { id: owner.id, full_name: owner.full_name, pk: owner.pk });
      await decryptAll(r.msgs);
      keep = msgs.filter((m) => sending.has(m.id) && !r.msgs.find((x) => x.id === m.id));
      msgs = r.msgs.concat(keep); rcs = {};
      for (const x of r.rcs) (rcs[x[0]] = rcs[x[0]] || []).push([x[1], x[2], x[3]]);
      title.textContent = owner.full_name; draw();
    } catch (e) { /* ignore */ }
  };
  const input = h('textarea', { rows: 1, placeholder: t('type_msg'), maxLength: 600 });
  const send = async () => {
    const text = input.value.trim(); if (!text || !owner) return;
    input.value = ''; input.style.height = '';
    const id = uid(); msgs.push({ id, sid: S.me.id, body: text, at: Date.now() }); sending.add(id); draw(); list.scrollTop = list.scrollHeight;
    try {
      if (!E2E.hasPub(owner.id)) throw Object.assign(new Error('no_key'), { code: 'no_key' });
      const { payload } = await E2E.encrypt(chatId, id, { b: text }, [owner.id]);
      await api('/api/owner-chat', { body: { id, enc: 1, body: payload }, quiet: true }); sending.delete(id); await load();
    } catch (e) { toast(errText(e)); }
  };
  input.addEventListener('input', () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 110) + 'px'; });
  el.append(header(h('div', null, title, h('div', { class: 'sub' }, t('oc_sub')))), list,
    h('div', { class: 'composer' }, h('div', { class: 'cbox' }, input), h('button', { class: 'sendb', onclick: send }, ic('send', 20, 'flip'))));
  el._show = () => {}; el._leave = () => clearInterval(timer);
  load(); timer = setInterval(() => { if (!document.hidden) load(); }, 3500);
  return el;
}
