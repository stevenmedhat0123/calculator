'use strict';
Object.assign(App, {
  setSession(r) {
    S.token = r.token; store.set('token', r.token);
    S.me = r.user; S.settings = r.settings || { allow_screens: false };
  },
  applySecure() { NV.secure(S.active && S.me && S.me.role !== 'owner' && !S.settings.allow_screens); },
  loading(msg, retry) {
    const el = h('div', { class: 'auth center-s' }, msg ? h('p', { class: 'muted' }, msg) : h('div', { class: 'spin big' }),
      retry && h('button', { class: 'btn primary', onclick: retry }, t('retry')), retry && h('button', { class: 'lnk', onclick: () => App.lockApp() }, t('back_to_calc')));
    Nav.replaceAll(el, 'loading');
  },
  async openSecret() {
    S.active = true;
    $('#root').classList.add('show'); $('#hidebar').classList.add('show');
    App.applySecure();
    if (!S.token) { Nav.replaceAll(authScreen('login'), 'auth'); return; }
    App.loading();
    try {
      const r = await api('/api/me', { quiet: true });
      S.me = r.user; S.settings = r.settings;
      App.enter();
    } catch (e) {
      if (e.status === 401) { App.sessionExpired(true); return; }
      App.loading(errText(e), () => App.openSecret());
    }
  },
  enter() {
    App.applySecure();
    const a = S.me.access;
    if (a === 'ok') {
      S.ver = null; S.chats.clear(); S.msgs.clear(); S.hist.clear(); S.rc.clear(); S.openChat = null;
      Nav.replaceAll(mainScreen(), 'main');
      Sync.start(); checkUpdate(false);
      clearInterval(App._me); App._me = setInterval(App.pollMe, 45000);
    } else {
      Sync.stop();
      Nav.replaceAll(pendingScreen(a), 'pending');
    }
  },
  async pollMe() {
    if (!S.active || document.hidden) return;
    try {
      const r = await api('/api/me', { quiet: true });
      const was = S.me.access;
      S.me = Object.assign(S.me, r.user); S.settings = r.settings; App.applySecure();
      if (r.user.access !== was) App.enter();
    } catch (e) { /* ignore */ }
  },
  accessChanged(kind) {
    if (!S.me || S.me.access === kind) return;
    S.me.access = kind; App.enter();
  },
  sessionExpired(silent) {
    S.token = null; store.del('token'); S.me = null; Sync.stop();
    if (!silent) toast(t('session_expired'));
    Nav.replaceAll(authScreen('login'), 'auth');
  },
  async signOut() {
    if (!(await dialog({ title: t('sign_out'), text: t('sign_out_text'), ok: t('sign_out'), danger: true }))) return;
    try { await api('/api/logout', { body: {}, quiet: true }); } catch (e) { /* ignore */ }
    S.token = null; store.del('token'); S.me = null; Sync.stop(); clearInterval(App._me);
    S.chats.clear(); S.msgs.clear(); S.hist.clear(); S.rc.clear(); S.ver = null;
    Nav.replaceAll(authScreen('login'), 'auth');
  },
  lockApp() {
    if (!S.active) return;
    S.active = false; S.openChat = null; S.lockOpen = false; Main.lockUntil = 0;
    Sync.stop(); clearInterval(App._me); stopAudio();
    document.querySelectorAll('.ov').forEach((o) => o.remove());
    NV.secure(false);
    $('#root').classList.remove('show'); $('#hidebar').classList.remove('show');
    setTimeout(() => { if (!S.active) { while (Nav.stack.length) { const s = Nav.stack.pop(); if (s.el._leave) s.el._leave(); s.el.remove(); } $('#root').replaceChildren(); } }, 220);
    Calc.reset();
  },
  refresh() {
    for (const s of Nav.stack) { if (s.el._refresh) s.el._refresh(); if (s.el._draw) s.el._draw(); }
    const top = Nav.top(); if (top && top.el._refresh) top.el._refresh();
  }
});
window.__back = () => {
  const ov = document.querySelectorAll('.ov');
  if (ov.length) { ov[ov.length - 1]._close(null); return true; }
  if (!S.active) return false;
  if (Nav.pop()) return true;
  App.lockApp(); return true;
};
window.__bg = () => { if (S.active && S.autoLock) App.lockApp(); };
if (!nat) document.addEventListener('visibilitychange', () => { if (document.hidden) window.__bg(); });

(function boot() {
  setLang(S.lang);
  $('#calc').append(Calc.build());
  $('#hidebar button').addEventListener('click', () => App.lockApp());
  setInterval(() => { if (S.active && S.me && S.me.access === 'ok') checkUpdate(false); }, 30 * 60 * 1000);
})();
