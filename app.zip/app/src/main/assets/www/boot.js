'use strict';
Object.assign(App, {
  setSession(r) {
    S.token = r.token; store.set('token', r.token);
    S.me = r.user; S.settings = r.settings || { allow_screens: false }; S.meAt = Date.now(); S.offline = false;
    store.set('uid', r.user.id);
  },
  applySecure() { NV.secure(S.active && S.me && S.me.role !== 'owner' && !S.settings.allow_screens); },
  applyFullscreen() { try { if (nat && nat.fullscreen) nat.fullscreen(!!S.active && store.get('fullscreen', true)); } catch (e) { /* ignore */ } },
  loading(msg, retry) {
    const el = h('div', { class: 'auth center-s' }, msg ? h('p', { class: 'muted' }, msg) : h('div', { class: 'spin big' }),
      retry && h('button', { class: 'btn primary', onclick: retry }, t('retry')), retry && h('button', { class: 'lnk', onclick: () => App.lockApp() }, t('back_to_calc')));
    Nav.replaceAll(el, 'loading');
  },
  async openSecret() {
    S.active = true;
    $('#root').classList.add('show'); Ball.show(true);
    App.applySecure(); App.applyFullscreen(); Theme.apply();
    if (!S.token) { Nav.replaceAll(authScreen('login'), 'auth'); return; }
    App.loading();
    try {
      /* the account details were checked a moment ago (the app locks itself whenever it goes to the background): do not ask again */
      if (!(S.me && S.meAt && Date.now() - S.meAt < 300000)) {
        try {
          const r = await api('/api/me', { quiet: true });
          S.me = r.user; S.settings = r.settings; S.meAt = Date.now(); S.offline = false; store.set('uid', S.me.id);
        } catch (e) {
          /* limit reached / no connection: open the saved chats read-only instead of an error screen */
          if (e.status === 401 || (e.code !== 'quota' && e.code !== 'network')) throw e;
          const lm = S.me ? { me: S.me, settings: S.settings } : await Disk.loadMe(store.get('uid', null));
          if (!lm) throw e;
          S.me = lm.me; S.settings = lm.settings || S.settings; S.offline = true;
        }
      }
      await App.enter();
    } catch (e) {
      if (e.status === 401) { App.sessionExpired(true); return; }
      App.loading(errText(e) || Quota.text(), () => App.openSecret());
    }
  },
  async enter() {
    App.applySecure();
    if (S.me.auth_v !== 1) { Sync.stop(); Nav.replaceAll(upgradeScreen(), 'upgrade'); return; }
    if (!E2E.ready()) {
      const ok = await E2E.loadLocal(S.me.id, S.me.pubkey);
      if (!ok) { Sync.stop(); Nav.replaceAll(unlockScreen(), 'unlock'); return; }
    }
    E2E.setPub(S.me.id, S.me.pubkey);
    const a = S.me.access;
    if (a === 'ok') {
      /* chats already in memory (same account, locked a moment ago) or saved on the phone: continue from there, only ask the server what is new */
      const warm = S.cacheUid === S.me.id && S.ver !== null && S.cur && Date.now() - S.cur < 7 * 864e5;
      if (!warm) {
        S.ver = null; S.cur = 0; S.cacheUid = null; S.chats.clear(); S.msgs.clear(); S.hist.clear(); S.rc.clear();
        await Disk.hydrate(S.me.id);
      } else await Disk.open(S.me.id);
      S.openChat = null;
      if (!S.offline) Disk.saveMe(S.me, S.settings);
      Nav.replaceAll(mainScreen(), 'main');
      Sync.start(); checkUpdate(false); loadContacts();
      clearInterval(App._me); App._me = setInterval(() => App.pollMe(), 4 * 60000);
    } else {
      Sync.stop();
      Nav.replaceAll(pendingScreen(a), 'pending');
    }
  },
  async pollMe(force) {
    if (!S.active || !S.me || (force !== true && (document.hidden || Quota.active()))) return;
    try {
      const r = await api('/api/me', { quiet: true, bg: true });
      const was = S.me.access;
      S.me = Object.assign(S.me, r.user); S.settings = r.settings; S.meAt = Date.now(); S.offline = false; App.applySecure();
      if (r.user.access !== was) App.enter();
      else App.refresh();
    } catch (e) { /* ignore */ }
  },
  accessChanged(kind) {
    if (!S.me || S.me.access === kind) return;
    S.me.access = kind; App.enter();
  },
  sessionExpired(silent) {
    S.token = null; store.del('token'); S.me = null; Sync.stop();
    if (!silent) toast(t('session_expired'));
    Nav.replaceAll(authScreen('login'), 'auth');
  },
  async signOut() {
    if (!(await dialog({ title: t('sign_out'), text: t('sign_out_text'), ok: t('sign_out'), danger: true }))) return;
    try { await api('/api/logout', { body: {}, quiet: true, noRetry: true }); } catch (e) { /* ignore */ }
    S.token = null; store.del('token'); S.me = null; Sync.stop(); clearInterval(App._me);
    S.chats.clear(); S.msgs.clear(); S.hist.clear(); S.rc.clear(); S.ver = null; S.cur = 0; S.cacheUid = null; S.meAt = 0; S.offline = false; S.contacts = new Map(); S.users.clear();
    await Disk.wipe(); store.del('uid');
    await E2E.clearLocal();
    Nav.replaceAll(authScreen('login'), 'auth');
  },
  lockApp() {
    if (!S.active) return;
    S.active = false; S.openChat = null; S.lockOpen = false; Main.lockUntil = 0; Main.lockMatch = false;
    Sync.stop(); clearInterval(App._me); stopAudio();
    if (S.ver !== null && S.cacheUid) Disk.save(Sync.state());          // everything is saved before the app hides
    document.querySelectorAll('.ov').forEach((o) => o.remove());
    NV.secure(false); Ball.show(false); App.applyFullscreen();
    try { if (nat && nat.lightBars) nat.lightBars(false, '#000000'); } catch (e) { /* old shell */ }
    $('#root').classList.remove('show');
    setTimeout(() => { if (!S.active) { while (Nav.stack.length) { const s = Nav.stack.pop(); if (s.el._leave) s.el._leave(); s.el.remove(); } $('#root').replaceChildren(); } }, 220);
    Calc.reset();
  },
  refresh() {
    for (const s of Nav.stack) { if (s.el._refresh) s.el._refresh(); if (s.el._draw) s.el._draw(); }
    const top = Nav.top(); if (top && top.el._refresh) top.el._refresh();
  }
});
window.__back = () => {
  const ov = document.querySelectorAll('.ov');
  if (ov.length) { ov[ov.length - 1]._close(null); return true; }
  if (!S.active) return false;
  const top = Nav.top();
  if (top && top.el._back && top.el._back()) return true;
  if (Nav.pop()) return true;
  App.lockApp(); return true;
};
window.__bg = () => { Presence.setFg(false); if (S.active && S.autoLock) App.lockApp(); };
window.__fg = () => { Presence.setFg(true); if (S.active) Sync.kick(); };
document.addEventListener('visibilitychange', () => { if (document.hidden) { if (!nat) window.__bg(); else Presence.setFg(false); } else window.__fg(); });

(function boot() {
  setLang(S.lang);
  Theme.apply();
  $('#calc').append(Calc.build());
  Ball.init();
  try { if (nat && nat.setRecents) nat.setRecents(store.get('recents', 1)); } catch (e) { /* ignore */ }
  setInterval(() => { if (S.active && S.me && S.me.access === 'ok') checkUpdate(false); }, 30 * 60 * 1000);
})();
