'use strict';
/*
  Local copy of the chats on this phone (IndexedDB), so the server (D1) is asked for NEW things only.
  - Everything is stored exactly as the server sent it, so messages stay encrypted on the phone too.
  - One database per account: "calc-cache-<user id>".
  - state.cur is the server time of the last sync; the server only sends what changed after it.
*/
const PAGE = 30;                        // messages per page (server and phone)
const Disk = (() => {
  const MAX_AGE = 7 * 864e5;            // older than this: start fresh (a long absence would be a big catch-up)
  const MEDIA_CAP = 80 * 1048576;       // downloaded (still encrypted) photos / voice / files kept on the phone
  const STORES = ['meta', 'chats', 'hist', 'msgs', 'rc', 'media'];
  let db = null, uidNow = null;
  const disk = new Map();               // chatId -> { more }  (chats that have saved history; more = server may have older messages)
  const pad = (n) => String(Math.max(0, Math.floor(n))).padStart(14, '0');
  const mkey = (chatId, at, id) => chatId + '|' + pad(at) + '|' + id;
  const newQ = () => ({ msgs: new Map(), dels: new Set(), rc: new Set(), chats: new Map(), drops: new Set(), purge: new Map(), hist: new Map() });
  let q = newQ(), timer = null, chain = Promise.resolve();

  /* ----- plain IndexedDB plumbing ----- */
  function open(uid) {
    return new Promise((res) => {
      if (db && uidNow === uid) return res(true);
      close();
      let req;
      try { req = indexedDB.open('calc-cache-' + uid, 1); } catch (e) { return res(false); }
      req.onupgradeneeded = () => {
        const d = req.result;
        for (const n of STORES) {
          if (d.objectStoreNames.contains(n)) continue;
          if (n === 'meta') d.createObjectStore(n);
          else if (n === 'msgs') d.createObjectStore(n, { keyPath: 'k' });
          else d.createObjectStore(n, { keyPath: 'id' });
        }
      };
      req.onsuccess = () => {
        db = req.result; uidNow = uid;
        db.onversionchange = () => close();
        res(true);
      };
      req.onerror = () => res(false);
      req.onblocked = () => res(false);
    });
  }
  function close() { if (db) { try { db.close(); } catch (e) { /* ignore */ } } db = null; uidNow = null; }
  /* one transaction; fn(tx, out) may start requests and fill out; resolves with out when the transaction is complete */
  function run(names, mode, fn) {
    return new Promise((res, rej) => {
      if (!db) return rej(new Error('no_cache'));
      let t; const out = {};
      try { t = db.transaction(names, mode); } catch (e) { return rej(e); }
      t.oncomplete = () => res(out);
      t.onerror = () => rej(t.error || new Error('idb'));
      t.onabort = () => rej(t.error || new Error('idb_abort'));
      try { fn(t, out); } catch (e) { try { t.abort(); } catch (x) { /* ignore */ } rej(e); }
    });
  }

  /* ----- what gets written: the message exactly as the server sent it (never the decrypted text) ----- */
  function packMsg(m) {
    const r = m._raw;
    const o = {
      id: m.id, chat_id: m.chat_id, sid: m.sid, type: m.type, body: r ? r.body : m.body, enc: m.enc ? 1 : 0,
      media: r ? r.media : m.media, reply: r ? r.reply : m.reply, rx: m.rx || {}, del: m.del ? 1 : 0, at: m.at, up: m.up, ed: m.ed || 0
    };
    o.k = mkey(o.chat_id, o.at, o.id);
    return o;
  }
  function packChat(c) {
    const o = {};
    for (const k of Object.keys(c)) { if (k !== 'last' && k[0] !== '_') o[k] = c[k]; }
    o.last = c.last ? packMsg(c.last) : null;
    return o;
  }

  /* ----- write queue: collected, then saved in one transaction together with the sync position ----- */
  function sched() { if (!timer) timer = setTimeout(() => { timer = null; flush(null); }, 400); }
  function flush(state) {
    clearTimeout(timer); timer = null;
    const b = q; q = newQ();
    chain = chain.then(() => write(b, state)).catch(() => false);
    return chain;
  }
  function write(b, state) {
    if (!db) return false;
    return run(['meta', 'chats', 'hist', 'msgs', 'rc'], 'readwrite', (t) => {
      const m = t.objectStore('msgs'), c = t.objectStore('chats'), hs = t.objectStore('hist'), r = t.objectStore('rc'), me = t.objectStore('meta');
      for (const id of b.drops) { c.delete(id); hs.delete(id); m.delete(IDBKeyRange.bound(id + '|', id + '|~')); }
      for (const [id, upto] of b.purge) m.delete(IDBKeyRange.bound(id + '|', id + '|' + pad(upto + 1), false, true));
      for (const x of b.chats.values()) c.put(packChat(x));
      for (const [id, more] of b.hist) hs.put({ id, more });
      for (const x of b.msgs.values()) m.put(packMsg(x));
      for (const k of b.dels) m.delete(k);
      for (const id of b.rc) {
        const e = S.rc.get(id);
        if (e) r.put({ id, r: [...e.entries()].map(([u, v]) => [u, v[0], v[1]]) });
      }
      if (state) me.put(state, 'state');
    }).then(() => true);
  }

  const api2 = {
    PAGE,
    has: (chatId) => disk.has(chatId),
    disk,
    ok: () => !!db,
    open,
    /* queue helpers: called by the sync / chat code */
    touchMsg(m) { if (db && m && m.id) { q.msgs.set(m.id, m); q.dels.delete(mkey(m.chat_id, m.at, m.id)); sched(); } },
    touchChat(c) { if (db && c) { q.chats.set(c.id, c); sched(); } },
    touchRc(id) { if (db) { q.rc.add(id); sched(); } },
    setHist(chatId, more) { if (!db) return; disk.set(chatId, { more: !!more }); q.hist.set(chatId, !!more); sched(); },
    dropMsg(m) { if (db && m) { q.msgs.delete(m.id); q.dels.add(mkey(m.chat_id, m.at, m.id)); sched(); } },
    dropChat(id) {
      disk.delete(id);
      if (!db) return;
      for (const [k, m] of q.msgs) if (m.chat_id === id) q.msgs.delete(k);
      q.chats.delete(id); q.hist.delete(id); q.purge.delete(id); q.drops.add(id); sched();
    },
    /* the chat was cleared (here or on another phone): forget everything up to that time */
    purge(chatId, upto) {
      if (!db || !upto) return;
      for (const [k, m] of q.msgs) if (m.chat_id === chatId && m.at <= upto) q.msgs.delete(k);
      q.purge.set(chatId, Math.max(upto, q.purge.get(chatId) || 0)); sched();
    },
    /* save everything queued, plus (optionally) the sync position, in one go */
    save(state) { return flush(state || null); },
    flushNow() { return flush(null); },

    /* ----- reading ----- */
    async page(chatId, before, limit) {
      if (!db) return [];
      await flush(null);
      const out = [];
      try {
        await run(['msgs'], 'readonly', (t) => {
          const hi = Number.isFinite(before) ? chatId + '|' + pad(before) : chatId + '|~';
          const req = t.objectStore('msgs').openCursor(IDBKeyRange.bound(chatId + '|', hi, false, true), 'prev');
          req.onsuccess = () => { const c = req.result; if (c && out.length < limit) { out.push(c.value); c.continue(); } };
        });
      } catch (e) { return []; }
      return out.reverse();
    },
    async rcFor(ids) {
      const out = [];
      if (!db || !ids.length) return out;
      try {
        await run(['rc'], 'readonly', (t) => {
          const s = t.objectStore('rc');
          for (const id of ids) { const g = s.get(id); g.onsuccess = () => { if (g.result) out.push(g.result); }; }
        });
      } catch (e) { /* ignore */ }
      return out;
    },
    async stats() {
      if (!db) return { chats: 0, msgs: 0 };
      try {
        const o = await run(['chats', 'msgs'], 'readonly', (t, out) => {
          const a = t.objectStore('chats').count(), b = t.objectStore('msgs').count();
          a.onsuccess = () => { out.chats = a.result; }; b.onsuccess = () => { out.msgs = b.result; };
        });
        return { chats: o.chats || 0, msgs: o.msgs || 0 };
      } catch (e) { return { chats: 0, msgs: 0 }; }
    },

    /* ----- start of a session: put the saved chat list back into memory ----- */
    async hydrate(uid) {
      if (!(await open(uid))) return false;
      let o;
      try {
        o = await run(['meta', 'chats', 'hist'], 'readonly', (t, out) => {
          const a = t.objectStore('meta').get('state'), b = t.objectStore('chats').getAll(), c = t.objectStore('hist').getAll();
          a.onsuccess = () => { out.state = a.result; }; b.onsuccess = () => { out.chats = b.result; }; c.onsuccess = () => { out.hist = c.result; };
        });
      } catch (e) { return false; }
      const st = o.state;
      if (!st || st.v !== 1 || !st.cur || Date.now() - st.cur > MAX_AGE) { await api2.reset(); return false; }
      disk.clear();
      for (const h of o.hist || []) disk.set(h.id, { more: !!h.more });
      S.chats.clear(); S.msgs.clear(); S.hist.clear(); S.rc.clear();
      const lasts = [];
      for (const c of o.chats || []) { S.chats.set(c.id, c); if (c.last) lasts.push(c.last); }
      await decryptAll(lasts);
      S.blocked = new Set(st.blocked || []);
      for (const c of o.chats || []) for (const m of c.members || []) { S.users.set(m.id, Object.assign(S.users.get(m.id) || {}, m)); if (m.pk) E2E.setPub(m.id, m.pk); }
      S.ver = st.ver; S.cur = st.cur; S.listAt = st.listAt || 0; S.cacheUid = uid;
      return true;
    },
    /* the account details are kept (without the lock password hash) so saved chats can be read when the server is not reachable */
    async saveMe(me, settings) {
      if (!db || !me) return;
      const o = Object.assign({}, me); delete o.lock_hash; delete o.lock_salt;
      try { await run(['meta'], 'readwrite', (t) => { t.objectStore('meta').put({ me: o, settings: settings || {}, at: Date.now() }, 'me'); }); } catch (e) { /* ignore */ }
    },
    async loadMe(uid) {
      if (!uid || !(await open(uid))) return null;
      try {
        const o = await run(['meta'], 'readonly', (t, out) => { const g = t.objectStore('meta').get('me'); g.onsuccess = () => { out.v = g.result; }; });
        return o.v || null;
      } catch (e) { return null; }
    },
    /* forget saved chats (keeps downloaded files) */
    async reset() {
      q = newQ(); clearTimeout(timer); timer = null; disk.clear();
      if (!db) return;
      try { await run(['meta', 'chats', 'hist', 'msgs', 'rc'], 'readwrite', (t) => { for (const n of ['chats', 'hist', 'msgs', 'rc']) t.objectStore(n).clear(); t.objectStore('meta').delete('state'); }); } catch (e) { /* ignore */ }
    },
    /* sign out: remove everything of this account from the phone */
    async wipe() {
      const uid = uidNow || S.cacheUid; q = newQ(); clearTimeout(timer); timer = null; disk.clear(); close();
      if (!uid) return;
      await new Promise((res) => { try { const r = indexedDB.deleteDatabase('calc-cache-' + uid); r.onsuccess = r.onerror = r.onblocked = () => res(); } catch (e) { res(); } });
    },

    /* ----- downloaded files: kept (still encrypted) so they are never fetched twice ----- */
    async mediaGet(id) {
      if (!db) return null;
      try {
        const o = await run(['media'], 'readonly', (t, out) => { const g = t.objectStore('media').get(id); g.onsuccess = () => { out.v = g.result; }; });
        return o.v ? o.v.parts : null;
      } catch (e) { return null; }
    },
    async mediaPut(id, parts) {
      if (!db) return false;
      let size = 0; for (const p of parts) size += p.byteLength;
      if (size > 40 * 1048576) return false;
      try {
        await run(['meta', 'media'], 'readwrite', (t) => {
          const me = t.objectStore('meta'), md = t.objectStore('media');
          const g = me.get('mediaIdx');
          g.onsuccess = () => {
            const idx = (g.result || []).filter((e) => e[0] !== id);
            idx.push([id, size, Date.now()]);
            let total = idx.reduce((a, e) => a + e[1], 0);
            while (total > MEDIA_CAP && idx.length > 1) { const old = idx.shift(); total -= old[1]; md.delete(old[0]); }
            me.put(idx, 'mediaIdx'); md.put({ id, parts });
          };
        });
        return true;
      } catch (e) { return false; }
    }
  };
  return api2;
})();
