'use strict';
/* ---------- small widgets ---------- */
function toggle(on, onChange) {
  const el = h('button', { class: 'tg' + (on ? ' on' : ''), role: 'switch', 'aria-checked': on ? 'true' : 'false' }, h('i'));
  el.addEventListener('click', async () => {
    const nv = !el.classList.contains('on');
    const ok = await onChange(nv);
    if (ok !== false) { el.classList.toggle('on', nv); el.setAttribute('aria-checked', nv ? 'true' : 'false'); }
  });
  return el;
}
const DAY = 864e5;
function randomCode() {
  const U = 'ABCDEFGHJKLMNPQRSTUVWXYZ', L = 'abcdefghijkmnopqrstuvwxyz', D = '23456789', Y = '!#%?@$&*+=';
  const pick = (s) => s[crypto.getRandomValues(new Uint32Array(1))[0] % s.length];
  const a = [pick(U), pick(L), pick(D), pick(Y)];
  const all = U + L + D + Y;
  while (a.length < 14) a.push(pick(all));
  for (let i = a.length - 1; i > 0; i--) { const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a.join('');
}
const durLabel = (c) => (c.permanent ? t('permanent') : '1 ' + t('d_' + c.duration));

async function changePwFlow(kind) {
  for (;;) {
    const v = await ask(kind === 'pass' ? t('change_owner_pw') : t('change_backup_pw'),
      [{ label: t('cur_pw'), pw: true }, { label: kind === 'pass' ? t('f_newpw') : t('f_rec'), pw: true }, { label: kind === 'pass' ? t('f_pw2') : t('f_rec2'), pw: true }], t('save'));
    if (!v) return;
    if (kind === 'pass' && !strongPw(v[1])) { toast(t('e_weak_password')); continue; }
    if (kind === 'rec' && v[1].length < 6) { toast(t('e_weak_recovery')); continue; }
    if (v[1] !== v[2]) { toast(t('e_pw_mismatch')); continue; }
    try {
      const un = S.me.kdf;
      const me = await api('/api/me', { quiet: true });
      let pkcs8;
      try { pkcs8 = await E2E.unwrapBlob(me.key_blob, await E2E.wrapKeyOf(v[0], un, 'pw')); } catch (e) { toast(t('e_bad_login')); continue; }
      const cur = await E2E.authHash(v[0], un, 'pw');
      if (kind === 'pass') await api('/api/password', { body: { current: cur, value: await E2E.authHash(v[1], un, 'pw'), key_blob: await E2E.wrapBlob(pkcs8, await E2E.wrapKeyOf(v[1], un, 'pw')) }, quiet: true });
      else await api('/api/recovery', { body: { current: cur, value: await E2E.authHash(v[1], un, 'rec'), key_blob_rec: await E2E.wrapBlob(pkcs8, await E2E.wrapKeyOf(v[1], un, 'rec')) }, quiet: true });
      toast(t('saved')); return;
    } catch (e) { toast(errText(e)); }
  }
}

/* ---------- owner panel ---------- */
function ownerPanel() {
  const el = h('div', { class: 'owner' });
  let tab = 'codes';
  const body = h('div', { class: 'ob' });
  const tabsEl = h('div', { class: 'otabs' });
  const views = {};
  const show = (tb) => {
    tab = tb;
    tabsEl.replaceChildren(...['codes', 'members', 'account'].map((k) => h('button', { class: k === tab ? 'on' : '', onclick: () => show(k) }, t('tab_' + k))));
    if (!views[tb]) views[tb] = tb === 'codes' ? codesView() : tb === 'members' ? membersView() : accountView();
    body.replaceChildren(views[tb]); if (views[tb]._load) views[tb]._load();
  };
  el.append(h('div', { class: 'ohdr' }, h('h1', null, t('owner_panel')), h('button', { class: 'ib', onclick: () => Nav.pop() }, ic('close', 26))), tabsEl, body);
  show('codes');
  return el;
}

function codesView() {
  const st = { duration: 'month', permanent: false, unlimited: false, max: 1, filter: 'all', codes: [] };
  const code = h('input', { class: 'mono center', placeholder: t('code_own_ph'), autocapitalize: 'off', autocomplete: 'off', spellcheck: false, maxLength: 64 });
  const note = h('input', { placeholder: t('code_note_ph'), maxLength: 80 });
  const err = h('div', { class: 'err' });
  const durRow = h('div', { class: 'chiprow' });
  const maxBox = h('div', { class: 'stepper' });
  const list = h('div', { class: 'clist2' });
  const filters = h('div', { class: 'chiprow wrap' });
  const maxVal = h('div', { class: 'sv' }, '1');
  const drawForm = () => {
    durRow.replaceChildren(...['day', 'week', 'month', 'year'].map((d) => h('button', { class: 'ch' + (st.duration === d && !st.permanent ? ' on' : '') + (st.permanent ? ' dis' : ''), onclick: () => { if (st.permanent) return; st.duration = d; drawForm(); } }, t('d_' + d))));
    maxBox.style.display = st.unlimited ? 'none' : '';
    maxVal.textContent = st.max;
    seg.replaceChildren(h('button', { class: !st.unlimited ? 'on' : '', onclick: () => { st.unlimited = false; drawForm(); } }, t('limited')), h('button', { class: st.unlimited ? 'on' : '', onclick: () => { st.unlimited = true; drawForm(); } }, t('unlimited')));
  };
  const seg = h('div', { class: 'seg2' });
  maxBox.append(h('button', { class: 'sb', onclick: () => { st.max = Math.max(1, st.max - 1); drawForm(); } }, '\u2212'), maxVal, h('button', { class: 'sb', onclick: () => { st.max = Math.min(10000, st.max + 1); drawForm(); } }, '+'));
  const create = h('button', { class: 'btn big' }, t('create_code'));
  create.addEventListener('click', async () => {
    err.textContent = '';
    const c = code.value.trim();
    if (c.length < 4 || c.length > 64 || /\s/.test(c)) return (err.textContent = t('e_bad_code_format'));
    create.disabled = true;
    try {
      await api('/api/owner/codes', { body: { code: c, duration: st.duration, permanent: st.permanent, unlimited: st.unlimited, max_uses: st.max, note: note.value.trim() } });
      code.value = ''; note.value = ''; toast(t('code_created')); load();
    } catch (e) { err.textContent = errText(e); }
    create.disabled = false;
  });
  const form = h('div', { class: 'ocard' }, h('h2', null, t('new_code')),
    h('label', { class: 'fld' }, h('span', { class: 'fl' }, t('code')), code),
    h('button', { class: 'btn outline wide', onclick: () => { code.value = randomCode(); } }, ic('star', 18), t('make_random')),
    h('p', { class: 'muted s' }, t('code_rules')),
    h('div', { class: 'fl' }, t('duration')), durRow,
    h('div', { class: 'prow' }, h('div', null, h('b', null, t('perm_sub')), h('small', null, t('never_ends'))), toggle(false, (v) => { st.permanent = v; drawForm(); })),
    h('p', { class: 'muted s' }, t('counted_from')),
    h('div', { class: 'fl' }, t('times_used')), seg, maxBox,
    h('p', { class: 'muted s' }, t('limited_hint')),
    h('label', { class: 'fld' }, h('span', { class: 'fl' }, t('note_opt')), note), err, create);
  const statusOf = (c) => (c.status === 'cancelled' ? 'cancelled' : (c.max_uses > 0 && c.uses >= c.max_uses ? 'used' : 'available'));
  const drawList = () => {
    const counts = { all: st.codes.length, available: 0, used: 0, cancelled: 0 };
    st.codes.forEach((c) => { counts[statusOf(c)]++; });
    filters.replaceChildren(...['all', 'available', 'used', 'cancelled'].map((k) => h('button', { class: 'ch' + (st.filter === k ? ' on' : ''), onclick: () => { st.filter = k; drawList(); } }, t('f_' + k) + ' \u00b7 ' + counts[k])));
    const rows = st.codes.filter((c) => st.filter === 'all' || statusOf(c) === st.filter);
    list.replaceChildren(...rows.map((c) => {
      const s = statusOf(c);
      return h('div', { class: 'ocard code' },
        h('div', { class: 'ctop2' }, h('span', { class: 'cv mono' }, c.code), h('span', { class: 'pill ' + s }, t('f_' + s))),
        h('div', { class: 'muted' }, durLabel(c) + ' \u00b7 ' + (c.max_uses > 0 ? t('used_of', { a: c.uses, b: c.max_uses }) : t('used_n', { a: c.uses }) + ' \u00b7 ' + t('unlimited'))),
        c.note ? h('div', { class: 'cnote' }, c.note) : null,
        c.used_by.length ? [h('div', { class: 'muted s' }, t('used_by')), c.used_by.map((u) => h('div', { class: 'ub' }, u.name + ' \u00b7 ' + fmtDate(u.at)))] : null,
        h('div', { class: 'brow' }, h('button', { class: 'btn small', onclick: () => copyText(c.code) }, t('copy')),
          h('button', { class: 'btn small', onclick: async () => { try { await api('/api/owner/codes/cancel', { body: { code: c.code } }); load(); } catch (e) { toast(errText(e)); } } }, c.status === 'cancelled' ? t('restore_code') : t('cancel_code')),
          h('button', { class: 'btn small red', onclick: async () => { if (await dialog({ title: t('delete'), text: c.code, ok: t('delete'), danger: true })) { try { await api('/api/owner/codes/delete', { body: { code: c.code } }); load(); } catch (e) { toast(errText(e)); } } } }, t('delete'))));
    }), st.codes.length ? null : h('p', { class: 'muted center' }, t('no_codes')));
  };
  const load = async () => { try { const r = await api('/api/owner/codes'); st.codes = r.codes; drawList(); } catch (e) { toast(errText(e)); } };
  const el = h('div', null, form, filters, list);
  drawForm(); drawList(); el._load = load;
  return el;
}

function membersView() {
  const st = { q: '', filter: 'all', members: [] };
  const search = h('input', { type: 'search', placeholder: t('search_name'), autocomplete: 'off' });
  const sum = h('div', { class: 'muted' });
  const filters = h('div', { class: 'chiprow wrap' });
  const list = h('div', { class: 'clist2' });
  const stateOf = (m) => {
    if (m.status === 'blocked') return 'blocked';
    if (m.access !== 'ok') return 'ended';
    if (!m.permanent && m.expires_at - Date.now() < 7 * DAY) return 'soon';
    return 'active';
  };
  const draw = () => {
    const q = search.value.trim().toLowerCase();
    const all = st.members.filter((m) => !q || m.full_name.toLowerCase().includes(q) || m.username.includes(q));
    const cnt = { all: all.length, active: 0, soon: 0, ended: 0, blocked: 0 };
    all.forEach((m) => { const s = stateOf(m); cnt[s]++; if (s === 'soon') cnt.active++; });
    sum.textContent = t('members_sum', { a: st.members.length, b: st.members.filter((m) => m.access === 'ok' && m.status !== 'blocked').length });
    filters.replaceChildren(...['all', 'active', 'soon', 'ended', 'blocked'].map((k) => h('button', { class: 'ch' + (st.filter === k ? ' on' : ''), onclick: () => { st.filter = k; draw(); } }, t('m_' + k) + ' \u00b7 ' + cnt[k])));
    const rows = all.filter((m) => { const s = stateOf(m); return st.filter === 'all' || s === st.filter || (st.filter === 'active' && s === 'soon'); });
    list.replaceChildren(...rows.map((m) => {
      const s = stateOf(m);
      const left = m.permanent ? null : Math.ceil((m.expires_at - Date.now()) / DAY);
      const line = s === 'blocked' ? t('m_blocked') : s === 'ended' ? (m.expires_at ? t('access_ended') : t('no_code_yet')) : m.permanent ? t('perm_sub') : t('active_until', { d: fmtDate(m.expires_at), n: left });
      return h('div', { class: 'ocard' }, h('div', { class: 'ctop2' }, h('b', { class: 'mname' }, m.full_name), h('span', { class: 'pill m-' + s }, t(s === 'soon' ? 'm_soon' : s === 'ended' ? 'm_ended_pill' : s === 'blocked' ? 'm_blocked' : 'm_active_pill'))),
        h('div', { class: 'muted' }, line), h('div', { class: 'muted s' }, '@' + m.username + ' \u00b7 ' + m.phone),
        h('div', { class: 'muted s' }, t('last_seen_d', { d: m.last_seen ? fmtDate(m.last_seen) : '\u2014' })),
        h('div', { class: 'brow' },
          h('button', { class: 'btn small', onclick: async () => { try { const id = await startDm(null, m.id); Nav.pop(); Chat.open(id); } catch (e) { toast(errText(e)); } } }, t('message')),
          h('button', { class: 'btn small', onclick: () => { const was = m.status, path = was === 'blocked' ? 'unblock' : 'block'; m.status = was === 'blocked' ? 'active' : 'blocked'; draw(); api('/api/owner/members/' + path, { body: { id: m.id }, retry: true }).then(() => load()).catch((e) => { m.status = was; draw(); toast(errText(e)); }); } }, m.status === 'blocked' ? t('unblock') : t('block')),
          h('button', { class: 'btn small', onclick: () => resetLockFor(m) }, ic('lock', 14), t('reset_lock')),
          m.access === 'ok' ? h('button', { class: 'btn small red', onclick: async () => { if (await dialog({ title: t('end_access'), text: m.full_name, ok: t('end_access'), danger: true })) { try { await api('/api/owner/members/revoke', { body: { id: m.id } }); load(); } catch (e) { toast(errText(e)); } } } }, t('end_access')) : null));
    }), rows.length ? null : h('p', { class: 'muted center' }, t('no_members')));
  };
  search.addEventListener('input', draw);
  const load = async () => { try { const r = await api('/api/owner/members'); st.members = r.members; draw(); } catch (e) { toast(errText(e)); } };
  const el = h('div', null, h('div', { class: 'searchw' }, ic('search', 18), search), sum, filters, list);
  el._load = load; draw();
  return el;
}

function accountView() {
  const row = (icon, color, title, sub, fn, cls) => h('button', { class: 'orow ' + (cls || ''), onclick: fn }, h('span', { class: 'oi', style: { color } }, ic(icon, 22)), h('span', null, h('b', null, title), sub ? h('small', null, sub) : null));
  return h('div', null, h('div', { class: 'ocard' }, h('h2', null, S.me.full_name), h('div', { class: 'muted' }, t('owner'))),
    h('div', { class: 'ocard flush' },
      row('lock', '#ff6b81', t('change_owner_pw'), null, () => changePwFlow('pass')),
      row('shield', '#4da8ff', t('change_backup_pw'), t('backup_hint'), () => changePwFlow('rec')),
      row('up', '#ffa94d', t('sign_out'), null, () => App.signOut(), 'red')),
    h('p', { class: 'muted center s' }, t('server') + ': ' + serverUrl()));
}

/* ---------- in-app update ---------- */
const Upd = { state: 'idle', pct: 0, bytes: 0 };
function cmpVer(a, b) {
  const x = String(a).split('.').map((n) => parseInt(n, 10) || 0), y = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; }
  return 0;
}
async function checkUpdate(manual) {
  const repo = window.CFG && window.CFG.repo;
  if (!repo || repo.startsWith('__')) { if (manual) toast(t('upd_norepo')); return; }
  try {
    const r = await fetch('https://api.github.com/repos/' + repo + '/releases/latest', { headers: { accept: 'application/vnd.github+json' } });
    if (!r.ok) throw new Error('http');
    const j = await r.json();
    const asset = (j.assets || []).find((a) => /\.apk$/i.test(a.name));
    const v = String(j.tag_name || '').replace(/^v/i, '');
    if (asset && cmpVer(v, NV.version()) > 0) { if (!S.update || S.update.version !== v) Upd.state = 'idle'; S.update = { version: v, size: asset.size, url: asset.browser_download_url }; }
    else { S.update = null; if (manual) toast(t('upd_latest')); }
  } catch (e) { if (manual) toast(t('upd_fail')); }
  App.refresh();
}
Upd.act = function () {
  if (!S.update) return;
  if (Upd.state === 'idle' || Upd.state === 'error') {
    if (!nat || !nat.download) { window.open(S.update.url, '_blank'); return; }
    Upd.state = 'downloading'; Upd.pct = 0; nat.download(S.update.url); App.refresh();
  } else if (Upd.state === 'ready') {
    if (nat.canInstall()) nat.install(); else { toast(t('upd_allow')); nat.installSettings(); }
  }
};
window.__dl = (p, bytes) => { Upd.pct = p; Upd.bytes = bytes; App.refresh(); };
window.__dlDone = (ok) => { Upd.state = ok ? 'ready' : 'error'; if (ok) Upd.pct = 100; App.refresh(); if (ok) Upd.act(); };
function updateBanner() {
  if (!S.update) return null;
  const u = S.update;
  const label = Upd.state === 'downloading' ? t('upd_downloading', { p: Upd.pct }) : Upd.state === 'ready' ? t('upd_ready') : Upd.state === 'error' ? t('upd_fail') : t('upd_available', { v: u.version, s: fmtSize(u.size) });
  const btn = Upd.state === 'downloading' ? null : h('button', { class: 'btn small primary', onclick: () => Upd.act() }, Upd.state === 'ready' ? t('install') : Upd.state === 'error' ? t('retry') : t('download'));
  return h('div', { class: 'ubanner' }, h('div', { class: 'ut' }, ic('download', 20), h('span', null, h('b', null, t('upd_title')), h('small', null, label))), btn,
    Upd.state === 'downloading' ? h('div', { class: 'prog2' }, h('i', { style: { width: Upd.pct + '%' } })) : null);
}
