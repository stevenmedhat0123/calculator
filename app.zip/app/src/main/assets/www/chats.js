'use strict';
/* ---------- names, contacts ---------- */
S.contacts = new Map(); S.typingMap = new Map(); S.keyChanged = new Set();
async function loadContacts() {
  try {
    const r = await api('/api/contacts', { quiet: true });
    S.contacts = new Map(r.contacts.map((c) => [c.id, c]));
    for (const c of r.contacts) { if (c.pk) E2E.setPub(c.id, c.pk); S.users.set(c.id, Object.assign(S.users.get(c.id) || {}, { id: c.id, full_name: c.full_name, username: c.username, pk: c.pk, av: c.av })); }
  } catch (e) { /* ignore */ }
  App.refresh();
}
const displayName = (id) => {
  if (S.me && id === S.me.id) return t('you');
  const c = S.contacts.get(id); if (c && c.name) return c.name;
  const u = S.users.get(id); return (u && u.full_name) || t('unknown');
};
const peerOf = (c) => c.members.find((m) => m.id !== S.me.id);
const isSelf = (c) => c.type === 'dm' && c.members.length === 1 && c.members[0].id === S.me.id;
const chatTitle = (c) => (c.type === 'group' ? c.name : isSelf(c) ? t('message_yourself') : (peerOf(c) ? displayName(peerOf(c).id) : t('chat')));
const userName = displayName;
const firstName = (id) => displayName(id).split(' ')[0];
const isRequest = (c) => !!(S.me.role === 'owner' && c.type === 'dm' && peerOf(c) && peerOf(c).acc && peerOf(c).acc !== 'ok');
function sysText(m) {
  let o = {}; try { o = JSON.parse(m.body); } catch (e) { /* ignore */ }
  const k = 'sys_' + o.k;
  return I18N.en[k] ? t(k, { a: o.a, b: o.b, name: o.name }) : '';
}
function previewText(m, c) {
  if (!m) return '';
  if (m.del) return '\u2298 ' + t('msg_deleted');
  let s = '';
  if (m.type === 'text') s = m.body;
  else if (m.type === 'image') s = '\ud83d\udcf7 ' + (m.body || t('photo'));
  else if (m.type === 'video') s = '\ud83c\udfa5 ' + (m.body || t('video'));
  else if (m.type === 'audio') s = '\ud83c\udfa4 ' + t('voice') + (m.media && m.media.dur ? ' ' + fmtDur(m.media.dur) : '');
  else if (m.type === 'file') s = '\ud83d\udcc4 ' + ((m.media && m.media.name) || t('file'));
  else if (m.type === 'sys') return sysText(m);
  if (c && c.type === 'group' && m.sid !== S.me.id) s = firstName(m.sid) + ': ' + s;
  return s;
}
const rcOf = (mid) => { const r = S.rc.get(mid); return r ? [...r.entries()].map(([u, v]) => [u, v[0], v[1]]) : []; };
function tickEl(list, pending) {
  if (pending) return h('span', { class: 'tick pend' }, ic('clock', 12));
  let st = 1;
  if (list.length) st = list.every((x) => x[2]) ? 3 : (list.every((x) => x[1]) ? 2 : 1);
  return h('span', { class: 'tick s' + st, html: STAR_SVG + (st > 1 ? STAR_SVG : '') });
}
function onLong(el, fn) {
  let tm = null, sx = 0, sy = 0, fired = false;
  el.addEventListener('touchstart', (e) => { fired = false; sx = e.touches[0].clientX; sy = e.touches[0].clientY; tm = setTimeout(() => { fired = true; if (navigator.vibrate) navigator.vibrate(12); fn(e); }, 420); }, { passive: true });
  const cancel = () => clearTimeout(tm);
  el.addEventListener('touchmove', (e) => { if (Math.abs(e.touches[0].clientX - sx) > 8 || Math.abs(e.touches[0].clientY - sy) > 8) cancel(); }, { passive: true });
  el.addEventListener('touchend', (e) => { cancel(); if (fired) e.preventDefault(); });
  el.addEventListener('touchcancel', cancel);
  el.addEventListener('contextmenu', (e) => { e.preventDefault(); fn(e); });
}
let actx;
function beep() {
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const o = actx.createOscillator(), g = actx.createGain();
    o.frequency.value = 880; g.gain.value = 0.05; o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.1);
  } catch (e) { /* ignore */ }
}

/* ---------- encryption helpers for messages ---------- */
const decCache = new Map();
async function fetchKeys(ids) {
  ids = [...new Set(ids)].filter((i) => i && !E2E.hasPub(i)); if (!ids.length) return;
  try {
    const r = await api('/api/pubkeys?ids=' + ids.join(','), { quiet: true });
    for (const [id, v] of Object.entries(r.keys)) if (v.pk) E2E.setPub(id, v.pk);
  } catch (e) { /* ignore */ }
}
async function decryptMsg(m) {
  if (m && m.enc && !m._raw) m._raw = { body: m.body, media: m.media, reply: m.reply };   // exactly what the server sent: this is what is saved on the phone
  if (!m || !m.enc || m._dec) return m;
  if (m.del || !m.body) { m._dec = true; return m; }
  const ck = m.id + ':' + m.ed + ':' + m.body.length;
  const hit = decCache.get(ck);
  if (hit) { Object.assign(m, hit); m._dec = true; return m; }
  try {
    if (!E2E.hasPub(m.sid)) { const u = S.users.get(m.sid); if (u && u.pk) E2E.setPub(m.sid, u.pk); }
    if (!E2E.hasPub(m.sid)) await fetchKeys([m.sid]);
    const { content } = await E2E.decrypt(m.chat_id, m.id, m.body);
    const out = { body: content.b || '', reply: content.r || null, fwd: !!content.f, media: content.m ? Object.assign({}, m.media || {}, content.m) : m.media, _ok: true };
    decCache.set(ck, out); Object.assign(m, out);
  } catch (e) { m.body = '\ud83d\udd12 ' + t('cant_decrypt'); m._fail = true; }
  m._dec = true; return m;
}
const decryptAll = (arr) => Promise.all((arr || []).map(decryptMsg));

/* ---------- typing (instant, pushed) ---------- */
const Typing = {
  set(chatId, uid2, name) {
    if (!S.me || uid2 === S.me.id) return;
    let m = S.typingMap.get(chatId); if (!m) { m = new Map(); S.typingMap.set(chatId, m); }
    m.set(uid2, { n: name, until: Date.now() + 4800 });
    App.refresh(); setTimeout(() => App.refresh(), 5000);
  },
  names(chatId) {
    const m = S.typingMap.get(chatId); if (!m) return [];
    const now = Date.now(), out = [];
    for (const [u, v] of m) { if (v.until > now) out.push(displayName(u) || v.n); else m.delete(u); }
    return out;
  }
};

/* ---------- sync: WebSocket push + fast polling fallback ---------- */
const Sync = {
  timer: null, busyP: null, lastNow: 0, ws: null, wsOk: false, wsTimer: null, hb: null, backoff: 1000, again: false, touched: Date.now(), notified: new Set(),
  start() { S.active = true; this.stop(); S.active = true; this.wsFails = 0; this.touched = Date.now(); this.connect(); this.schedule(0); },
  /* what is saved with the chats on the phone: where the next sync continues from */
  state() { return { v: 1, ver: S.ver, cur: S.cur, listAt: S.listAt, blocked: [...S.blocked] }; },
  /* the person is using the app: poll faster; idle: poll slower (every poll costs a few database reads) */
  touch() { const was = Date.now() - this.touched; this.touched = Date.now(); if (was > 30000 && S.active) this.kick(); },
  delay() {
    let d = this.wsOk ? (S.openChat ? 20000 : 30000) : (S.openChat ? 3000 : 6000);
    const idle = Date.now() - this.touched;
    if (idle > 120000) d *= 3; else if (idle > 30000) d *= 2;
    return Math.min(d, 60000);
  },
  stop() { clearTimeout(this.timer); clearTimeout(this.wsTimer); clearInterval(this.hb); this.closeWs(); },
  closeWs() { if (this.ws) { try { this.ws.onclose = null; this.ws.close(); } catch (e) { /* ignore */ } this.ws = null; } this.wsOk = false; },
  connect() {
    if (!S.active || !S.token || !serverUrl() || this.ws || typeof WebSocket === 'undefined') return;
    let ws;
    try { ws = new WebSocket(serverUrl().replace(/^http/, 'ws') + '/api/ws', ['calc', 'bearer.' + S.token]); } catch (e) { return; }
    this.ws = ws;
    ws.onopen = () => { this.wsOk = true; this.wsFails = 0; this.backoff = 1000; clearInterval(this.hb); this.hb = setInterval(() => { try { ws.send('ping'); } catch (e) { /* ignore */ } }, 25000); this.kick(); };
    ws.onmessage = (ev) => {
      if (ev.data === 'pong') return;
      let j = {}; try { j = JSON.parse(ev.data); } catch (e) { return; }
      if (j.k === 't') { Typing.set(j.c, j.u, j.n); return; }     // typing is only shown: no need to ask the server again
      this.kick();
    };
    ws.onclose = () => {
      clearInterval(this.hb); this.ws = null;
      if (!this.wsOk) this.wsFails = (this.wsFails || 0) + 1;
      this.wsOk = false;
      if (S.active && this.wsFails < 5) this.wsTimer = setTimeout(() => this.connect(), Math.min(120000, (this.backoff *= 2)));
    };
    ws.onerror = () => { try { ws.close(); } catch (e) { /* ignore */ } };
  },
  schedule(ms) { clearTimeout(this.timer); if (S.active) this.timer = setTimeout(() => this.tick(), ms); },
  kick() { if (!S.active) return; if (this.busyP) this.again = true; else this.schedule(0); },
  async now() { if (this.busyP) await this.busyP; return this.tick(true); },
  tick(force) {
    if (!S.active) return Promise.resolve();
    if (this.busyP) return this.busyP;
    if (document.hidden && !force) { this.schedule(2500); return Promise.resolve(); }
    /* limit reached: wait (a few minutes) instead of asking again and again */
    if (Quota.active() && !force) { this.schedule(Math.min(300000, Math.max(5000, Quota.until - Date.now()))); return Promise.resolve(); }
    this.busyP = (async () => {
      let more = false;
      try {
        let q = S.ver === null ? '' : '?since=' + S.ver + '&cur=' + (S.cur || 0);
        const add = (s) => { q += (q ? '&' : '?') + s; };
        if (S.openChat) {
          add('chat=' + S.openChat);
          if (this.wsOk) add('typ=0');                                   // typing arrives through the live connection
          const oc = S.chats.get(S.openChat);
          if (!oc || oc.type !== 'dm') add('seen=0');                    // "last seen" is only shown in 1:1 chats
        }
        const r = await api('/api/sync' + q, { timeout: 15000, quiet: false, bg: !force });
        await applySync(r);
        more = !!r.more;
        if (S.offline) { S.offline = false; App.pollMe(true); }
      } catch (e) { /* retry next tick */ }
      this.busyP = null;
      const again = this.again || more; this.again = false;
      this.schedule(again ? 0 : this.delay());
    })();
    return this.busyP;
  }
};
function setRc(x) {
  let m = S.rc.get(x[0]); if (!m) { m = new Map(); S.rc.set(x[0], m); }
  m.set(x[1], [x[2], x[3]]);
}
const msgCmp = (a, b) => a.at - b.at || (a.id < b.id ? -1 : 1);
function upsertMsg(m) {
  if (!S.hist.has(m.chat_id) && !Hist.loading.has(m.chat_id)) return false;
  const arr = S.msgs.get(m.chat_id) || [];
  const i = arr.findIndex((x) => x.id === m.id);
  if (i >= 0) { if (arr[i].up > m.up) return false; arr[i] = m; }
  else { arr.push(m); arr.sort(msgCmp); }
  S.msgs.set(m.chat_id, arr);
  return true;
}
/* forget everything of a chat up to a time (the chat was cleared here or on another phone) */
function purgeChat(id, upto) {
  const a = S.msgs.get(id); if (a) S.msgs.set(id, a.filter((m) => m.at > upto));
  if (Disk.has(id)) Disk.setHist(id, false);
  Disk.purge(id, upto);
}
async function applySync(r) {
  const prevNow = Sync.lastNow; Sync.lastNow = r.now;
  const full = !!r.full;
  const verBefore = S.ver;
  if (full) { S.chats.clear(); S.msgs.clear(); S.hist.clear(); S.rc.clear(); await Disk.reset(); }
  if (r.blocked) S.blocked = new Set(r.blocked);
  for (const c of r.chats || []) {
    for (const m of c.members) {
      S.users.set(m.id, Object.assign(S.users.get(m.id) || {}, m));
      if (m.pk) {
        const old = store.get('pk_' + m.id, null);
        if (old && old !== m.pk && m.id !== S.me.id) { S.keyChanged.add(m.id); toast(t('key_changed', { n: displayName(m.id) })); }
        store.set('pk_' + m.id, m.pk); E2E.setPub(m.id, m.pk);
      }
    }
  }
  await decryptAll([...(r.msgs || []), ...(r.chats || []).map((c) => c.last).filter(Boolean)]);
  let closeOpen = false;
  for (const c of r.chats || []) {
    const old = S.chats.get(c.id);
    if (c.gone) { S.chats.delete(c.id); S.msgs.delete(c.id); S.hist.delete(c.id); Disk.dropChat(c.id); if (S.openChat === c.id) closeOpen = true; continue; }
    if (old && (c.clr || 0) > (old.clr || 0)) purgeChat(c.id, c.clr);
    S.chats.set(c.id, c); Disk.touchChat(c);
  }
  for (const x of r.rcs || []) { setRc(x); Disk.touchRc(x[0]); }
  const incoming = [];
  for (const m of r.msgs || []) {
    upsertMsg(m);
    if (Disk.has(m.chat_id)) Disk.touchMsg(m);             // chats that are saved on the phone stay complete
    /* a really new message from someone else (the server repeats the last 15 s on purpose, so remember what was announced) */
    if (!full && prevNow && m.sid !== S.me.id && m.type !== 'sys' && m.up === m.at && !m.del && Date.now() - m.at < 30000 && !Sync.notified.has(m.id)) {
      Sync.notified.add(m.id); if (Sync.notified.size > 400) Sync.notified.clear();
      incoming.push(m);
    }
  }
  S.ver = r.ver; S.cur = r.cur || r.now; S.cacheUid = S.me.id;
  if (r.typing) S.typing = r.typing; else if (!Sync.wsOk) S.typing = [];
  S.seen = r.seen || (S.openChat ? S.seen : []);
  /* save what changed together with the position to continue from (idle polls change nothing, so nothing is written) */
  if (full || r.chats || r.msgs || r.more || S.ver !== verBefore) Disk.save(Sync.state());
  if (full || (r.chats && r.chats.length) || (r.msgs && r.msgs.length)) Sync.touched = Math.max(Sync.touched, Date.now() - 20000);
  for (const m of incoming) {
    const c = S.chats.get(m.chat_id);
    if (!c || c.muted || S.blocked.has(m.sid) || (S.openChat === m.chat_id && !document.hidden)) continue;
    beep();
    toast(c.locked ? t('new_msg') : chatTitle(c) + ': ' + previewText(m, c).slice(0, 60));
  }
  if (closeOpen) Nav.popTo(Math.max(1, Nav.stack.findIndex((s) => s.name === 'chat')));
  App.refresh();
}

/* ---------- history of one chat: memory first, then this phone, and only then the server (30 messages per page) ---------- */
const Hist = {
  loading: new Set(),
  fromRow(row) { const m = Object.assign({}, row); delete m.k; return m; },
  merge(id, list) {
    const map = new Map((S.msgs.get(id) || []).map((m) => [m.id, m]));
    for (const m of list) { const o = map.get(m.id); if (!o || o.up < m.up) map.set(m.id, m); }
    S.msgs.set(id, [...map.values()].sort(msgCmp));
  },
  async diskRcs(msgs) {
    const ids = msgs.filter((m) => m.sid === S.me.id).map((m) => m.id);
    for (const e of await Disk.rcFor(ids)) for (const x of e.r) setRc([e.id, x[0], x[1], x[2]]);
  },
  /* newest page of a chat -> memory */
  async loadChat(id) {
    const have = S.hist.get(id); if (have && !have.partial) return;
    this.loading.add(id);
    try {
      let rows = [];
      const d = Disk.has(id) ? Disk.disk.get(id) : null;
      if (d) rows = await Disk.page(id, undefined, PAGE);
      if (d && (rows.length || !d.more)) {
        const msgs = rows.map(this.fromRow);
        await decryptAll(msgs); await this.diskRcs(msgs);
        this.merge(id, msgs); S.hist.set(id, { more: rows.length >= PAGE || !!d.more });
        return;
      }
      const r = await api('/api/chats/' + id + '/messages?limit=' + PAGE);
      await decryptAll(r.msgs);
      r.rcs.forEach((x) => { setRc(x); Disk.touchRc(x[0]); });
      this.merge(id, r.msgs); S.hist.set(id, { more: !!r.more });
      if (Disk.ok()) { r.msgs.forEach((m) => Disk.touchMsg(m)); Disk.setHist(id, !!r.more); }
    } finally { this.loading.delete(id); }
  },
  /* the page before the oldest message we show */
  async older(id, big) {
    const st = S.hist.get(id); if (!st || !st.more) return 0;
    const lim = big ? 100 : PAGE;
    const arr = S.msgs.get(id) || [];
    const before = arr.length ? arr[0].at : 0;
    const d = Disk.has(id) ? Disk.disk.get(id) : null;
    let rows = (d && before) ? await Disk.page(id, before, lim) : [];
    if (!rows.length && d && !d.more) { S.hist.set(id, { more: false }); return 0; }   // everything is already here
    let msgs, more;
    if (rows.length >= lim || (rows.length && !d.more)) {
      msgs = rows.map(this.fromRow); more = rows.length >= lim || !!d.more;
      await decryptAll(msgs); await this.diskRcs(msgs);
    } else {
      const edge = rows.length ? rows[0].at : before;
      const r = await api('/api/chats/' + id + '/messages?limit=' + lim + (big ? '&big=1' : '') + (edge ? '&before=' + edge : ''));
      const fresh = r.msgs;
      msgs = rows.map(this.fromRow).concat(fresh); more = !!r.more;
      await decryptAll(msgs); await this.diskRcs(msgs.slice(0, rows.length));
      r.rcs.forEach((x) => { setRc(x); Disk.touchRc(x[0]); });
      if (Disk.ok()) { fresh.forEach((m) => Disk.touchMsg(m)); Disk.setHist(id, more); }
    }
    this.merge(id, msgs); S.hist.set(id, { more });
    return msgs.length;
  },
  /* the whole history (backup): large pages, up to a limit */
  async all(id, max, onProgress) {
    const h0 = S.hist.get(id); if (!h0 || h0.partial) await this.loadChat(id);
    for (let guard = 0; guard < 200; guard++) {
      const st = S.hist.get(id), have = (S.msgs.get(id) || []).length;
      if (!st || !st.more || have >= max) break;
      if (!(await this.older(id, true))) break;
      if (onProgress) onProgress((S.msgs.get(id) || []).length);
    }
    return S.msgs.get(id) || [];
  }
};

/* ---------- main screen ---------- */
const Main = { lockUntil: 0, lockMatch: false, tab: 'chats', show: null };
function chatRow(c, opts) {
  opts = opts || {};
  const last = c.last, mine = last && last.sid === S.me.id && last.type !== 'sys';
  const peer = c.type === 'dm' ? peerOf(c) : null;
  const typing = Typing.names(c.id);
  const self = isSelf(c);
  const row = h('div', { class: 'crow', onclick: () => Chat.open(c.id) },
    self ? h('div', { class: 'av selfav', style: { width: '50px', height: '50px' } }, ic('user', 24)) : avatar(chatTitle(c), 50, c.type === 'group', peer ? { id: peer.id, av: peer.av } : null),
    h('div', { class: 'cmid' },
      h('div', { class: 'cl1' }, c.pinned ? ic('pin', 14, 'mu') : null, h('span', { class: 'cname' }, chatTitle(c)), opts.tag ? h('span', { class: 'ctag' }, opts.tag) : null, h('span', { class: 'ctime' + (c.unread ? ' un' : '') }, last ? fmtList(last.at) : '')),
      h('div', { class: 'cl2' }, typing.length ? null : (mine && !last.del && tickEl(self ? [[S.me.id, 1, 1]] : rcOf(last.id), false)),
        typing.length ? h('span', { class: 'cprev typ' }, c.type === 'group' ? typing.map((n) => n.split(' ')[0]).join(', ') + ' ' + t('typing') : t('typing'))
          : h('span', { class: 'cprev' }, previewText(last, c)),
        c.muted ? ic('mute', 16, 'mu') : null, c.unread ? h('span', { class: 'badge' + (c.muted ? ' m' : '') }, c.unread > 99 ? '99+' : c.unread) : null)));
  onLong(row, () => chatMenu(c));
  return row;
}
async function chatMenu(c) {
  const v = await sheet([
    { v: 'pin', icon: 'pin', label: c.pinned ? t('unpin') : t('pin') },
    { v: 'mute', icon: 'mute', label: c.muted ? t('unmute') : t('mute') },
    { v: 'lock', icon: 'lock', label: c.locked ? t('unlock_chat') : t('lock_chat') },
    { v: 'clear', icon: 'trash', label: t('clear_chat'), danger: true },
    c.type === 'group' && { v: 'leave', icon: 'back', label: t('leave_group'), danger: true }]);
  if (v) Chat.action(c, v);
}
function sortedChats(filter, q) {
  const qq = (q || '').trim().toLowerCase();
  return [...S.chats.values()].filter(filter).filter((c) => !qq || chatTitle(c).toLowerCase().includes(qq) || previewText(c.last, c).toLowerCase().includes(qq))
    .sort((a, b) => ((b.pinned || 0) - (a.pinned || 0)) || ((b.last ? b.last.at : b.up) - (a.last ? a.last.at : a.up)));
}
function attachPull(scroller, inner, onPull) {
  let y0 = null, dy = 0;
  scroller.addEventListener('touchstart', (e) => { if (scroller.scrollTop <= 0) { y0 = e.touches[0].clientY; dy = 0; } else y0 = null; }, { passive: true });
  scroller.addEventListener('touchmove', (e) => {
    if (y0 === null) return; dy = e.touches[0].clientY - y0;
    if (dy > 0) { inner.style.transition = 'none'; inner.style.transform = 'translateY(' + Math.min(dy * 0.45, 64) + 'px)'; }
  }, { passive: true });
  const end = () => { if (y0 === null) return; inner.style.transition = 'transform .22s'; inner.style.transform = ''; if (dy > 110) onPull(); y0 = null; dy = 0; };
  scroller.addEventListener('touchend', end); scroller.addEventListener('touchcancel', end);
}
async function lockVerify(pw) { return !!(S.me.lock_hash && (await pbk(pw, S.me.lock_salt)) === S.me.lock_hash); }
async function setLockPassword(newPw) {
  const salt = [...crypto.getRandomValues(new Uint8Array(8))].map((x) => x.toString(16).padStart(2, '0')).join('');
  const hash = await pbk(newPw, salt);
  await api('/api/lock', { body: { salt, hash } });
  S.me.lock_salt = salt; S.me.lock_hash = hash;
}
async function createLockPassword() {
  for (;;) {
    const v = await ask(t('lock_create'), [{ label: t('lock_pw'), pw: true, hint: t('lock_pw_hint') }, { label: t('f_pw2'), pw: true }], t('save'), t('lock_create_text'));
    if (!v) return false;
    if (v[0].length < 4) { toast(t('e_lock_short')); continue; }
    if (v[0] !== v[1]) { toast(t('e_pw_mismatch')); continue; }
    try { await setLockPassword(v[0]); return true; } catch (e) { toast(errText(e)); return false; }
  }
}
async function openLocked(verified) {
  if (!S.me.lock_hash) { if (!(await createLockPassword())) return; verified = true; }
  if (!verified) {
    for (;;) {
      const v = await ask(t('locked_chats'), [{ label: t('lock_pw'), pw: true }], t('unlock'));
      if (!v) return;
      if (await lockVerify(v[0])) break;
      toast(t('e_lock_wrong'));
    }
  }
  S.lockOpen = true; Main.lockMatch = false;
  Nav.push(lockedScreen(), 'locked');
}
function lockedScreen() {
  const el = h('div', { class: 'main' });
  const list = h('div', { class: 'clist' });
  const draw = () => {
    const rows = sortedChats((c) => c.locked, '');
    list.replaceChildren(...rows.map((c) => chatRow(c)), rows.length ? null : h('div', { class: 'empty' }, ic('lock', 40), h('p', null, t('locked_empty'))));
  };
  el._draw = draw; el._leave = () => { S.lockOpen = false; };
  el.append(header(t('locked_chats'), { actions: h('button', { class: 'ib', onclick: lockSettings }, ic('sliders', 22)) }), list);
  draw();
  return el;
}
async function lockSettings() {
  const v = await sheet([
    { v: 'pw', icon: 'lock', label: t('lock_change') },
    { v: 'hide', icon: S.me.lock_hidden ? 'eye' : 'eyeoff', label: S.me.lock_hidden ? t('lock_show_pull') : t('lock_hide_pull') }]);
  if (v === 'pw') {
    for (;;) {
      const x = await ask(t('lock_change'), [{ label: t('lock_cur'), pw: true }, { label: t('lock_new'), pw: true }, { label: t('f_pw2'), pw: true }], t('save'));
      if (!x) return;
      if (!(await lockVerify(x[0]))) { toast(t('e_lock_wrong')); continue; }
      if (x[1].length < 4) { toast(t('e_lock_short')); continue; }
      if (x[1] !== x[2]) { toast(t('e_pw_mismatch')); continue; }
      try { await setLockPassword(x[1]); toast(t('saved')); } catch (e) { toast(errText(e)); }
      return;
    }
  } else if (v === 'hide') {
    const nv = !S.me.lock_hidden;
    await dialog({ title: nv ? t('lock_hide_pull') : t('lock_show_pull'), text: nv ? t('lock_hide_text') : t('lock_show_text'), ok: t('ok'), cancel: false });
    try { await api('/api/lock', { body: { hidden: nv } }); S.me.lock_hidden = nv; toast(t('saved')); } catch (e) { toast(errText(e)); }
  }
}

function requestsScreen() {
  const el = h('div', { class: 'main' });
  const list = h('div', { class: 'clist' });
  const draw = () => {
    const rows = sortedChats(isRequest, '');
    list.replaceChildren(h('p', { class: 'muted s pad2' }, t('requests_hint')), ...rows.map((c) => chatRow(c, { tag: t('not_subscribed') })), rows.length ? null : h('div', { class: 'empty' }, ic('users', 40), h('p', null, t('requests_empty'))));
  };
  el._draw = draw; el.append(header(t('requests')), list); draw();
  return el;
}

/* calm note (not an error) while the free daily limit of the server is used up */
function quotaBanner() {
  if (!Quota.active()) return null;
  return h('div', { class: 'qbanner' }, ic('clock', 20), h('div', null, h('b', null, t('quota_title')), h('span', null, t('quota_sub', { t: Quota.when() }))));
}

function chatsView() {
  const wrap = h('div', { class: 'cview' });
  const search = h('input', { type: 'search', placeholder: t('search_ph'), autocomplete: 'off', autocapitalize: 'off', name: 'q-' + Date.now() });
  const banner = h('div', { class: 'ubanner-w' });
  const inner = h('div', { class: 'clist-in' });
  const scroller = h('div', { class: 'clist' }, inner);
  let st;
  const lockRow = (count) => h('button', { class: 'lockrow', onclick: () => { search.value = ''; Main.lockUntil = 0; draw(); openLocked(); } }, ic('lock', 20), h('span', null, t('locked_chats')), count ? h('span', { class: 'cnt' }, count) : null);
  const draw = () => {
    const lockCount = [...S.chats.values()].filter((c) => c.locked).length;
    if (Main.lockMatch === 'verified') {
      inner.replaceChildren(h('button', { class: 'lockrow big', onclick: () => { search.value = ''; Main.lockMatch = false; draw(); openLocked(true); } }, ic('lock', 24), h('span', null, t('locked_chats')), lockCount ? h('span', { class: 'cnt' }, lockCount) : null));
      banner.replaceChildren(); return;
    }
    const rows = sortedChats((c) => !c.locked && !isRequest(c), search.value);
    const reqs = search.value ? [] : sortedChats(isRequest, '');
    const reqUnread = reqs.reduce((a, c) => a + (c.unread || 0), 0);
    const showLock = Date.now() < Main.lockUntil && !S.me.lock_hidden;
    inner.replaceChildren(
      showLock && lockRow(lockCount),
      reqs.length ? h('button', { class: 'lockrow req', onclick: () => Nav.push(requestsScreen(), 'requests') }, ic('users', 20), h('span', null, t('requests')), h('span', { class: 'cnt' + (reqUnread ? ' un' : '') }, reqUnread || reqs.length)) : null,
      ...rows.map((c) => chatRow(c)),
      rows.length ? null : h('div', { class: 'empty' }, ic('chat', 44), h('p', null, S.chats.size ? t('no_results') : t('chats_empty')), S.chats.size ? null : h('p', { class: 'muted' }, t('chats_empty_hint'))));
    banner.replaceChildren(...[quotaBanner(), updateBanner()].filter(Boolean));
  };
  search.addEventListener('input', () => {
    clearTimeout(st);
    const q = search.value;
    if (Main.lockMatch) { Main.lockMatch = false; }
    draw();
    if (S.me.lock_hidden && S.me.lock_hash && q.length >= 4) {
      st = setTimeout(async () => { if (search.value === q && await lockVerify(q)) { Main.lockMatch = 'verified'; draw(); } }, 300);
    }
  });
  attachPull(scroller, inner, () => {
    if (S.me.lock_hidden) return;
    Main.lockUntil = Date.now() + 9000; draw(); setTimeout(draw, 9100);
  });
  wrap.append(h('div', { class: 'searchw' }, ic('search', 18), search), banner, scroller,
    h('button', { class: 'fab', onclick: () => Nav.push(newChatScreen(), 'newchat') }, ic('pen', 24)));
  wrap._draw = draw;
  wrap._clear = () => { search.value = ''; Main.lockMatch = false; Main.lockUntil = 0; draw(); };
  draw();
  return wrap;
}

function mainScreen() {
  const el = h('div', { class: 'main' });
  const content = h('div', { class: 'mcontent' });
  let view = null, tab = 'chats';
  const badge = h('span', { class: 'nbadge' });
  const title = h('div', { class: 'ttl big' }, t('chats'));
  const nav = h('div', { class: 'bnav' });
  const show = (tb) => {
    tab = tb; Main.tab = tb;
    content.replaceChildren();
    view = tb === 'chats' ? chatsView() : settingsView();
    content.append(view);
    title.textContent = tb === 'chats' ? t('chats') : t('settings');
    drawNav();
  };
  const drawNav = () => {
    const b = (id, icn, label, extra) => h('button', { class: 'nb' + (tab === id ? ' on' : ''), onclick: () => show(id) }, h('span', { class: 'nbi' }, ic(icn, 24), extra), h('span', null, label));
    nav.replaceChildren(b('chats', 'chat', t('chats'), badge), b('settings', 'sliders', t('settings')));
  };
  const menu = async () => {
    const v = await sheet([{ v: 'group', icon: 'users', label: t('new_group') }, { v: 'contacts', icon: 'user', label: t('contacts') }, S.me.role === 'owner' && { v: 'owner', icon: 'crown', label: t('owner_panel') },
      { v: 'settings', icon: 'sliders', label: t('settings') }, { v: 'hide', icon: 'calc', label: t('back_to_calc') }]);
    if (v === 'group') Nav.push(newGroupScreen(), 'newgroup');
    else if (v === 'contacts') Nav.push(contactsScreen(), 'contacts');
    else if (v === 'owner') Nav.push(ownerPanel(), 'owner');
    else if (v === 'settings') show('settings');
    else if (v === 'hide') App.lockApp();
  };
  el.append(h('div', { class: 'hdr main-h' }, title, h('span', { class: 'sp' }), h('button', { class: 'ib', onclick: menu }, ic('more', 22))), content, nav);
  el._refresh = () => {
    if (view && view._draw) view._draw();
    const n = [...S.chats.values()].filter((c) => !c.locked && !c.muted).reduce((a, c) => a + (c.unread || 0), 0);
    badge.textContent = n > 99 ? '99+' : n; badge.style.display = n ? '' : 'none';
  };
  el._show = () => { if (view && view._clear) view._clear(); el._refresh(); };
  Main.show = show;
  show('chats');
  return el;
}

/* ---------- start chats, contacts, groups ---------- */
async function startDm(query, userId) {
  const r = await api('/api/chats/dm', { body: userId ? { user_id: userId } : { query } });
  if (!S.chats.has(r.chat_id)) await Sync.now();
  return r.chat_id;
}
async function startSelf() {
  const r = await api('/api/chats/self', { body: {} });
  if (!S.chats.has(r.chat_id)) await Sync.now();
  return r.chat_id;
}
function contactList() {
  const seen = new Map();
  for (const c of S.chats.values()) if (c.type === 'dm') { const p = peerOf(c); if (p) seen.set(p.id, { id: p.id, full_name: p.full_name, username: p.username, av: p.av }); }
  for (const c of S.contacts.values()) seen.set(c.id, { id: c.id, full_name: c.full_name, username: c.username, av: c.av });
  return [...seen.values()].sort((a, b) => displayName(a.id).localeCompare(displayName(b.id)));
}
function contactRow(u, onTap, extra) {
  return h('div', { class: 'lrow', onclick: onTap }, avatar(displayName(u.id), 44, false, u), h('span', null, h('b', null, displayName(u.id)), h('small', null, '@' + u.username)), extra);
}
function newChatScreen() {
  const el = h('div', { class: 'main' });
  const q = h('input', { placeholder: t('nc_ph'), autocapitalize: 'off', autocomplete: 'off', spellcheck: false });
  const err = h('div', { class: 'err' });
  const btn = h('button', { class: 'btn primary wide' }, ic('chat', 18), t('start_chat'));
  const go = async (query, id) => {
    err.textContent = ''; if (!query && !id) return; btn.disabled = true;
    try { const cid = await startDm(query, id); Nav.pop(); Chat.open(cid); }
    catch (e) { err.textContent = errText(e); btn.disabled = false; }
  };
  btn.addEventListener('click', () => go(q.value.trim()));
  q.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(q.value.trim()); });
  const cs = contactList();
  el.append(header(t('new_chat')), h('div', { class: 'pad' }, field(t('nc_label'), q, t('nc_hint')), err, btn,
    h('button', { class: 'lrow', onclick: () => { Nav.pop(); Nav.push(newContactScreen(), 'newcontact'); } }, h('span', { class: 'lic' }, ic('user', 22)), t('new_contact')),
    h('button', { class: 'lrow', onclick: () => { Nav.pop(); Nav.push(newGroupScreen(), 'newgroup'); } }, h('span', { class: 'lic' }, ic('users', 22)), t('new_group')),
    h('button', { class: 'lrow', onclick: async () => { try { const cid = await startSelf(); Nav.pop(); Chat.open(cid); } catch (e) { err.textContent = errText(e); } } }, h('span', { class: 'lic self' }, ic('user', 22)), h('span', null, h('b', null, t('message_yourself')), h('small', null, t('message_yourself_sub')))),
    cs.length ? h('div', { class: 'sect' }, t('contacts')) : null,
    cs.map((u) => contactRow(u, () => go(null, u.id)))));
  setTimeout(() => q.focus(), 300);
  return el;
}
function newContactScreen(prefill) {
  const el = h('div', { class: 'main' });
  const nm = h('input', { placeholder: t('contact_name_ph'), maxLength: 60, value: (prefill && prefill.name) || '' });
  const q = h('input', { placeholder: t('nc_ph'), autocapitalize: 'off', spellcheck: false, value: (prefill && prefill.query) || '' });
  const err = h('div', { class: 'err' });
  const save = async (open) => {
    err.textContent = '';
    if (!nm.value.trim()) return (err.textContent = t('e_contact_name'));
    if (!q.value.trim()) return (err.textContent = t('e_user_not_found'));
    try {
      const r = await api('/api/contacts', { body: { query: q.value.trim(), name: nm.value.trim() }, quiet: true });
      S.contacts.set(r.contact.id, r.contact); if (r.contact.pk) E2E.setPub(r.contact.id, r.contact.pk);
      toast(t('contact_saved')); Nav.pop(); App.refresh();
      if (open) { const cid = await startDm(null, r.contact.id); Chat.open(cid); }
    } catch (e) { err.textContent = errText(e); }
  };
  el.append(header(t('new_contact')), h('div', { class: 'pad' }, field(t('contact_name'), nm, t('contact_name_hint')), field(t('nc_label'), q, t('nc_hint')), err,
    h('button', { class: 'btn primary wide', onclick: () => save(false) }, t('save')), h('button', { class: 'btn ghost wide', onclick: () => save(true) }, ic('chat', 18), t('save_and_message'))));
  setTimeout(() => nm.focus(), 300);
  return el;
}
async function editContact(id) {
  const c = S.contacts.get(id);
  const v = await sheet([{ v: 'rename', icon: 'pen', label: t('rename_contact') }, c && { v: 'delete', icon: 'trash', label: t('delete_contact'), danger: true }]);
  try {
    if (v === 'rename') {
      const x = await ask(t('rename_contact'), [{ label: t('contact_name'), value: displayName(id), max: 60 }], t('save'));
      if (!x || !x[0].trim()) return;
      if (c) await api('/api/contacts/' + id, { method: 'PATCH', body: { name: x[0].trim() } });
      else { const u = S.users.get(id) || {}; const r = await api('/api/contacts', { body: { user_id: id, name: x[0].trim() } }); S.contacts.set(id, r.contact); }
      if (c) c.name = x[0].trim();
      toast(t('saved')); App.refresh();
    } else if (v === 'delete') {
      if (!(await dialog({ title: t('delete_contact'), text: displayName(id), ok: t('delete'), danger: true }))) return;
      await api('/api/contacts/' + id, { method: 'DELETE' }); S.contacts.delete(id); toast(t('saved')); App.refresh();
    }
  } catch (e) { toast(errText(e)); }
}
function contactsScreen() {
  const el = h('div', { class: 'main' });
  const search = h('input', { type: 'search', placeholder: t('search_name'), autocomplete: 'off' });
  const list = h('div', { class: 'pad nopad' });
  const draw = () => {
    const q = search.value.trim().toLowerCase();
    const cs = contactList().filter((u) => !q || displayName(u.id).toLowerCase().includes(q) || u.username.includes(q));
    list.replaceChildren(h('button', { class: 'lrow', onclick: () => Nav.push(newContactScreen(), 'newcontact') }, h('span', { class: 'lic' }, ic('plus', 22)), t('new_contact')),
      ...cs.map((u) => contactRow(u, async () => { try { const cid = await startDm(null, u.id); Chat.open(cid); } catch (e) { toast(errText(e)); } },
        h('button', { class: 'ib sm', onclick: (e) => { e.stopPropagation(); editContact(u.id); } }, ic('pen', 18)))),
      cs.length ? null : h('p', { class: 'muted center' }, t('no_results')));
  };
  search.addEventListener('input', draw);
  el.append(header(t('contacts')), h('div', { class: 'searchw' }, ic('search', 18), search), list);
  el._draw = draw; draw();
  return el;
}
function newGroupScreen() {
  const el = h('div', { class: 'main' });
  const sel = new Map();
  const name = h('input', { placeholder: t('group_name'), maxLength: 60 });
  const err = h('div', { class: 'err' });
  const chips = h('div', { class: 'chips' });
  const list = h('div');
  const draw = () => {
    chips.replaceChildren(...[...sel.values()].map((u) => h('span', { class: 'chip', onclick: () => { sel.delete(u.id); draw(); } }, displayName(u.id).split(' ')[0], ' \u00d7')));
    const cs = contactList();
    sel.forEach((u) => { if (!cs.find((x) => x.id === u.id)) cs.push(u); });
    list.replaceChildren(...cs.map((u) => h('button', { class: 'lrow' + (sel.has(u.id) ? ' sel' : ''), onclick: () => { sel.has(u.id) ? sel.delete(u.id) : sel.set(u.id, u); draw(); } },
      avatar(displayName(u.id), 44, false, u), h('span', null, h('b', null, displayName(u.id)), h('small', null, '@' + u.username)), h('span', { class: 'ck2' }, sel.has(u.id) ? ic('check', 18) : null))));
  };
  const addQ = h('input', { placeholder: t('nc_ph'), autocapitalize: 'off', spellcheck: false });
  const addBtn = h('button', { class: 'btn ghost', onclick: async () => {
    const v = addQ.value.trim(); if (!v) return;
    try { const r = await api('/api/lookup?q=' + encodeURIComponent(v), { quiet: true }); sel.set(r.user.id, r.user); S.users.set(r.user.id, Object.assign(S.users.get(r.user.id) || {}, r.user)); addQ.value = ''; err.textContent = ''; draw(); }
    catch (e) { err.textContent = errText(e); }
  } }, ic('plus', 18));
  const create = h('button', { class: 'btn primary wide' }, t('create_group'));
  create.addEventListener('click', async () => {
    err.textContent = '';
    if (!name.value.trim()) return (err.textContent = t('e_bad_name_group'));
    create.disabled = true;
    try { const r = await api('/api/chats/group', { body: { name: name.value.trim(), members: [...sel.keys()] } }); await Sync.now(); Nav.pop(); Chat.open(r.chat_id); }
    catch (e) { err.textContent = errText(e); create.disabled = false; }
  });
  el.append(header(t('new_group')), h('div', { class: 'pad' }, field(t('group_name'), name), chips, h('div', { class: 'addrow' }, addQ, addBtn),
    h('div', { class: 'sect' }, t('add_members')), list, err, create));
  draw();
  return el;
}

/* any touch / key press = the person is here: keep the sync fast */
['touchstart', 'pointerdown', 'keydown'].forEach((ev) => document.addEventListener(ev, () => Sync.touch(), { passive: true, capture: true }));
