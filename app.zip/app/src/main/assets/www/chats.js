'use strict';
/* ---------- shared chat helpers ---------- */
const peerOf = (c) => c.members.find((m) => m.id !== S.me.id);
const chatTitle = (c) => (c.type === 'group' ? c.name : (peerOf(c) ? peerOf(c).full_name : t('chat')));
const userName = (id) => (id === S.me.id ? t('you') : ((S.users.get(id) || {}).full_name || t('unknown')));
const firstName = (id) => userName(id).split(' ')[0];
function sysText(m) {
  let o = {}; try { o = JSON.parse(m.body); } catch (e) { /* ignore */ }
  const k = 'sys_' + o.k;
  return I18N.en[k] ? t(k, o) : '';
}
function previewText(m, c) {
  if (!m) return '';
  if (m.del) return '\u2298 ' + t('msg_deleted');
  let s = '';
  if (m.type === 'text') s = m.body;
  else if (m.type === 'image') s = '\ud83d\udcf7 ' + (m.body || t('photo'));
  else if (m.type === 'video') s = '\ud83c\udfa5 ' + (m.body || t('video'));
  else if (m.type === 'audio') s = '\ud83c\udfa4 ' + t('voice') + (m.media && m.media.dur ? ' ' + fmtDur(m.media.dur) : '');
  else if (m.type === 'file') s = '\ud83d\udcc4 ' + ((m.media && m.media.name) || t('file'));
  else if (m.type === 'sys') return sysText(m);
  if (c && c.type === 'group' && m.sid !== S.me.id) s = firstName(m.sid) + ': ' + s;
  return s;
}
const rcOf = (mid) => { const r = S.rc.get(mid); return r ? [...r.entries()].map(([u, v]) => [u, v[0], v[1]]) : []; };
function tickEl(list, pending) {
  if (pending) return h('span', { class: 'tick pend' }, ic('clock', 12));
  let st = 1;
  if (list.length) st = list.every((x) => x[2]) ? 3 : (list.every((x) => x[1]) ? 2 : 1);
  return h('span', { class: 'tick s' + st, html: STAR_SVG + (st > 1 ? STAR_SVG : '') });
}
function onLong(el, fn) {
  let tm = null, sx = 0, sy = 0, fired = false;
  el.addEventListener('touchstart', (e) => { fired = false; sx = e.touches[0].clientX; sy = e.touches[0].clientY; tm = setTimeout(() => { fired = true; if (navigator.vibrate) navigator.vibrate(12); fn(e); }, 420); }, { passive: true });
  const cancel = () => clearTimeout(tm);
  el.addEventListener('touchmove', (e) => { if (Math.abs(e.touches[0].clientX - sx) > 8 || Math.abs(e.touches[0].clientY - sy) > 8) cancel(); }, { passive: true });
  el.addEventListener('touchend', (e) => { cancel(); if (fired) e.preventDefault(); });
  el.addEventListener('touchcancel', cancel);
  el.addEventListener('contextmenu', (e) => { e.preventDefault(); fn(e); });
}
let actx;
function beep() {
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const o = actx.createOscillator(), g = actx.createGain();
    o.frequency.value = 880; g.gain.value = 0.05; o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.1);
  } catch (e) { /* ignore */ }
}

/* ---------- sync ---------- */
const Sync = {
  timer: null, busyP: null, lastNow: 0,
  start() { S.active = true; this.stop(); this.schedule(0); },
  stop() { clearTimeout(this.timer); this.timer = null; },
  schedule(ms) { clearTimeout(this.timer); if (S.active) this.timer = setTimeout(() => this.tick(), ms); },
  kick() { if (S.active && !this.busyP) this.schedule(0); },
  async now() { if (this.busyP) await this.busyP; return this.tick(true); },
  tick(force) {
    if (!S.active) return Promise.resolve();
    if (this.busyP) return this.busyP;
    if (document.hidden && !force) { this.schedule(2500); return Promise.resolve(); }
    this.busyP = (async () => {
      try {
        let q = S.ver === null ? '' : '?since=' + S.ver;
        if (S.openChat) q += (q ? '&' : '?') + 'chat=' + S.openChat;
        const r = await api('/api/sync' + q, { timeout: 15000, quiet: false });
        applySync(r);
      } catch (e) { /* retry next tick */ }
      this.busyP = null;
      this.schedule(S.openChat ? 1700 : 3000);
    })();
    return this.busyP;
  }
};
function setRc(x) {
  let m = S.rc.get(x[0]); if (!m) { m = new Map(); S.rc.set(x[0], m); }
  m.set(x[1], [x[2], x[3]]);
}
function upsertMsg(m) {
  if (!S.hist.has(m.chat_id)) return false;
  const arr = S.msgs.get(m.chat_id) || [];
  const i = arr.findIndex((x) => x.id === m.id);
  if (i >= 0) { if (arr[i].up > m.up) return false; arr[i] = m; }
  else { arr.push(m); arr.sort((a, b) => a.at - b.at || (a.id < b.id ? -1 : 1)); }
  S.msgs.set(m.chat_id, arr);
  return true;
}
function applySync(r) {
  const prevNow = Sync.lastNow; Sync.lastNow = r.now;
  if (r.full) { S.chats.clear(); S.msgs.clear(); S.hist.clear(); S.rc.clear(); }
  if (r.blocked) S.blocked = new Set(r.blocked);
  let closeOpen = false;
  for (const c of r.chats || []) {
    for (const m of c.members) S.users.set(m.id, m);
    if (c.gone) { S.chats.delete(c.id); S.msgs.delete(c.id); S.hist.delete(c.id); if (S.openChat === c.id) closeOpen = true; continue; }
    S.chats.set(c.id, c);
    if (c.last && S.openChat !== c.id) { /* last shown from chat */ }
  }
  for (const x of r.rcs || []) setRc(x);
  const incoming = [];
  for (const m of r.msgs || []) {
    upsertMsg(m);
    if (!r.full && m.sid !== S.me.id && m.type !== 'sys' && m.up === m.at && m.at >= prevNow - 3500 && !m.del) incoming.push(m);
  }
  S.ver = r.ver;
  S.typing = r.typing || []; S.seen = r.seen || [];
  for (const m of incoming) {
    const c = S.chats.get(m.chat_id);
    if (!c || c.muted || S.blocked.has(m.sid) || (S.openChat === m.chat_id && !document.hidden)) continue;
    beep();
    toast(c.locked ? t('new_msg') : chatTitle(c) + ': ' + previewText(m, c).slice(0, 60));
  }
  if (closeOpen) { Nav.popTo(Math.max(1, Nav.stack.findIndex((s) => s.name === 'chat'))); }
  App.refresh();
}

/* ---------- main screen ---------- */
const Main = { renderList: null, tab: 'chats', lockUntil: 0, banner: null };
function chatRow(c, q) {
  const last = c.last, mine = last && last.sid === S.me.id && last.type !== 'sys';
  const row = h('div', { class: 'crow', onclick: () => Chat.open(c.id) },
    avatar(chatTitle(c), 50, c.type === 'group'),
    h('div', { class: 'cmid' },
      h('div', { class: 'cl1' }, h('span', { class: 'cname' }, chatTitle(c)), h('span', { class: 'ctime' + (c.unread ? ' un' : '') }, last ? fmtList(last.at) : '')),
      h('div', { class: 'cl2' }, mine && !last.del && tickEl(rcOf(last.id), false), h('span', { class: 'cprev' }, previewText(last, c)),
        c.muted ? ic('mute', 16, 'mu') : null, c.unread ? h('span', { class: 'badge' + (c.muted ? ' m' : '') }, c.unread > 99 ? '99+' : c.unread) : null)));
  onLong(row, () => chatMenu(c));
  return row;
}
async function chatMenu(c) {
  const v = await sheet([
    { v: 'mute', icon: 'mute', label: c.muted ? t('unmute') : t('mute') },
    { v: 'lock', icon: 'lock', label: c.locked ? t('unlock_chat') : t('lock_chat') },
    { v: 'clear', icon: 'trash', label: t('clear_chat'), danger: true },
    c.type === 'group' && { v: 'leave', icon: 'back', label: t('leave_group'), danger: true }]);
  if (v) Chat.action(c, v);
}
function sortedChats(filter, q) {
  const qq = (q || '').trim().toLowerCase();
  return [...S.chats.values()].filter(filter).filter((c) => !qq || chatTitle(c).toLowerCase().includes(qq) || previewText(c.last, c).toLowerCase().includes(qq))
    .sort((a, b) => ((b.last ? b.last.at : b.up) - (a.last ? a.last.at : a.up)));
}
function attachPull(scroller, inner, onPull) {
  let y0 = null, dy = 0;
  scroller.addEventListener('touchstart', (e) => { if (scroller.scrollTop <= 0) { y0 = e.touches[0].clientY; dy = 0; } else y0 = null; }, { passive: true });
  scroller.addEventListener('touchmove', (e) => {
    if (y0 === null) return; dy = e.touches[0].clientY - y0;
    if (dy > 0) { inner.style.transition = 'none'; inner.style.transform = 'translateY(' + Math.min(dy * 0.45, 64) + 'px)'; }
  }, { passive: true });
  const end = () => { if (y0 === null) return; inner.style.transition = 'transform .22s'; inner.style.transform = ''; if (dy > 110) onPull(); y0 = null; dy = 0; };
  scroller.addEventListener('touchend', end); scroller.addEventListener('touchcancel', end);
}
async function lockVerify(pw) {
  return !!(S.me.lock_hash && (await pbk(pw, S.me.lock_salt)) === S.me.lock_hash);
}
async function setLockPassword(newPw) {
  const salt = [...crypto.getRandomValues(new Uint8Array(8))].map((x) => x.toString(16).padStart(2, '0')).join('');
  const hash = await pbk(newPw, salt);
  await api('/api/lock', { body: { salt, hash } });
  S.me.lock_salt = salt; S.me.lock_hash = hash;
}
async function createLockPassword() {
  for (;;) {
    const v = await ask(t('lock_create'), [{ label: t('lock_pw'), pw: true, hint: t('lock_pw_hint') }, { label: t('f_pw2'), pw: true }], t('save'), t('lock_create_text'));
    if (!v) return false;
    if (v[0].length < 4) { toast(t('e_lock_short')); continue; }
    if (v[0] !== v[1]) { toast(t('e_pw_mismatch')); continue; }
    try { await setLockPassword(v[0]); return true; } catch (e) { toast(errText(e)); return false; }
  }
}
async function openLocked(verified) {
  if (!S.me.lock_hash) { if (!(await createLockPassword())) return; verified = true; }
  if (!verified) {
    for (;;) {
      const v = await ask(t('locked_chats'), [{ label: t('lock_pw'), pw: true }], t('unlock'));
      if (!v) return;
      if (await lockVerify(v[0])) break;
      toast(t('e_lock_wrong'));
    }
  }
  S.lockOpen = true;
  Nav.push(lockedScreen(), 'locked');
}
function lockedScreen() {
  const el = h('div', { class: 'main' });
  const list = h('div', { class: 'clist' });
  const draw = () => {
    const rows = sortedChats((c) => c.locked, '');
    list.replaceChildren(...rows.map((c) => chatRow(c)), rows.length ? null : h('div', { class: 'empty' }, ic('lock', 40), h('p', null, t('locked_empty'))));
  };
  el._draw = draw; el._leave = () => { S.lockOpen = false; };
  el.append(header(t('locked_chats'), { actions: h('button', { class: 'ib', onclick: lockSettings }, ic('sliders', 22)) }), list);
  draw();
  return el;
}
async function lockSettings() {
  const v = await sheet([
    { v: 'pw', icon: 'lock', label: t('lock_change') },
    { v: 'hide', icon: S.me.lock_hidden ? 'eye' : 'eyeoff', label: S.me.lock_hidden ? t('lock_show_pull') : t('lock_hide_pull') }]);
  if (v === 'pw') {
    for (;;) {
      const x = await ask(t('lock_change'), [{ label: t('lock_cur'), pw: true }, { label: t('lock_new'), pw: true }, { label: t('f_pw2'), pw: true }], t('save'));
      if (!x) return;
      if (!(await lockVerify(x[0]))) { toast(t('e_lock_wrong')); continue; }
      if (x[1].length < 4) { toast(t('e_lock_short')); continue; }
      if (x[1] !== x[2]) { toast(t('e_pw_mismatch')); continue; }
      try { await setLockPassword(x[1]); toast(t('saved')); } catch (e) { toast(errText(e)); }
      return;
    }
  } else if (v === 'hide') {
    const nv = !S.me.lock_hidden;
    await dialog({ title: nv ? t('lock_hide_pull') : t('lock_show_pull'), text: nv ? t('lock_hide_text') : t('lock_show_text'), ok: t('ok'), cancel: false });
    try { await api('/api/lock', { body: { hidden: nv } }); S.me.lock_hidden = nv; toast(t('saved')); } catch (e) { toast(errText(e)); }
  }
}

function chatsView() {
  const wrap = h('div', { class: 'cview' });
  const search = h('input', { type: 'search', placeholder: t('search_ph'), autocomplete: 'off', autocapitalize: 'off' });
  const banner = h('div', { class: 'ubanner-w' });
  const inner = h('div', { class: 'clist-in' });
  const scroller = h('div', { class: 'clist' }, inner);
  let st;
  const draw = () => {
    const rows = sortedChats((c) => !c.locked, search.value);
    const lockCount = [...S.chats.values()].filter((c) => c.locked).length;
    const showLock = Date.now() < Main.lockUntil && !S.me.lock_hidden;
    inner.replaceChildren(
      showLock && h('button', { class: 'lockrow', onclick: () => openLocked() }, ic('lock', 20), h('span', null, t('locked_chats')), lockCount ? h('span', { class: 'cnt' }, lockCount) : null),
      ...rows.map((c) => chatRow(c)),
      rows.length ? null : h('div', { class: 'empty' }, ic('chat', 44), h('p', null, S.chats.size ? t('no_results') : t('chats_empty')), S.chats.size ? null : h('p', { class: 'muted' }, t('chats_empty_hint'))));
    banner.replaceChildren(...[updateBanner()].filter(Boolean));
  };
  search.addEventListener('input', () => {
    clearTimeout(st); draw();
    const q = search.value;
    if (S.me.lock_hidden && S.me.lock_hash && q.length >= 4) {
      st = setTimeout(async () => { if (await lockVerify(q)) { search.value = ''; draw(); openLocked(true); } }, 350);
    }
  });
  attachPull(scroller, inner, () => {
    if (S.me.lock_hidden) return;
    Main.lockUntil = Date.now() + 9000; draw(); setTimeout(draw, 9100);
  });
  wrap.append(h('div', { class: 'searchw' }, ic('search', 18), search), banner, scroller,
    h('button', { class: 'fab', onclick: () => Nav.push(newChatScreen(), 'newchat') }, ic('pen', 24)));
  wrap._draw = draw; draw();
  return wrap;
}

function mainScreen() {
  const el = h('div', { class: 'main' });
  const content = h('div', { class: 'mcontent' });
  let view = null, tab = 'chats';
  const badge = h('span', { class: 'nbadge' });
  const title = h('div', { class: 'ttl big' }, t('chats'));
  const nav = h('div', { class: 'bnav' });
  const show = (tb) => {
    tab = tb; Main.tab = tb;
    content.replaceChildren();
    view = tb === 'chats' ? chatsView() : settingsView();
    content.append(view);
    title.textContent = tb === 'chats' ? t('chats') : t('settings');
    drawNav();
  };
  const drawNav = () => {
    const b = (id, icn, label, extra) => h('button', { class: 'nb' + (tab === id ? ' on' : ''), onclick: () => show(id) }, h('span', { class: 'nbi' }, ic(icn, 24), extra), h('span', null, label));
    nav.replaceChildren(b('chats', 'chat', t('chats'), badge), b('settings', 'sliders', t('settings')));
  };
  const menu = async () => {
    const v = await sheet([{ v: 'group', icon: 'users', label: t('new_group') }, S.me.role === 'owner' && { v: 'owner', icon: 'crown', label: t('owner_panel') },
      { v: 'settings', icon: 'sliders', label: t('settings') }, { v: 'hide', icon: 'calc', label: t('back_to_calc') }]);
    if (v === 'group') Nav.push(newGroupScreen(), 'newgroup');
    else if (v === 'owner') Nav.push(ownerPanel(), 'owner');
    else if (v === 'settings') show('settings');
    else if (v === 'hide') App.lockApp();
  };
  el.append(h('div', { class: 'hdr main-h' }, title, h('span', { class: 'sp' }), h('button', { class: 'ib', onclick: menu }, ic('more', 22))), content, nav);
  el._refresh = () => {
    if (view && view._draw) view._draw();
    const n = [...S.chats.values()].filter((c) => !c.locked && !c.muted).reduce((a, c) => a + (c.unread || 0), 0);
    badge.textContent = n > 99 ? '99+' : n; badge.style.display = n ? '' : 'none';
  };
  el._show = () => el._refresh();
  Main.show = show;
  show('chats');
  return el;
}

/* ---------- new chat / new group ---------- */
async function startDm(query, userId) {
  const r = await api('/api/chats/dm', { body: userId ? { user_id: userId } : { query } });
  if (!S.chats.has(r.chat_id)) await Sync.now();
  return r.chat_id;
}
function contactList() {
  const seen = new Map();
  for (const c of S.chats.values()) if (c.type === 'dm') { const p = peerOf(c); if (p) seen.set(p.id, p); }
  return [...seen.values()];
}
function newChatScreen() {
  const el = h('div', { class: 'main' });
  const q = h('input', { placeholder: t('nc_ph'), autocapitalize: 'off', autocomplete: 'off', spellcheck: false });
  const err = h('div', { class: 'err' });
  const btn = h('button', { class: 'btn primary wide' }, ic('chat', 18), t('start_chat'));
  const go = async (query, id) => {
    err.textContent = ''; if (!query && !id) return; btn.disabled = true;
    try { const cid = await startDm(query, id); Nav.pop(); Chat.open(cid); }
    catch (e) { err.textContent = errText(e); btn.disabled = false; }
  };
  btn.addEventListener('click', () => go(q.value.trim()));
  q.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(q.value.trim()); });
  const cs = contactList();
  el.append(header(t('new_chat')), h('div', { class: 'pad' }, field(t('nc_label'), q, t('nc_hint')), err, btn,
    h('button', { class: 'lrow', onclick: () => { Nav.pop(); Nav.push(newGroupScreen(), 'newgroup'); } }, h('span', { class: 'lic' }, ic('users', 22)), t('new_group')),
    cs.length ? h('div', { class: 'sect' }, t('contacts')) : null,
    cs.map((u) => h('button', { class: 'lrow', onclick: () => go(null, u.id) }, avatar(u.full_name, 44), h('span', null, h('b', null, u.full_name), h('small', null, '@' + u.username))))));
  setTimeout(() => q.focus(), 300);
  return el;
}
function newGroupScreen() {
  const el = h('div', { class: 'main' });
  const sel = new Map();
  const name = h('input', { placeholder: t('group_name'), maxLength: 60 });
  const err = h('div', { class: 'err' });
  const chips = h('div', { class: 'chips' });
  const list = h('div');
  const draw = () => {
    chips.replaceChildren(...[...sel.values()].map((u) => h('span', { class: 'chip', onclick: () => { sel.delete(u.id); draw(); } }, u.full_name.split(' ')[0], ' \u00d7')));
    const cs = contactList();
    sel.forEach((u) => { if (!cs.find((x) => x.id === u.id)) cs.push(u); });
    list.replaceChildren(...cs.map((u) => h('button', { class: 'lrow' + (sel.has(u.id) ? ' sel' : ''), onclick: () => { sel.has(u.id) ? sel.delete(u.id) : sel.set(u.id, u); draw(); } },
      avatar(u.full_name, 44), h('span', null, h('b', null, u.full_name), h('small', null, '@' + u.username)), h('span', { class: 'ck2' }, sel.has(u.id) ? ic('check', 18) : null))));
  };
  const addQ = h('input', { placeholder: t('nc_ph'), autocapitalize: 'off', spellcheck: false });
  const addBtn = h('button', { class: 'btn ghost', onclick: async () => {
    const v = addQ.value.trim(); if (!v) return;
    try { const r = await api('/api/lookup?q=' + encodeURIComponent(v), { quiet: true }); sel.set(r.user.id, r.user); addQ.value = ''; err.textContent = ''; draw(); }
    catch (e) { err.textContent = errText(e); }
  } }, ic('plus', 18));
  const create = h('button', { class: 'btn primary wide' }, t('create_group'));
  create.addEventListener('click', async () => {
    err.textContent = '';
    if (!name.value.trim()) return (err.textContent = t('e_bad_name_group'));
    create.disabled = true;
    try { const r = await api('/api/chats/group', { body: { name: name.value.trim(), members: [...sel.keys()] } }); await Sync.now(); Nav.pop(); Chat.open(r.chat_id); }
    catch (e) { err.textContent = errText(e); create.disabled = false; }
  });
  el.append(header(t('new_group')), h('div', { class: 'pad' }, field(t('group_name'), name), chips, h('div', { class: 'addrow' }, addQ, addBtn),
    h('div', { class: 'sect' }, t('add_members')), list, err, create));
  draw();
  return el;
}
