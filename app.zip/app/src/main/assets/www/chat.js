'use strict';
/* ---------- media transfer (chunked through the server) ---------- */
const CHUNK = 240 * 1024;
const Media = {
  urls: new Map(), loading: new Map(),
  async upload(blob, name, extra, onProgress) {
    const n = Math.max(1, Math.ceil(blob.size / CHUNK));
    const init = await api('/api/media', { body: { mime: blob.type || 'application/octet-stream', size: blob.size, name, chunks: n } });
    let done = 0;
    const up = async (i) => {
      const part = blob.slice(i * CHUNK, (i + 1) * CHUNK);
      const b64 = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1] || ''); fr.onerror = rej; fr.readAsDataURL(part); });
      for (let a = 0; ; a++) {
        try { await api('/api/media/' + init.id + '/' + i, { method: 'PUT', raw: b64, timeout: 60000 }); break; }
        catch (e) { if (a >= 2) throw e; await new Promise((r) => setTimeout(r, 800)); }
      }
      done++; if (onProgress) onProgress(done / n);
    };
    const idx = [...Array(n).keys()];
    const workers = [0, 1, 2].map(async () => { while (idx.length) await up(idx.shift()); });
    await Promise.all(workers);
    this.urls.set(init.id, URL.createObjectURL(blob));
    return Object.assign({ id: init.id, mime: blob.type || 'application/octet-stream', size: blob.size, name, chunks: n }, extra || {});
  },
  get(media, onProgress) {
    if (this.urls.has(media.id)) return Promise.resolve(this.urls.get(media.id));
    if (this.loading.has(media.id)) return this.loading.get(media.id);
    const p = (async () => {
      const parts = new Array(media.chunks); let done = 0;
      const idx = [...Array(media.chunks).keys()];
      const worker = async () => {
        while (idx.length) {
          const i = idx.shift();
          for (let a = 0; ; a++) {
            try {
              const b64 = await api('/api/media/' + media.id + '/' + i, { text: true, timeout: 60000 });
              const bin = atob(b64); const u8 = new Uint8Array(bin.length);
              for (let k = 0; k < bin.length; k++) u8[k] = bin.charCodeAt(k);
              parts[i] = u8; break;
            } catch (e) { if (a >= 2) throw e; await new Promise((r) => setTimeout(r, 800)); }
          }
          done++; if (onProgress) onProgress(done / media.chunks);
        }
      };
      await Promise.all([worker(), worker(), worker(), worker()]);
      const url = URL.createObjectURL(new Blob(parts, { type: media.mime }));
      this.urls.set(media.id, url);
      return url;
    })();
    this.loading.set(media.id, p);
    p.then(() => this.loading.delete(media.id), () => this.loading.delete(media.id));
    return p;
  }
};
async function shrinkImage(file) {
  if (!/^image\/(jpeg|png|webp|heic|heif)$/i.test(file.type)) return { blob: file, w: 0, h: 0 };
  try {
    const bmp = await createImageBitmap(file);
    const max = 1600, sc = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * sc), hh = Math.round(bmp.height * sc);
    const cv = h('canvas', { width: w, height: hh }); cv.getContext('2d').drawImage(bmp, 0, 0, w, hh);
    const blob = await new Promise((r) => cv.toBlob(r, 'image/jpeg', 0.82));
    return { blob: blob || file, w, h: hh };
  } catch (e) { return { blob: file, w: 0, h: 0 }; }
}
function saveBlobUrl(url, name, mime) {
  fetch(url).then((r) => r.blob()).then((b) => {
    if (nat && nat.save) {
      const fr = new FileReader();
      fr.onload = () => { const ok = nat.save(name, mime || b.type, String(fr.result).split(',')[1]); toast(ok ? t('saved_downloads') : t('e_generic')); };
      fr.readAsDataURL(b);
    } else { const a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove(); }
  });
}
function viewer(m) {
  let o;
  const bar = h('div', { class: 'vbar' }, h('button', { class: 'ib', onclick: () => o.close() }, ic('close', 24)), h('span', { class: 'sp' }),
    h('button', { class: 'ib', onclick: () => Media.get(m.media).then((u) => saveBlobUrl(u, m.media.name || 'file', m.media.mime)) }, ic('download', 22)));
  const body = h('div', { class: 'vbody' }, h('div', { class: 'spin' }));
  o = overlay(h('div', { class: 'viewer' }, bar, body), { sticky: true });
  Media.get(m.media).then((u) => {
    body.replaceChildren(m.type === 'video' ? h('video', { src: u, controls: true, autoplay: true, playsInline: true }) : h('img', { src: u }));
  }).catch(() => body.replaceChildren(h('p', { class: 'muted' }, t('e_generic'))));
}

/* ---------- emoji picker ---------- */
function emojiPicker(onPick) {
  const grid = h('div', { class: 'egrid' });
  const tabs = h('div', { class: 'etabs' });
  let cur = 0;
  const draw = () => {
    tabs.replaceChildren(...EMOJI.map((c, i) => h('button', { class: i === cur ? 'on' : '', onclick: () => { cur = i; draw(); } }, c[0])));
    grid.replaceChildren(...EMOJI[cur][1].map((e) => h('button', { class: 'eb', onclick: () => onPick(e) }, e)));
    grid.scrollTop = 0;
  };
  draw();
  return h('div', { class: 'epick' }, tabs, grid);
}

/* ---------- voice recorder ---------- */
const Rec = {
  mr: null, chunks: [], t0: 0, timer: null, stream: null,
  async start(onTick) {
    this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
    const mt = types.find((x) => window.MediaRecorder && MediaRecorder.isTypeSupported(x)) || '';
    this.mr = new MediaRecorder(this.stream, mt ? { mimeType: mt } : undefined);
    this.chunks = []; this.mr.ondataavailable = (e) => { if (e.data.size) this.chunks.push(e.data); };
    this.mr.start(250); this.t0 = Date.now();
    this.timer = setInterval(() => onTick(Math.floor((Date.now() - this.t0) / 1000)), 250);
  },
  stop() {
    return new Promise((res) => {
      clearInterval(this.timer);
      const dur = (Date.now() - this.t0) / 1000;
      this.mr.onstop = () => { this.stream.getTracks().forEach((x) => x.stop()); res({ blob: new Blob(this.chunks, { type: this.mr.mimeType || 'audio/webm' }), dur }); };
      try { this.mr.stop(); } catch (e) { res(null); }
    });
  },
  cancel() { clearInterval(this.timer); try { this.mr.onstop = () => {}; this.mr.stop(); } catch (e) { /* ignore */ } if (this.stream) this.stream.getTracks().forEach((x) => x.stop()); }
};

/* ---------- chat screen ---------- */
const Chat = {
  cur: null,
  async open(id) {
    const c = S.chats.get(id);
    if (!c) { await Sync.now(); if (!S.chats.has(id)) return toast(t('e_generic')); }
    Nav.push(chatScreen(id), 'chat');
  },
  async action(c, v) {
    try {
      if (v === 'mute') await api('/api/chats/' + c.id + '/me', { method: 'PATCH', body: { muted: !c.muted } });
      else if (v === 'lock') {
        if (!c.locked && !S.me.lock_hash && !(await createLockPassword())) return;
        await api('/api/chats/' + c.id + '/me', { method: 'PATCH', body: { locked: !c.locked } });
        if (!c.locked) toast(S.me.lock_hidden ? t('chat_locked_hidden') : t('chat_locked'));
      } else if (v === 'clear') {
        if (!(await dialog({ title: t('clear_chat'), text: t('clear_confirm'), ok: t('clear_chat'), danger: true }))) return;
        await api('/api/chats/' + c.id + '/clear', { body: {} }); S.msgs.set(c.id, []);
      } else if (v === 'leave') {
        if (!(await dialog({ title: t('leave_group'), text: t('leave_confirm'), ok: t('leave_group'), danger: true }))) return;
        await api('/api/chats/' + c.id + '/members/' + S.me.id, { method: 'DELETE' });
        if (S.openChat === c.id) Nav.pop();
      }
      Sync.now();
    } catch (e) { toast(errText(e)); }
  }
};

function chatScreen(chatId) {
  const el = h('div', { class: 'chat' });
  const list = h('div', { class: 'msgs' });
  const cache = new Map();
  let pend = [];            // optimistic local messages
  let replyTo = null, editing = null, more = true, loadingOld = false, emojiOpen = false, recording = false;
  const c0 = () => S.chats.get(chatId);
  S.openChat = chatId; S.typing = []; S.seen = [];
  el._leave = () => { if (S.openChat === chatId) S.openChat = null; stopAudio(); };
  el._show = () => { S.openChat = chatId; Sync.kick(); markRead(); };

  const nameEl = h('div', { class: 'ttl' }), subEl = h('div', { class: 'sub' });
  const avBox = h('div', { class: 'avb' });
  const head = h('div', { class: 'hdr chat-h' },
    h('button', { class: 'ib', onclick: () => Nav.pop() }, ic('back', 24, 'flip')),
    h('div', { class: 'hmain', onclick: () => infoScreen(chatId) }, avBox, h('div', { class: 'hdr-t' }, nameEl, subEl)),
    h('button', { class: 'ib', onclick: menu }, ic('more', 22)));
  const replyBar = h('div', { class: 'rbar' });
  const input = h('textarea', { rows: 1, placeholder: t('type_msg'), maxLength: 4000 });
  const emojiBtn = h('button', { class: 'ib', onclick: () => toggleEmoji() }, ic('smile', 24));
  const attachBtn = h('button', { class: 'ib', onclick: attach }, ic('clip', 22));
  const sendBtn = h('button', { class: 'sendb', onclick: () => (input.value.trim() ? send() : startRec()) }, ic('mic', 22));
  const cbox = h('div', { class: 'cbox' }, emojiBtn, input, attachBtn);
  const comp = h('div', { class: 'composer' }, cbox, sendBtn);
  const epWrap = h('div', { class: 'epw' });
  const blockedBar = h('div', { class: 'blkbar' });
  const fileIn = h('input', { type: 'file', multiple: true, class: 'hidden' });
  fileIn.addEventListener('change', async () => { const fs = [...fileIn.files]; fileIn.value = ''; for (const f of fs) await sendFile(f); });
  el.append(head, list, replyBar, blockedBar, comp, epWrap, fileIn);

  function updSend() {
    const has = !!input.value.trim();
    sendBtn.replaceChildren(ic(has ? 'send' : 'mic', 22, has ? 'flip' : ''));
    input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px';
  }
  let typingAt = 0;
  input.addEventListener('input', () => {
    updSend();
    if (input.value && Date.now() - typingAt > 3000) { typingAt = Date.now(); api('/api/chats/' + chatId + '/typing', { body: {}, quiet: true }).catch(() => {}); }
  });
  input.addEventListener('focus', () => { if (emojiOpen) toggleEmoji(false); setTimeout(() => { list.scrollTop = list.scrollHeight; }, 250); });
  function toggleEmoji(on) {
    emojiOpen = on === undefined ? !emojiOpen : on;
    epWrap.replaceChildren(emojiOpen ? emojiPicker((e) => { const s = input.selectionStart || input.value.length; input.value = input.value.slice(0, s) + e + input.value.slice(s); input.focus(); updSend(); }) : '');
    epWrap.classList.toggle('open', emojiOpen);
    emojiBtn.replaceChildren(ic(emojiOpen ? 'chat' : 'smile', 24));
    if (emojiOpen) input.blur();
  }

  /* ----- header / status ----- */
  function drawHead() {
    const c = c0(); if (!c) return;
    nameEl.textContent = chatTitle(c);
    avBox.replaceChildren(avatar(chatTitle(c), 40, c.type === 'group'));
    let sub = '';
    if (S.typing.length) sub = c.type === 'group' ? S.typing.map((n) => n.split(' ')[0]).join(', ') + ' ' + t('typing') : t('typing');
    else if (c.type === 'dm') {
      const p = peerOf(c), sn = p && S.seen.find((x) => x.id === p.id);
      if (sn && sn.last_seen) sub = Date.now() - sn.last_seen < 75000 ? t('online') : t('last_seen', { d: fmtDay(sn.last_seen), t: fmtTime(sn.last_seen) });
    } else sub = c.members.map((m) => (m.id === S.me.id ? t('you') : m.full_name.split(' ')[0])).join(', ');
    subEl.textContent = sub; subEl.classList.toggle('typ', !!S.typing.length);
    const peer = c.type === 'dm' ? peerOf(c) : null;
    const iBlocked = peer && S.blocked.has(peer.id);
    blockedBar.replaceChildren(iBlocked ? h('span', null, t('you_blocked'), ' ', h('button', { class: 'lnk', onclick: () => blockUser(peer.id, false) }, t('unblock'))) : '');
    blockedBar.style.display = iBlocked ? '' : 'none'; comp.style.display = iBlocked ? 'none' : '';
  }
  async function blockUser(uid2, block) {
    try { await api('/api/blocks', { body: { user_id: uid2, block } }); if (block) S.blocked.add(uid2); else S.blocked.delete(uid2); toast(block ? t('blocked_done') : t('unblocked_done')); Sync.now(); drawHead(); } catch (e) { toast(errText(e)); }
  }
  async function menu() {
    const c = c0(); if (!c) return;
    const peer = c.type === 'dm' ? peerOf(c) : null;
    const v = await sheet([{ v: 'info', icon: c.type === 'group' ? 'users' : 'user', label: c.type === 'group' ? t('group_info') : t('contact_info') },
      { v: 'mute', icon: 'mute', label: c.muted ? t('unmute') : t('mute') }, { v: 'lock', icon: 'lock', label: c.locked ? t('unlock_chat') : t('lock_chat') },
      { v: 'clear', icon: 'trash', label: t('clear_chat') },
      peer && { v: 'block', icon: 'ban', label: S.blocked.has(peer.id) ? t('unblock') : t('block'), danger: true },
      c.type === 'group' && { v: 'leave', icon: 'back', label: t('leave_group'), danger: true }]);
    if (v === 'info') infoScreen(chatId);
    else if (v === 'block') blockUser(peer.id, !S.blocked.has(peer.id));
    else if (v) Chat.action(c, v);
  }

  /* ----- messages ----- */
  function allMsgs() {
    const arr = (S.msgs.get(chatId) || []).slice();
    for (const p of pend) if (!arr.find((x) => x.id === p.id)) arr.push(p);
    return arr;
  }
  const isMine = (m) => m.sid === S.me.id;
  function replyBlock(m) {
    const r = m.reply; if (!r) return null;
    const txt = r.type === 'text' ? r.body : r.type === 'image' ? '\ud83d\udcf7 ' + t('photo') : r.type === 'video' ? '\ud83c\udfa5 ' + t('video') : r.type === 'audio' ? '\ud83c\udfa4 ' + t('voice') : '\ud83d\udcc4 ' + t('file');
    return h('div', { class: 'quote', onclick: () => jump(r.id) }, h('b', null, userName(r.sid)), h('span', null, txt));
  }
  function mediaBlock(m) {
    const md = m.media; if (!md) return null;
    if (m.type === 'image') {
      const ar = md.w && md.h ? md.w + '/' + md.h : '4/3';
      const box = h('div', { class: 'imgbox', style: { aspectRatio: ar } }, h('div', { class: 'spin' }));
      const load = () => Media.get(md).then((u) => { box.replaceChildren(h('img', { src: u, onclick: () => viewer(m) })); }).catch(() => box.replaceChildren(h('button', { class: 'btn ghost', onclick: () => { box.replaceChildren(h('div', { class: 'spin' })); load(); } }, ic('download', 18), fmtSize(md.size))));
      if (md.size <= 4 * 1048576 || Media.urls.has(md.id)) load();
      else box.replaceChildren(h('button', { class: 'btn ghost', onclick: () => { box.replaceChildren(h('div', { class: 'spin' })); load(); } }, ic('download', 18), fmtSize(md.size)));
      if (m.pending) box.append(h('div', { class: 'prog' }, h('i', { style: { width: Math.round((m.progress || 0) * 100) + '%' } })));
      return box;
    }
    if (m.type === 'video') {
      const box = h('div', { class: 'imgbox vid', style: { aspectRatio: md.w && md.h ? md.w + '/' + md.h : '16/9' } });
      const play = () => { box.replaceChildren(h('div', { class: 'spin' })); Media.get(md, (p) => { box.firstChild && (box.firstChild.dataset.p = Math.round(p * 100) + '%'); }).then((u) => box.replaceChildren(h('video', { src: u, controls: true, playsInline: true, preload: 'metadata' }))).catch(() => box.replaceChildren(h('button', { class: 'btn ghost', onclick: play }, ic('download', 18), t('retry')))); };
      box.append(h('button', { class: 'playbig', onclick: play }, ic('play', 30)), h('span', { class: 'vsz' }, fmtSize(md.size)));
      if (Media.urls.has(md.id)) play();
      if (m.pending) box.append(h('div', { class: 'prog' }, h('i', { style: { width: Math.round((m.progress || 0) * 100) + '%' } })));
      return box;
    }
    if (m.type === 'audio') return audioPlayer(m);
    return h('div', { class: 'filec', onclick: () => Media.get(md).then((u) => saveBlobUrl(u, md.name || 'file', md.mime)).catch(() => toast(t('e_generic'))) },
      h('span', { class: 'fic' }, ic('file', 24)), h('span', { class: 'fnm' }, h('b', null, md.name || t('file')), h('small', null, fmtSize(md.size))), ic('download', 20));
  }
  function bubble(m) {
    const mine = isMine(m);
    const showName = !mine && c0() && c0().type === 'group';
    const rx = Object.values(m.rx || {});
    const rxCount = {}; rx.forEach((e) => { rxCount[e] = (rxCount[e] || 0) + 1; });
    const content = m.del ? h('div', { class: 'txt del' }, '\u2298 ', mine ? t('you_deleted') : t('msg_deleted'))
      : [showName && h('div', { class: 'sname', style: { color: PAL[[...userName(m.sid)].reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) >>> 0, 0) % PAL.length] } }, userName(m.sid)),
        replyBlock(m), mediaBlock(m), m.body && m.type !== 'sys' ? h('div', { class: 'txt' }, m.body) : null];
    return h('div', { class: 'bub ' + (mine ? 'out' : 'in') + (m.type === 'image' && !m.body && !m.del ? ' mono' : '') + (m.failed ? ' failed' : '') },
      content,
      h('div', { class: 'meta' }, m.ed && !m.del ? h('span', null, t('edited')) : null, h('span', null, fmtTime(m.at)), mine && !m.del && tickEl(m.pending ? [] : rcOf(m.id), m.pending && !m.failed),
        m.failed ? h('button', { class: 'lnk sm', onclick: () => retry(m) }, t('retry')) : null),
      rx.length ? h('div', { class: 'rx' }, Object.entries(rxCount).map(([e, n]) => h('span', null, e, n > 1 ? n : ''))) : null);
  }
  function draw() {
    const msgs = allMsgs();
    const near = list.scrollHeight - list.scrollTop - list.clientHeight < 120;
    const prevH = list.scrollHeight;
    const out = []; let lastDay = '';
    if (more && msgs.length) out.push(h('div', { class: 'older' }, h('button', { class: 'lnk', onclick: loadOlder }, loadingOld ? '\u2026' : t('load_older'))));
    for (const m of msgs) {
      const day = new Date(m.at).toDateString();
      if (day !== lastDay) { lastDay = day; out.push(h('div', { class: 'day' }, h('span', null, fmtDay(m.at)))); }
      if (m.type === 'sys') { out.push(h('div', { class: 'sysm' }, h('span', null, sysText(m)))); continue; }
      const sig = [m.up, m.del, m.pending, m.failed, m.progress && Math.round(m.progress * 20), JSON.stringify(rcOf(m.id)), S.lang, Object.keys(m.rx || {}).length].join('|');
      let ent = cache.get(m.id);
      if (!ent || ent.sig !== sig) {
        const row = h('div', { class: 'row ' + (isMine(m) ? 'out' : 'in'), 'data-id': m.id }, bubble(m));
        if (!m.pending) onLong(row, () => msgMenu(m));
        else row.addEventListener('click', () => { if (m.failed) retry(m); });
        let sx = 0;
        row.addEventListener('touchstart', (e) => { sx = e.touches[0].clientX; }, { passive: true });
        row.addEventListener('touchend', (e) => { const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 70 && !m.pending && !m.del) { setReply(m); } });
        ent = { sig, el: row }; cache.set(m.id, ent);
      }
      out.push(ent.el);
    }
    if (!msgs.length) out.push(h('div', { class: 'empty' }, h('p', { class: 'muted' }, t('say_hi'))));
    list.replaceChildren(...out);
    if (near || list._first) { list.scrollTop = list.scrollHeight; list._first = false; }
    else if (loadingOld === 'done') list.scrollTop = list.scrollHeight - prevH;
  }
  function jump(id) { const e = cache.get(id); if (e) { e.el.scrollIntoView({ block: 'center' }); e.el.classList.add('flash'); setTimeout(() => e.el.classList.remove('flash'), 1000); } }
  function setReply(m) {
    replyTo = m; editing = null;
    const txt = m.type === 'text' ? m.body : previewText(m);
    replyBar.replaceChildren(h('div', { class: 'rb' }, h('b', null, userName(m.sid)), h('span', null, txt.slice(0, 80))), h('button', { class: 'ib', onclick: clearReply }, ic('close', 20)));
    replyBar.style.display = ''; input.focus();
  }
  function clearReply() { replyTo = null; editing = null; replyBar.style.display = 'none'; replyBar.replaceChildren(); }
  clearReply();

  async function loadHistory() {
    try {
      const r = await api('/api/chats/' + chatId + '/messages?limit=40');
      S.hist.set(chatId, true); S.msgs.set(chatId, r.msgs); more = r.more; r.rcs.forEach(setRc);
      list._first = true; draw(); drawHead(); markRead();
    } catch (e) { toast(errText(e)); }
  }
  async function loadOlder() {
    if (loadingOld) return; loadingOld = true; draw();
    const arr = S.msgs.get(chatId) || [];
    try {
      const r = await api('/api/chats/' + chatId + '/messages?limit=40&before=' + (arr[0] ? arr[0].at : 0));
      S.msgs.set(chatId, [...r.msgs, ...arr]); more = r.more; r.rcs.forEach(setRc);
    } catch (e) { toast(errText(e)); }
    loadingOld = 'done'; draw(); loadingOld = false;
  }
  let readT = null;
  function markRead() {
    clearTimeout(readT);
    readT = setTimeout(async () => {
      const c = c0(); if (!c || document.hidden || S.openChat !== chatId) return;
      const hasUnread = c.unread > 0 || (S.msgs.get(chatId) || []).some((m) => !isMine(m) && m.type !== 'sys' && !(S.rc.get(m.id) || new Map()).get(S.me.id));
      const arr = S.msgs.get(chatId) || [];
      const need = c.unread > 0 || arr.some((m) => !isMine(m) && m.type !== 'sys' && m.at > (c.read_upto || 0));
      if (!need && !hasUnread) return;
      c.unread = 0; c.read_upto = Date.now(); App.refresh();
      try { await api('/api/chats/' + chatId + '/read', { body: {}, quiet: true }); } catch (e) { /* ignore */ }
    }, 400);
  }
  el._draw = () => { if (!c0()) return; drawHead(); if (S.hist.has(chatId)) { draw(); markRead(); } };

  /* ----- sending ----- */
  async function send() {
    const text = input.value.trim(); if (!text) return;
    if (editing) {
      const m = editing; clearReply(); input.value = ''; updSend();
      try { await api('/api/messages/' + m.id, { method: 'PATCH', body: { body: text } }); Sync.now(); } catch (e) { toast(e.code === 'too_late' ? t('e_too_late') : errText(e)); }
      return;
    }
    const id = uid();
    const m = { id, chat_id: chatId, sid: S.me.id, type: 'text', body: text, media: null, reply: replyTo ? { id: replyTo.id, sid: replyTo.sid, type: replyTo.type, body: replyTo.body } : null, rx: {}, del: 0, at: Date.now(), up: Date.now(), ed: 0, pending: true };
    const rt = replyTo; clearReply(); input.value = ''; updSend();
    pend.push(m); draw(); list.scrollTop = list.scrollHeight;
    await post(m, { id, type: 'text', body: text, reply_to: rt ? rt.id : undefined });
  }
  async function post(m, payload) {
    try {
      const r = await api('/api/chats/' + chatId + '/messages', { body: payload, quiet: false });
      pend = pend.filter((x) => x.id !== m.id);
      upsertMsg(r.msg); S.hist.set(chatId, true);
      const c = c0(); if (c) { c.last = r.msg; c.up = r.msg.up; }
      draw(); list.scrollTop = list.scrollHeight; Sync.kick(); App.refresh();
    } catch (e) { m.failed = true; draw(); if (e.code === 'you_blocked') toast(t('you_blocked')); }
  }
  function retry(m) { m.failed = false; draw(); post(m, { id: m.id, type: m.type, body: m.body, media: m.media, reply_to: m.reply ? m.reply.id : undefined }); }
  function attach() {
    sheet([{ v: 'media', icon: 'image', label: t('att_media') }, { v: 'file', icon: 'file', label: t('att_file') }]).then((v) => {
      if (!v) return; fileIn.accept = v === 'media' ? 'image/*,video/*' : '*/*'; fileIn.click();
    });
  }
  async function sendFile(file) {
    if (file.size > 16.5 * 1048576) return toast(t('e_too_big'));
    const id = uid();
    const isImg = file.type.startsWith('image/'), isVid = file.type.startsWith('video/');
    const type = isImg ? 'image' : isVid ? 'video' : 'file';
    const m = { id, chat_id: chatId, sid: S.me.id, type, body: '', media: { id: 'tmp' + id, mime: file.type, size: file.size, name: file.name, chunks: 1, w: 0, h: 0 }, rx: {}, del: 0, at: Date.now(), up: Date.now(), ed: 0, pending: true, progress: 0 };
    let blob = file, extra = {};
    if (isImg) { const s = await shrinkImage(file); blob = s.blob; extra = { w: s.w, h: s.h }; m.media.w = s.w; m.media.h = s.h; m.media.size = blob.size; }
    Media.urls.set(m.media.id, URL.createObjectURL(blob));
    pend.push(m); draw(); list.scrollTop = list.scrollHeight;
    await uploadAndPost(m, blob, file.name, extra);
  }
  async function uploadAndPost(m, blob, name, extra) {
    try {
      const real = await Media.upload(blob, name, extra, (p) => { m.progress = p; draw(); });
      Media.urls.set(real.id, Media.urls.get(m.media.id));
      m.media = real;
      await post(m, { id: m.id, type: m.type, body: m.body, media: real });
    } catch (e) { m.failed = true; m._blob = blob; m._name = name; m._extra = extra; draw(); toast(errText(e)); }
  }
  const oldRetry = retry;
  retry = function (m) { if (m._blob) { m.failed = false; draw(); uploadAndPost(m, m._blob, m._name, m._extra); } else oldRetry(m); }; // eslint-disable-line no-func-assign

  /* ----- voice notes ----- */
  async function startRec() {
    if (recording) return;
    try {
      const bar = h('div', { class: 'recbar' });
      const timer = h('span', { class: 'rect' }, '0:00');
      await Rec.start((s) => { timer.textContent = fmtDur(s); });
      recording = true;
      const stop = async (sendIt) => {
        recording = false; bar.remove(); cbox.style.display = ''; sendBtn.style.display = '';
        if (!sendIt) { Rec.cancel(); return; }
        const r = await Rec.stop(); if (!r || r.dur < 0.6) return toast(t('too_short'));
        const id = uid();
        const m = { id, chat_id: chatId, sid: S.me.id, type: 'audio', body: '', media: { id: 'tmp' + id, mime: r.blob.type, size: r.blob.size, name: 'voice', chunks: 1, dur: r.dur }, rx: {}, del: 0, at: Date.now(), up: Date.now(), ed: 0, pending: true, progress: 0 };
        Media.urls.set(m.media.id, URL.createObjectURL(r.blob));
        pend.push(m); draw(); list.scrollTop = list.scrollHeight;
        await uploadAndPost(m, r.blob, 'voice.' + (r.blob.type.includes('mp4') ? 'm4a' : 'webm'), { dur: Math.round(r.dur) });
      };
      bar.append(h('button', { class: 'ib danger', onclick: () => stop(false) }, ic('trash', 22)), h('span', { class: 'recdot' }), timer, h('span', { class: 'sp' }),
        h('button', { class: 'sendb', onclick: () => stop(true) }, ic('send', 20, 'flip')));
      cbox.style.display = 'none'; sendBtn.style.display = 'none'; comp.append(bar);
    } catch (e) { recording = false; toast(t('e_mic')); }
  }

  /* ----- message actions ----- */
  async function msgMenu(m) {
    const mine = isMine(m);
    const quick = ['\ud83d\udc4d', '\u2764\ufe0f', '\ud83d\ude02', '\ud83d\ude2e', '\ud83d\ude22', '\ud83d\ude4f'];
    let o;
    const react = async (e) => { o.close(); try { await api('/api/messages/' + m.id + '/react', { body: { emoji: e } }); Sync.now(); } catch (x) { toast(errText(x)); } };
    const act = (fn) => () => { o.close(); fn(); };
    const items = m.del ? [h('button', { class: 'sheet-i', onclick: act(() => delMe(m)) }, ic('trash', 20), h('span', null, t('delete_me')))] : [
      h('button', { class: 'sheet-i', onclick: act(() => setReply(m)) }, ic('reply', 20), h('span', null, t('reply'))),
      m.type === 'text' && h('button', { class: 'sheet-i', onclick: act(() => copyText(m.body)) }, ic('copy', 20), h('span', null, t('copy'))),
      mine && m.type === 'text' && Date.now() - m.at < 15 * 60 * 1000 && h('button', { class: 'sheet-i', onclick: act(() => { editing = m; replyTo = null; input.value = m.body; updSend(); replyBar.replaceChildren(h('div', { class: 'rb' }, h('b', null, t('edit')), h('span', null, m.body.slice(0, 80))), h('button', { class: 'ib', onclick: () => { clearReply(); input.value = ''; updSend(); } }, ic('close', 20))); replyBar.style.display = ''; input.focus(); }) }, ic('pen', 20), h('span', null, t('edit'))),
      h('button', { class: 'sheet-i', onclick: act(() => forward(m)) }, ic('share', 20), h('span', null, t('forward'))),
      mine && h('button', { class: 'sheet-i', onclick: act(() => msgInfo(m)) }, ic('info', 20), h('span', null, t('msg_info'))),
      h('button', { class: 'sheet-i danger', onclick: act(() => delMe(m)) }, ic('trash', 20), h('span', null, t('delete_me'))),
      mine && h('button', { class: 'sheet-i danger', onclick: act(() => delAll(m)) }, ic('trash', 20), h('span', null, t('delete_all')))];
    const card = h('div', { class: 'sheet' }, !m.del && h('div', { class: 'qrx' }, quick.map((e) => h('button', { onclick: () => react(e) }, e)),
      h('button', { class: 'more', onclick: () => { o.close(); moreReact(m); } }, ic('plus', 20))), items);
    o = overlay(card);
  }
  function moreReact(m) {
    let o;
    o = overlay(h('div', { class: 'sheet tall' }, emojiPicker(async (e) => { o.close(); try { await api('/api/messages/' + m.id + '/react', { body: { emoji: e } }); Sync.now(); } catch (x) { toast(errText(x)); } })));
  }
  async function delMe(m) {
    if (!(await dialog({ title: t('delete_me'), text: t('delete_me_text'), ok: t('delete'), danger: true }))) return;
    try { await api('/api/messages/' + m.id + '/delete', { body: { scope: 'me' } }); const a = S.msgs.get(chatId) || []; S.msgs.set(chatId, a.filter((x) => x.id !== m.id)); draw(); Sync.now(); } catch (e) { toast(errText(e)); }
  }
  async function delAll(m) {
    if (!(await dialog({ title: t('delete_all'), text: t('delete_all_text'), ok: t('delete'), danger: true }))) return;
    try { await api('/api/messages/' + m.id + '/delete', { body: { scope: 'all' } }); Sync.now(); } catch (e) { toast(errText(e)); }
  }
  async function forward(m) {
    const chats = sortedChats((c) => c.id !== chatId || true, '');
    let o;
    const pick = async (c) => {
      o.close();
      try {
        const p = { id: uid(), type: m.type, body: m.body, media: m.media || undefined };
        await api('/api/chats/' + c.id + '/messages', { body: p }); toast(t('forwarded')); Sync.now();
      } catch (e) { toast(errText(e)); }
    };
    o = overlay(h('div', { class: 'sheet tall' }, h('h3', { class: 'sh' }, t('forward_to')), chats.map((c) => h('button', { class: 'sheet-i', onclick: () => pick(c) }, avatar(chatTitle(c), 36, c.type === 'group'), h('span', null, chatTitle(c))))));
  }
  function msgInfo(m) {
    const c = c0(); const rows = [];
    const rc = rcOf(m.id);
    const el2 = h('div', { class: 'main' });
    const who = (u) => userName(u);
    const sect = (title, key) => {
      const l = rc.filter((x) => x[key]).sort((a, b) => a[key] - b[key]);
      return [h('div', { class: 'sect' }, title), l.length ? l.map((x) => h('div', { class: 'irow' }, avatar(who(x[0]), 36), h('span', null, who(x[0])), h('small', null, fmtDay(x[key]) + ' ' + fmtTime(x[key])))) : h('div', { class: 'muted pad2' }, '\u2014')];
    };
    el2.append(header(t('msg_info')), h('div', { class: 'pad' }, h('div', { class: 'row out info-b' }, bubble(Object.assign({}, m))), h('p', { class: 'muted' }, t('sent_at') + ': ' + fmtDay(m.at) + ' ' + fmtTime(m.at)),
      sect(t('read_by'), 2), sect(t('delivered_to'), 1), rows));
    Nav.push(el2, 'msginfo');
  }

  /* ----- boot ----- */
  const apply = () => { drawHead(); };
  drawHead(); updSend(); loadHistory();
  return el;
}

/* ---------- audio ---------- */
let curAudio = null;
function stopAudio() { if (curAudio) { try { curAudio.pause(); } catch (e) { /* ignore */ } curAudio = null; } }
function audioPlayer(m) {
  const md = m.media;
  const au = new Audio(); au.preload = 'none';
  const playBtn = h('button', { class: 'pl' }, ic('play', 20));
  const bar = h('div', { class: 'wave' }, h('i'));
  const tm = h('span', { class: 'dur' }, fmtDur(md.dur));
  let ready = false;
  const setIc = (p) => playBtn.replaceChildren(ic(p ? 'pause' : 'play', 20));
  au.addEventListener('timeupdate', () => { const d = au.duration && isFinite(au.duration) ? au.duration : md.dur || 1; bar.firstChild.style.width = Math.min(100, au.currentTime / d * 100) + '%'; tm.textContent = fmtDur(au.paused && au.currentTime === 0 ? md.dur : au.currentTime); });
  au.addEventListener('ended', () => { setIc(false); bar.firstChild.style.width = '0'; tm.textContent = fmtDur(md.dur); });
  au.addEventListener('pause', () => setIc(false)); au.addEventListener('play', () => setIc(true));
  playBtn.addEventListener('click', async () => {
    if (!au.paused) return au.pause();
    if (curAudio && curAudio !== au) curAudio.pause();
    if (!ready) { try { playBtn.classList.add('busy'); au.src = await Media.get(md); ready = true; } catch (e) { toast(t('e_generic')); return; } finally { playBtn.classList.remove('busy'); } }
    curAudio = au; au.play().catch(() => toast(t('e_generic')));
  });
  bar.addEventListener('click', (e) => { if (!ready) return; const r = bar.getBoundingClientRect(); const f = (S.lang === 'ar' ? r.right - e.clientX : e.clientX - r.left) / r.width; if (au.duration) au.currentTime = Math.max(0, Math.min(1, f)) * au.duration; });
  return h('div', { class: 'aud' }, playBtn, bar, tm);
}

/* ---------- contact / group info ---------- */
function infoScreen(chatId) {
  const c = S.chats.get(chatId); if (!c) return;
  const el = h('div', { class: 'main' });
  const body = h('div', { class: 'pad info' });
  const draw = async () => {
    const c2 = S.chats.get(chatId); if (!c2) return;
    body.replaceChildren();
    const amAdmin = c2.role === 'admin';
    if (c2.type === 'dm') {
      const p = peerOf(c2); if (!p) return;
      let info = {}; try { info = await api('/api/users/' + p.id); } catch (e) { /* ignore */ }
      body.append(h('div', { class: 'ibig' }, avatar(p.full_name, 96), h('h2', null, p.full_name), h('p', { class: 'muted' }, '@' + p.username + (info.phone ? ' \u00b7 ' + info.phone : ''))),
        h('button', { class: 'lrow', onclick: () => Chat.action(c2, 'mute').then(draw) }, h('span', { class: 'lic' }, ic('mute', 20)), c2.muted ? t('unmute') : t('mute')),
        h('button', { class: 'lrow danger', onclick: async () => { try { await api('/api/blocks', { body: { user_id: p.id, block: !S.blocked.has(p.id) } }); if (S.blocked.has(p.id)) S.blocked.delete(p.id); else S.blocked.add(p.id); Sync.now(); draw(); } catch (e) { toast(errText(e)); } } }, h('span', { class: 'lic' }, ic('ban', 20)), S.blocked.has(p.id) ? t('unblock') : t('block')));
    } else {
      const nm = h('h2', null, c2.name);
      body.append(h('div', { class: 'ibig' }, avatar(c2.name, 96, true), nm, h('p', { class: 'muted' }, t('members_n', { n: c2.members.length })),
        amAdmin && h('button', { class: 'btn ghost', onclick: async () => { const v = await ask(t('rename_group'), [{ label: t('group_name'), value: c2.name, max: 60 }]); if (v && v[0].trim()) { try { await api('/api/chats/' + chatId, { method: 'PATCH', body: { name: v[0].trim() } }); await Sync.now(); draw(); } catch (e) { toast(errText(e)); } } } }, ic('pen', 16), t('rename_group'))),
        amAdmin && h('button', { class: 'lrow', onclick: async () => {
          const v = await ask(t('add_member'), [{ label: t('nc_label'), placeholder: t('nc_ph') }], t('add'));
          if (v && v[0].trim()) { try { await api('/api/chats/' + chatId + '/members', { body: { query: v[0].trim() } }); await Sync.now(); draw(); } catch (e) { toast(errText(e)); } }
        } }, h('span', { class: 'lic' }, ic('plus', 20)), t('add_member')),
        h('div', { class: 'sect' }, t('members')),
        c2.members.map((m) => h('div', { class: 'irow' }, avatar(m.full_name, 40), h('span', null, h('b', null, m.id === S.me.id ? t('you') : m.full_name), h('small', null, '@' + m.username)), m.role === 'admin' ? h('em', { class: 'adm' }, t('admin')) : null,
          amAdmin && m.id !== S.me.id ? h('button', { class: 'ib sm', onclick: async () => {
            const v = await sheet([{ v: 'adm', icon: 'crown', label: m.role === 'admin' ? t('remove_admin') : t('make_admin') }, { v: 'rm', icon: 'trash', label: t('remove_member'), danger: true }]);
            try {
              if (v === 'adm') await api('/api/chats/' + chatId + '/admin', { body: { user_id: m.id, admin: m.role !== 'admin' } });
              else if (v === 'rm') await api('/api/chats/' + chatId + '/members/' + m.id, { method: 'DELETE' });
              if (v) { await Sync.now(); draw(); }
            } catch (e) { toast(errText(e)); }
          } }, ic('more', 20)) : null)),
        h('button', { class: 'lrow danger', onclick: () => Chat.action(c2, 'leave') }, h('span', { class: 'lic' }, ic('back', 20)), t('leave_group')));
    }
  };
  el.append(header(c.type === 'group' ? t('group_info') : t('contact_info')), body);
  el._show = draw;
  draw();
  Nav.push(el, 'info');
}
