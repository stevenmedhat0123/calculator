'use strict';
/* ---------- media transfer (chunked, encrypted on the phone before upload) ---------- */
const CHUNK = 240 * 1024;
const Media = {
  urls: new Map(), loading: new Map(),
  /* Files go to the server's file storage (R2 / KV), never into the database. New servers take 2 MB pieces as raw bytes. */
  async upload(blob, name, extra, onProgress) {
    const legacyN = Math.max(1, Math.ceil(blob.size / CHUNK));
    const key = E2E.newMediaKey();
    const init = await api('/api/media', { body: { v2: 1, mime: 'application/octet-stream', size: blob.size, name: '', chunks: legacyN }, retry: true });
    const bin = !!init.bin, csz = bin ? init.chunk : CHUNK;
    const n = Math.max(1, Math.ceil(blob.size / csz));
    let done = 0;
    const up = async (i) => {
      const buf = new Uint8Array(await blob.slice(i * csz, (i + 1) * csz).arrayBuffer());
      const enc = await E2E.encChunk(key, buf);
      const payload = bin ? enc : E2E.b64(enc);
      for (let a = 0; ; a++) {
        try { await api('/api/media/' + init.id + '/' + i, { method: 'PUT', raw: payload, timeout: 60000, retry: true }); break; }
        catch (e) { if (a >= 2 || e.code === 'quota' || e.code === 'no_storage') throw e; await new Promise((r) => setTimeout(r, 800)); }
      }
      done++; if (onProgress) onProgress(done / n);
    };
    const idx = [...Array(n).keys()];
    await Promise.all([0, 1, 2].map(async () => { while (idx.length) await up(idx.shift()); }));
    this.urls.set(init.id, URL.createObjectURL(blob));
    return Object.assign({ id: init.id, mime: blob.type || 'application/octet-stream', size: blob.size, name, chunks: n, k: key }, extra || {});
  },
  /* downloaded pieces stay on the phone (still encrypted), so a photo is never downloaded twice */
  get(media, onProgress, bg) {
    if (this.urls.has(media.id)) return Promise.resolve(this.urls.get(media.id));
    if (this.loading.has(media.id)) return this.loading.get(media.id);
    const p = (async () => {
      let raw = await Disk.mediaGet(media.id);
      if (!raw || raw.length !== media.chunks) {
        raw = new Array(media.chunks); let done = 0;
        const idx = [...Array(media.chunks).keys()];
        const worker = async () => {
          while (idx.length) {
            const i = idx.shift();
            for (let a = 0; ; a++) {
              try { raw[i] = await api('/api/media/' + media.id + '/' + i, { bin: true, timeout: 60000, bg: !!bg }); break; }
              catch (e) { if (a >= 2 || e.code === 'quota' || e.status === 404) throw e; await new Promise((r) => setTimeout(r, 800)); }
            }
            done++; if (onProgress) onProgress(done / media.chunks);
          }
        };
        await Promise.all([worker(), worker(), worker(), worker()]);
        Disk.mediaPut(media.id, raw);
      }
      const parts = [];
      for (const u8 of raw) parts.push(media.k ? await E2E.decChunk(media.k, u8) : u8);
      const url = URL.createObjectURL(new Blob(parts, { type: media.mime }));
      this.urls.set(media.id, url);
      return url;
    })();
    this.loading.set(media.id, p);
    p.then(() => this.loading.delete(media.id), () => this.loading.delete(media.id));
    return p;
  }
};
async function shrinkImage(file, max = 1600) {
  if (!/^image\/(jpeg|png|webp|heic|heif)$/i.test(file.type)) return { blob: file, w: 0, h: 0 };
  try {
    const bmp = await createImageBitmap(file);
    const sc = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * sc), hh = Math.round(bmp.height * sc);
    const cv = h('canvas', { width: w, height: hh }); cv.getContext('2d').drawImage(bmp, 0, 0, w, hh);
    const blob = await new Promise((r) => cv.toBlob(r, 'image/jpeg', 0.82));
    return { blob: blob || file, w, h: hh };
  } catch (e) { return { blob: file, w: 0, h: 0 }; }
}
function saveBlobUrl(url, name, mime) {
  fetch(url).then((r) => r.blob()).then((b) => {
    if (nat && nat.save) {
      const fr = new FileReader();
      fr.onload = () => { const ok = nat.save(name, mime || b.type, String(fr.result).split(',')[1]); toast(ok ? t('saved_downloads') : t('e_generic')); };
      fr.readAsDataURL(b);
    } else { const a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove(); }
  });
}
function viewer(m) {
  let o;
  const bar = h('div', { class: 'vbar' }, h('button', { class: 'ib', onclick: () => o.close() }, ic('close', 24)), h('span', { class: 'sp' }),
    h('button', { class: 'ib', onclick: () => Media.get(m.media).then((u) => saveBlobUrl(u, m.media.name || 'file', m.media.mime)) }, ic('download', 22)));
  const body = h('div', { class: 'vbody' }, h('div', { class: 'spin' }));
  o = overlay(h('div', { class: 'viewer' }, bar, body), { sticky: true });
  Media.get(m.media).then((u) => {
    body.replaceChildren(m.type === 'video' ? h('video', { src: u, controls: true, autoplay: true, playsInline: true }) : h('img', { src: u }));
  }).catch(() => body.replaceChildren(h('p', { class: 'muted' }, t('e_generic'))));
}

/* ---------- emoji panel: tabs, recent, search ---------- */
function emojiPicker(onPick) {
  const search = h('input', { class: 'esearch', type: 'search', placeholder: t('emoji_search'), autocomplete: 'off', autocapitalize: 'off' });
  const grid = h('div', { class: 'egrid' });
  const tabs = h('div', { class: 'etabs' });
  let cur = Emo.recent().length ? -1 : 0;
  const keep = (e) => e.preventDefault();          // tapping an emoji must not steal focus (keeps the cursor, never closes the panel)
  const pick = (e) => { Emo.add(e); onPick(e); };
  const draw = () => {
    const q = search.value.trim();
    tabs.replaceChildren(h('button', { class: cur === -1 && !q ? 'on' : '', onpointerdown: keep, onclick: () => { cur = -1; search.value = ''; draw(); } }, '\ud83d\udd58'),
      ...EMOJI.map((c, i) => h('button', { class: i === cur && !q ? 'on' : '', onpointerdown: keep, onclick: () => { cur = i; search.value = ''; draw(); } }, c[0])));
    const list = q ? Emo.search(q) : (cur === -1 ? Emo.recent() : EMOJI[cur][1]);
    grid.replaceChildren(...list.map((e) => h('button', { class: 'eb', onpointerdown: keep, onclick: () => pick(e) }, e)),
      list.length ? null : h('p', { class: 'muted center emsg' }, q ? t('no_results') : t('emoji_recent_empty')));
  };
  search.addEventListener('input', draw);
  const wrap = h('div', { class: 'epick' }, h('div', { class: 'esw' }, ic('search', 16), search), tabs, grid);
  wrap._refresh = draw; draw();
  return wrap;
}

/* ---------- voice recorder ---------- */
const Rec = {
  mr: null, chunks: [], t0: 0, timer: null, stream: null,
  async start(onTick) {
    this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
    const mt = types.find((x) => window.MediaRecorder && MediaRecorder.isTypeSupported(x)) || '';
    this.mr = new MediaRecorder(this.stream, mt ? { mimeType: mt } : undefined);
    this.chunks = []; this.mr.ondataavailable = (e) => { if (e.data.size) this.chunks.push(e.data); };
    this.mr.start(250); this.t0 = Date.now();
    this.timer = setInterval(() => onTick(Math.floor((Date.now() - this.t0) / 1000)), 250);
  },
  stop() {
    return new Promise((res) => {
      clearInterval(this.timer);
      const dur = (Date.now() - this.t0) / 1000;
      this.mr.onstop = () => { this.stream.getTracks().forEach((x) => x.stop()); res({ blob: new Blob(this.chunks, { type: this.mr.mimeType || 'audio/webm' }), dur }); };
      try { this.mr.stop(); } catch (e) { res(null); }
    });
  },
  cancel() { clearInterval(this.timer); try { this.mr.onstop = () => {}; this.mr.stop(); } catch (e) { /* ignore */ } if (this.stream) this.stream.getTracks().forEach((x) => x.stop()); }
};

/* ---------- swipe a message to reply: it follows the finger ---------- */
function attachSwipe(row, bub, icon, onReply) {
  let sx = 0, sy = 0, dx = 0, decided = false, horiz = false, fired = false;
  row.addEventListener('touchstart', (e) => { sx = e.touches[0].clientX; sy = e.touches[0].clientY; dx = 0; decided = false; horiz = false; fired = false; bub.style.transition = 'none'; }, { passive: true });
  row.addEventListener('touchmove', (e) => {
    const x = e.touches[0].clientX - sx, y = e.touches[0].clientY - sy;
    if (!decided) { if (Math.abs(x) > 8 || Math.abs(y) > 8) { decided = true; horiz = x > 0 && Math.abs(x) > Math.abs(y) * 1.3; } return; }
    if (!horiz) return;
    dx = Math.min(x * 0.72, 96);
    bub.style.transform = 'translateX(' + dx + 'px)';
    icon.style.opacity = String(Math.min(1, dx / 46)); icon.style.transform = 'translateY(-50%) scale(' + (0.55 + Math.min(0.55, dx / 110)) + ')';
    if (dx >= 62 && !fired) { fired = true; if (navigator.vibrate) navigator.vibrate(14); icon.classList.add('hit'); }
    if (dx < 62 && fired) { fired = false; icon.classList.remove('hit'); }
  }, { passive: true });
  const end = () => {
    bub.style.transition = 'transform .24s cubic-bezier(.2,.9,.3,1)'; bub.style.transform = '';
    icon.style.opacity = '0'; icon.classList.remove('hit');
    if (horiz && dx >= 62) onReply();
    dx = 0; horiz = false;
  };
  row.addEventListener('touchend', end); row.addEventListener('touchcancel', end);
}

/* ---------- chat actions available from lists ---------- */
const Chat = {
  async open(id) {
    if (!S.chats.get(id)) { await Sync.now(); if (!S.chats.has(id)) return toast(t('e_generic')); }
    Nav.push(chatScreen(id), 'chat');
  },
  async action(c, v) {
    try {
      if (v === 'mute') await api('/api/chats/' + c.id + '/me', { method: 'PATCH', body: { muted: !c.muted } });
      else if (v === 'archive') { await api('/api/chats/' + c.id + '/me', { method: 'PATCH', body: { archived: !c.archived } }); if (!c.archived) toast(t('archived')); }
      else if (v === 'pin') {
        if (!c.pinned && [...S.chats.values()].filter((x) => x.pinned).length >= 3) return toast(t('pin_max'));
        await api('/api/chats/' + c.id + '/me', { method: 'PATCH', body: { pinned: !c.pinned } });
      } else if (v === 'lock') {
        if (!c.locked && !S.me.lock_hash && !(await createLockPassword())) return;
        await api('/api/chats/' + c.id + '/me', { method: 'PATCH', body: { locked: !c.locked } });
        if (!c.locked) toast(S.me.lock_hidden ? t('chat_locked_hidden') : t('chat_locked'));
      } else if (v === 'clear') {
        if (!(await dialog({ title: t('clear_chat'), text: t('clear_confirm'), ok: t('clear_chat'), danger: true }))) return;
        await api('/api/chats/' + c.id + '/clear', { body: {} }); S.msgs.set(c.id, []);
      } else if (v === 'leave') {
        if (!(await dialog({ title: t('leave_group'), text: t('leave_confirm'), ok: t('leave_group'), danger: true }))) return;
        await api('/api/chats/' + c.id + '/members/' + S.me.id, { method: 'DELETE' });
        if (S.openChat === c.id) Nav.pop();
      }
      Sync.now();
    } catch (e) { toast(errText(e)); }
  }
};

/* ---------- the chat screen ---------- */
function chatScreen(chatId) {
  const el = h('div', { class: 'chat' });
  const list = h('div', { class: 'msgs' });
  const cache = new Map();
  let pend = [];
  let replyTo = null, editing = null, more = !!(S.hist.get(chatId) && S.hist.get(chatId).more), loadingOld = false, emojiOpen = false, recording = false, searchQ = '';
  const c0 = () => S.chats.get(chatId);
  S.openChat = chatId; S.typing = []; S.seen = [];
  el._leave = () => { if (S.openChat === chatId) S.openChat = null; stopAudio(); };
  el._show = () => { S.openChat = chatId; Sync.kick(); markRead(); };

  const nameEl = h('div', { class: 'ttl' }), subEl = h('div', { class: 'sub' });
  const avBox = h('div', { class: 'avb' });
  const searchBtn = h('button', { class: 'ib', onclick: () => toggleSearch() }, ic('search', 22));
  const head = h('div', { class: 'hdr chat-h' },
    h('button', { class: 'ib', onclick: () => Nav.pop() }, ic('back', 24, 'flip')),
    h('div', { class: 'hmain', onclick: () => infoScreen(chatId) }, avBox, h('div', { class: 'hdr-t' }, nameEl, subEl)),
    searchBtn, h('button', { class: 'ib', onclick: menu }, ic('more', 22)));
  const searchIn = h('input', { type: 'search', placeholder: t('search_in_chat'), autocomplete: 'off' });
  const searchBar = h('div', { class: 'csearch' }, ic('search', 16), searchIn);
  searchBar.style.display = 'none';
  const replyBar = h('div', { class: 'rbar' });
  const input = h('textarea', { rows: 1, placeholder: t('type_msg'), maxLength: 4000 });
  const emojiBtn = h('button', { class: 'ib', onclick: () => toggleEmoji() }, ic('smile', 24));
  const attachBtn = h('button', { class: 'ib', onclick: attach }, ic('clip', 22));
  const sendBtn = h('button', { class: 'sendb', onclick: () => (input.value.trim() ? send() : startRec()) }, ic('mic', 22));
  const cbox = h('div', { class: 'cbox' }, emojiBtn, input, attachBtn);
  const comp = h('div', { class: 'composer' }, cbox, sendBtn);
  const epWrap = h('div', { class: 'epw' });
  const blockedBar = h('div', { class: 'blkbar' });
  const keyBar = h('div', { class: 'keybar' });
  const fileIn = h('input', { type: 'file', multiple: true, class: 'hidden' });
  fileIn.addEventListener('change', async () => { const fs = [...fileIn.files]; fileIn.value = ''; for (const f of fs) await sendFile(f); });
  el.append(head, searchBar, keyBar, list, replyBar, blockedBar, comp, epWrap, fileIn);

  function updSend() {
    if (!input.value) { caretA = caretB = 0; }
    const has = !!input.value.trim();
    sendBtn.replaceChildren(ic(has ? 'send' : 'mic', 22, has ? 'flip' : ''));
    input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px';
  }
  let typingAt = 0;
  input.addEventListener('input', () => {
    updSend();
    const c = c0();
    if (input.value && c && !isSelf(c) && Date.now() - typingAt > 2500) { typingAt = Date.now(); api('/api/chats/' + chatId + '/typing', { body: {}, quiet: true, noRetry: true }).catch(() => {}); }
  });
  // tapping the text box while the emoji panel is open brings the keyboard back
  input.addEventListener('click', () => { if (emojiOpen) toggleEmoji(false, true); });
  input.addEventListener('focus', () => { setTimeout(() => { list.scrollTop = list.scrollHeight; }, 250); });
  /* the caret is remembered while the emoji panel has the focus, so an emoji lands exactly where I was typing */
  let caretA = 0, caretB = 0;
  const saveCaret = () => { if (document.activeElement === input && input.selectionStart != null) { caretA = input.selectionStart; caretB = input.selectionEnd; } };
  ['keyup', 'click', 'input', 'select', 'touchend', 'focus'].forEach((ev) => input.addEventListener(ev, () => setTimeout(saveCaret, 0)));
  document.addEventListener('selectionchange', saveCaret);
  function insertText(s) {
    const len = input.value.length;
    const a = Math.min(caretA, len), b = Math.min(Math.max(caretB, a), len);
    input.value = input.value.slice(0, a) + s + input.value.slice(b);
    const pos = a + s.length;
    caretA = caretB = pos;
    try { input.focus({ preventScroll: true }); input.setSelectionRange(pos, pos); } catch (e) { /* ignore */ }
    input.dispatchEvent(new Event('input'));
  }
  function toggleEmoji(on, toKeyboard) {
    emojiOpen = on === undefined ? !emojiOpen : on;
    epWrap.replaceChildren(emojiOpen ? emojiPicker((e) => insertText(e)) : '');
    epWrap.classList.toggle('open', emojiOpen);
    emojiBtn.replaceChildren(ic(emojiOpen ? 'chat' : 'smile', 24));
    if (emojiOpen) { input.inputMode = 'none'; input.focus(); }
    else { input.inputMode = 'text'; if (toKeyboard !== false) { input.blur(); input.focus(); } }
  }
  function toggleSearch() {
    const open = searchBar.style.display === 'none';
    searchBar.style.display = open ? '' : 'none'; searchQ = '';
    if (open) { searchIn.value = ''; searchIn.focus(); } else draw();
    draw();
  }
  searchIn.addEventListener('input', () => { searchQ = searchIn.value.trim().toLowerCase(); draw(); });
  el._back = () => {
    if (emojiOpen) { toggleEmoji(false, false); return true; }
    if (searchBar.style.display !== 'none') { toggleSearch(); return true; }
    return false;
  };

  /* ----- header / status ----- */
  function drawHead() {
    const c = c0(); if (!c) return;
    nameEl.textContent = chatTitle(c);
    const peer = c.type === 'dm' ? peerOf(c) : null;
    const self = isSelf(c);
    avBox.replaceChildren(self ? h('div', { class: 'av selfav', style: { width: '40px', height: '40px' } }, ic('user', 20)) : avatar(chatTitle(c), 40, c.type === 'group', peer ? { id: peer.id, av: peer.av } : null));
    let sub = '';
    const typers = Typing.names(chatId).concat(S.typing.filter((n) => !Typing.names(chatId).includes(n)));
    if (typers.length) sub = c.type === 'group' ? typers.map((n) => n.split(' ')[0]).join(', ') + ' ' + t('typing') : t('typing');
    else if (self) sub = t('message_yourself_sub');
    else if (c.type === 'dm') {
      const sn = peer && S.seen.find((x) => x.id === peer.id);
      const lv = peer && Presence.map.get(peer.id);
      if (lv && lv.o) sub = t('online');
      else if (lv && lv.t) sub = t('last_seen', { d: fmtDay(lv.t), t: fmtTime(lv.t) });
      else if (sn && sn.last_seen) sub = (!Sync.wsOk && Date.now() - sn.last_seen < 100000) ? t('online') : t('last_seen', { d: fmtDay(sn.last_seen), t: fmtTime(sn.last_seen) });
      if (isRequest(c)) sub = t('not_subscribed') + (sub ? ' \u00b7 ' + sub : '');
    } else sub = c.members.map((m) => (m.id === S.me.id ? t('you') : displayName(m.id).split(' ')[0])).join(', ');
    subEl.textContent = sub; subEl.classList.toggle('typ', !!typers.length);
    const iBlocked = peer && S.blocked.has(peer.id);
    blockedBar.replaceChildren(iBlocked ? h('span', null, t('you_blocked'), ' ', h('button', { class: 'lnk', onclick: () => blockUser(peer.id, false) }, t('unblock'))) : '');
    blockedBar.style.display = iBlocked ? '' : 'none'; comp.style.display = iBlocked ? 'none' : '';
    const kc = c.members.some((m) => S.keyChanged.has(m.id));
    keyBar.replaceChildren(kc ? h('span', null, ic('shield', 14), ' ', t('key_changed_bar'), ' ', h('button', { class: 'lnk sm', onclick: () => { c.members.forEach((m) => S.keyChanged.delete(m.id)); drawHead(); } }, t('ok'))) : '');
    keyBar.style.display = kc ? '' : 'none';
  }
  async function blockUser(uid2, block) {
    try { await api('/api/blocks', { body: { user_id: uid2, block } }); if (block) S.blocked.add(uid2); else S.blocked.delete(uid2); toast(block ? t('blocked_done') : t('unblocked_done')); Sync.now(); drawHead(); } catch (e) { toast(errText(e)); }
  }
  async function menu() {
    const c = c0(); if (!c) return;
    const peer = c.type === 'dm' ? peerOf(c) : null;
    const v = await sheet([{ v: 'info', icon: c.type === 'group' ? 'users' : 'user', label: c.type === 'group' ? t('group_info') : t('contact_info') },
      { v: 'search', icon: 'search', label: t('search_in_chat') },
      { v: 'pin', icon: 'pin', label: c.pinned ? t('unpin') : t('pin') },
      { v: 'mute', icon: 'mute', label: c.muted ? t('unmute') : t('mute') }, { v: 'lock', icon: 'lock', label: c.locked ? t('unlock_chat') : t('lock_chat') },
      { v: 'clear', icon: 'trash', label: t('clear_chat') },
      peer && { v: 'block', icon: 'ban', label: S.blocked.has(peer.id) ? t('unblock') : t('block'), danger: true },
      c.type === 'group' && { v: 'leave', icon: 'back', label: t('leave_group'), danger: true }]);
    if (v === 'info') infoScreen(chatId);
    else if (v === 'search') toggleSearch();
    else if (v === 'block') blockUser(peer.id, !S.blocked.has(peer.id));
    else if (v) Chat.action(c, v);
  }

  /* ----- messages ----- */
  function allMsgs() {
    const arr = (S.msgs.get(chatId) || []).slice();
    for (const p of pend) if (!arr.find((x) => x.id === p.id)) arr.push(p);
    return arr;
  }
  const isMine = (m) => m.sid === S.me.id;
  function replyBlock(m) {
    const r = m.reply; if (!r) return null;
    const txt = r.type === 'text' ? r.body : r.type === 'image' ? '\ud83d\udcf7 ' + t('photo') : r.type === 'video' ? '\ud83c\udfa5 ' + t('video') : r.type === 'audio' ? '\ud83c\udfa4 ' + t('voice') : '\ud83d\udcc4 ' + t('file');
    return h('div', { class: 'quote', onclick: () => jump(r.id) }, h('b', null, displayName(r.sid)), h('span', null, txt));
  }
  function mediaBlock(m) {
    const md = m.media; if (!md) return null;
    const retryBtn = (box, load) => h('button', { class: 'btn ghost', onclick: () => { box.replaceChildren(h('div', { class: 'spin' })); load(); } }, ic('download', 18), fmtSize(md.size));
    if (m.type === 'image') {
      const box = h('div', { class: 'imgbox', style: { aspectRatio: md.w && md.h ? md.w + '/' + md.h : '4/3' } }, h('div', { class: 'spin' }));
      const load = () => Media.get(md, null, true).then((u) => { box.replaceChildren(h('img', { src: u, onclick: () => viewer(m) })); }).catch(() => box.replaceChildren(retryBtn(box, load)));
      if (md.size <= 4 * 1048576 || Media.urls.has(md.id)) load(); else box.replaceChildren(retryBtn(box, load));
      if (m.pending) box.append(h('div', { class: 'prog' }, h('i', { style: { width: Math.round((m.progress || 0) * 100) + '%' } })));
      return box;
    }
    if (m.type === 'video') {
      const box = h('div', { class: 'imgbox vid', style: { aspectRatio: md.w && md.h ? md.w + '/' + md.h : '16/9' } });
      const play = () => { box.replaceChildren(h('div', { class: 'spin' })); Media.get(md).then((u) => box.replaceChildren(h('video', { src: u, controls: true, playsInline: true, preload: 'metadata' }))).catch(() => box.replaceChildren(h('button', { class: 'btn ghost', onclick: play }, ic('download', 18), t('retry')))); };
      box.append(h('button', { class: 'playbig', onclick: play }, ic('play', 30)), h('span', { class: 'vsz' }, fmtSize(md.size)));
      if (Media.urls.has(md.id)) play();
      if (m.pending) box.append(h('div', { class: 'prog' }, h('i', { style: { width: Math.round((m.progress || 0) * 100) + '%' } })));
      return box;
    }
    if (m.type === 'audio') return audioPlayer(m);
    return h('div', { class: 'filec', onclick: () => Media.get(md).then((u) => saveBlobUrl(u, md.name || 'file', md.mime)).catch(() => toast(t('e_generic'))) },
      h('span', { class: 'fic' }, ic('file', 24)), h('span', { class: 'fnm' }, h('b', null, md.name || t('file')), h('small', null, fmtSize(md.size))), ic('download', 20));
  }
  function bubble(m) {
    const mine = isMine(m);
    const c = c0();
    const showName = !mine && c && c.type === 'group';
    const rx = Object.values(m.rx || {});
    const rxCount = {}; rx.forEach((e) => { rxCount[e] = (rxCount[e] || 0) + 1; });
    const content = m.del ? h('div', { class: 'txt del' }, '\u2298 ', mine ? t('you_deleted') : t('msg_deleted'))
      : [showName && h('div', { class: 'sname', style: { color: PAL[[...displayName(m.sid)].reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) >>> 0, 0) % PAL.length] } }, displayName(m.sid)),
        m.fwd ? h('div', { class: 'fwd' }, ic('share', 12), ' ', t('forwarded_label')) : null,
        replyBlock(m), mediaBlock(m), m.body && m.type !== 'sys' ? h('div', { class: 'txt' }, renderText(m.body)) : null];
    const ticks = c && isSelf(c) ? [[S.me.id, 1, 1]] : (m.pending ? [] : rcOf(m.id));
    return h('div', { class: 'bub ' + (mine ? 'out' : 'in') + (m.type === 'image' && !m.body && !m.del ? ' mono' : '') + (m.failed ? ' failed' : '') },
      content,
      h('div', { class: 'meta' }, m.ed && !m.del ? h('span', null, t('edited')) : null, h('span', null, fmtTime(m.at)), mine && !m.del && tickEl(ticks, m.pending && !m.failed),
        m.failed ? h('button', { class: 'lnk sm', onclick: () => retry(m) }, t('retry')) : null),
      rx.length ? h('div', { class: 'rx' }, Object.entries(rxCount).map(([e, n]) => h('span', null, e, n > 1 ? n : ''))) : null);
  }
  function draw() {
    const msgs = allMsgs().filter((m) => !searchQ || (m.body && m.body.toLowerCase().includes(searchQ)));
    const near = list.scrollHeight - list.scrollTop - list.clientHeight < 120;
    const out = []; let lastDay = '';
    if (loadingOld) out.push(h('div', { class: 'older' }, h('div', { class: 'spin' })));
    for (const m of msgs) {
      const day = new Date(m.at).toDateString();
      if (day !== lastDay) { lastDay = day; out.push(h('div', { class: 'day' }, h('span', null, fmtDay(m.at)))); }
      if (m.type === 'sys') { out.push(h('div', { class: 'sysm' }, h('span', null, sysText(m)))); continue; }
      const sig = [m.up, m.del, m.pending, m.failed, m.progress && Math.round(m.progress * 20), JSON.stringify(rcOf(m.id)), S.lang, JSON.stringify(m.rx || {}), m.body && m.body.length, m._fail].join('|');
      let ent = cache.get(m.id);
      if (!ent || ent.sig !== sig) {
        const bub = bubble(m);
        const swipeIc = h('span', { class: 'swipe-ic' }, ic('reply', 20));
        const row = h('div', { class: 'row ' + (isMine(m) ? 'out' : 'in'), 'data-id': m.id }, swipeIc, bub);
        if (!m.pending) {
          onLong(row, () => msgMenu(m));
          if (!m.del) attachSwipe(row, bub, swipeIc, () => setReply(m));
        } else row.addEventListener('click', () => { if (m.failed) retry(m); });
        ent = { sig, el: row }; cache.set(m.id, ent);
      }
      out.push(ent.el);
    }
    if (!msgs.length) out.push(h('div', { class: 'empty' }, ic('lock', 28), h('p', { class: 'muted' }, searchQ ? t('no_results') : t('say_hi')), searchQ ? null : h('p', { class: 'muted s' }, t('e2e_note'))));
    list.replaceChildren(...out);
    if (near || list._first) { list.scrollTop = list.scrollHeight; list._first = false; }
  }
  function jump(id) { const e = cache.get(id); if (e) { e.el.scrollIntoView({ block: 'center' }); e.el.classList.add('flash'); setTimeout(() => e.el.classList.remove('flash'), 1000); } }
  function setReply(m) {
    replyTo = m; editing = null;
    const txt = m.type === 'text' ? m.body : previewText(m);
    replyBar.replaceChildren(h('div', { class: 'rb' }, h('b', null, displayName(m.sid)), h('span', null, txt.slice(0, 80))), h('button', { class: 'ib', onclick: clearReply }, ic('close', 20)));
    replyBar.style.display = ''; input.focus();
  }
  function clearReply() { replyTo = null; editing = null; replyBar.style.display = 'none'; replyBar.replaceChildren(); }
  clearReply();

  async function loadHistory() {
    const cur = S.hist.get(chatId), had = !!(cur && !cur.partial);
    try {
      await Hist.loadChat(chatId);                 // from memory / this phone; the server only when the chat was never opened here
      more = !!(S.hist.get(chatId) || {}).more;
      list._first = !had; draw(); drawHead(); markRead();
    } catch (e) { toast(errText(e)); }
  }
  let olderFail = 0;
  async function loadOlder() {
    if (loadingOld || !more || Date.now() - olderFail < 15000) return; loadingOld = true;
    const h0 = list.scrollHeight, t0 = list.scrollTop; draw();
    try { await Hist.older(chatId); more = !!(S.hist.get(chatId) || {}).more; }
    catch (e) { olderFail = Date.now(); toast(errText(e)); }
    loadingOld = false; draw(); list.scrollTop = list.scrollHeight - h0 + t0;
  }
  list.addEventListener('scroll', () => { if (list.scrollTop < 180 && more && !loadingOld) loadOlder(); }, { passive: true });
  let readT = null;
  function markRead() {
    clearTimeout(readT);
    readT = setTimeout(async () => {
      const c = c0(); if (!c || document.hidden || S.openChat !== chatId) return;
      const arr = S.msgs.get(chatId) || [];
      const need = c.unread > 0 || arr.some((m) => !isMine(m) && m.type !== 'sys' && m.at > (c.read_upto || 0));
      if (!need) return;
      c.unread = 0; c.read_upto = Date.now(); App.refresh();
      try { await api('/api/chats/' + chatId + '/read', { body: {}, quiet: true, noRetry: true }); } catch (e) { /* ignore */ }
    }, 60);
  }
  el._draw = () => { if (!c0()) return; drawHead(); if (S.hist.has(chatId)) { draw(); markRead(); } };

  /* ----- sending (everything is encrypted before it leaves the phone) ----- */
  const contentOf = (m) => ({
    b: m.body || '', r: m.reply ? { id: m.reply.id, sid: m.reply.sid, type: m.reply.type, body: String(m.reply.body || '').slice(0, 120) } : null,
    m: m.media ? Object.assign({}, m.media) : null, f: m.fwd ? 1 : 0
  });
  async function post(m) {
    try {
      const c = c0(); const ids = c.members.map((x) => x.id);
      const need = ids.filter((i) => !E2E.hasPub(i)); if (need.length) await fetchKeys(need);
      const { payload } = await E2E.encrypt(chatId, m.id, contentOf(m), ids);
      const body = { id: m.id, type: m.type, body: payload, enc: 1 };
      if (m.media) body.media = { id: m.media.id, chunks: m.media.chunks, mime: 'application/octet-stream', size: m.media.size, name: '' };
      const r = await api('/api/chats/' + chatId + '/messages', { body, retry: true });
      await decryptMsg(r.msg);
      pend = pend.filter((x) => x.id !== m.id);
      if (!S.hist.has(chatId)) { Hist.merge(chatId, [r.msg]); S.hist.set(chatId, { more: true, partial: true }); } else upsertMsg(r.msg);
      if (Disk.has(chatId)) Disk.touchMsg(r.msg);
      const c2 = c0(); if (c2) { c2.last = r.msg; c2.up = r.msg.up; }
      draw(); list.scrollTop = list.scrollHeight; setTimeout(() => Sync.kick(), 1500); App.refresh();
    } catch (e) {
      m.failed = true; draw();
      toast(e.message === 'no_key' || e.code === 'no_key' ? t('e_no_key') : (e.code === 'you_blocked' ? t('you_blocked') : errText(e)));
    }
  }
  async function send() {
    const text = input.value.trim(); if (!text) return;
    if (editing) {
      const m = editing; clearReply(); input.value = ''; updSend();
      try {
        const ids = c0().members.map((x) => x.id);
        const { payload } = await E2E.encrypt(chatId, m.id, { b: text, r: m.reply ? { id: m.reply.id, sid: m.reply.sid, type: m.reply.type, body: String(m.reply.body || '').slice(0, 120) } : null, f: m.fwd ? 1 : 0 }, ids);
        await api('/api/messages/' + m.id, { method: 'PATCH', body: { body: payload, enc: 1 } }); Sync.now();
      } catch (e) { toast(e.code === 'too_late' ? t('e_too_late') : errText(e)); }
      return;
    }
    const id = uid();
    const m = { id, chat_id: chatId, sid: S.me.id, type: 'text', body: text, media: null, reply: replyTo ? { id: replyTo.id, sid: replyTo.sid, type: replyTo.type, body: replyTo.body } : null, rx: {}, del: 0, at: Date.now(), up: Date.now(), ed: 0, pending: true, enc: 1 };
    clearReply(); input.value = ''; updSend();
    pend.push(m); draw(); list.scrollTop = list.scrollHeight;
    await post(m);
  }
  /* a reaction appears the instant it is tapped; the server call follows in the background */
  function reactNow(m, e) {
    const old = m.rx || {}, rx = Object.assign({}, old);
    if (!e || rx[S.me.id] === e) delete rx[S.me.id]; else rx[S.me.id] = e;
    m.rx = rx; draw();
    api('/api/messages/' + m.id + '/react', { body: { emoji: e }, retry: true }).then(() => { setTimeout(() => Sync.kick(), 1200); }).catch((x) => { m.rx = old; draw(); toast(errText(x)); });
  }
  /* when the connection comes back, messages that could not be sent go out by themselves */
  const onNet = () => { if (!el.isConnected) { window.removeEventListener('online', onNet); return; } pend.filter((x) => x.failed && !x._blob).forEach((x) => retry(x)); };
  window.addEventListener('online', onNet);
  /* the keys of the people in this chat are fetched as soon as it opens, so the first message does not wait for them */
  setTimeout(() => { const c = c0(); if (c && c.members) { const need = c.members.map((x) => x.id).filter((i) => !E2E.hasPub(i)); if (need.length) fetchKeys(need).catch(() => {}); } }, 0);
  function retry(m) { m.failed = false; draw(); if (m._blob) uploadAndPost(m, m._blob, m._name, m._extra); else post(m); }
  function attach() {
    sheet([{ v: 'media', icon: 'image', label: t('att_media') }, { v: 'file', icon: 'file', label: t('att_file') }]).then((v) => {
      if (!v) return; fileIn.accept = v === 'media' ? 'image/*,video/*' : '*/*'; fileIn.click();
    });
  }
  async function sendFile(file) {
    if (file.size > 64 * 1048576) return toast(t('e_too_big'));
    const id = uid();
    const isImg = file.type.startsWith('image/'), isVid = file.type.startsWith('video/');
    const type = isImg ? 'image' : isVid ? 'video' : 'file';
    const m = { id, chat_id: chatId, sid: S.me.id, type, body: '', media: { id: 'tmp' + id, mime: file.type, size: file.size, name: file.name, chunks: 1, w: 0, h: 0 }, rx: {}, del: 0, at: Date.now(), up: Date.now(), ed: 0, pending: true, progress: 0, enc: 1 };
    let blob = file, extra = {};
    if (isImg) { const s = await shrinkImage(file); blob = s.blob; extra = { w: s.w, h: s.h }; m.media.w = s.w; m.media.h = s.h; m.media.size = blob.size; }
    Media.urls.set(m.media.id, URL.createObjectURL(blob));
    pend.push(m); draw(); list.scrollTop = list.scrollHeight;
    await uploadAndPost(m, blob, file.name, extra);
  }
  async function uploadAndPost(m, blob, name, extra) {
    try {
      const real = await Media.upload(blob, name, extra, (p) => { m.progress = p; draw(); });
      Media.urls.set(real.id, Media.urls.get(m.media.id));
      m.media = real;
      await post(m);
    } catch (e) { m.failed = true; m._blob = blob; m._name = name; m._extra = extra; draw(); toast(errText(e)); }
  }

  /* ----- voice notes ----- */
  async function startRec() {
    if (recording) return;
    try {
      const bar = h('div', { class: 'recbar' });
      const timer = h('span', { class: 'rect' }, '0:00');
      await Rec.start((s) => { timer.textContent = fmtDur(s); });
      recording = true;
      const stop = async (sendIt) => {
        recording = false; bar.remove(); cbox.style.display = ''; sendBtn.style.display = '';
        if (!sendIt) { Rec.cancel(); return; }
        const r = await Rec.stop(); if (!r || r.dur < 0.6) return toast(t('too_short'));
        const id = uid();
        const m = { id, chat_id: chatId, sid: S.me.id, type: 'audio', body: '', media: { id: 'tmp' + id, mime: r.blob.type, size: r.blob.size, name: 'voice', chunks: 1, dur: r.dur }, rx: {}, del: 0, at: Date.now(), up: Date.now(), ed: 0, pending: true, progress: 0, enc: 1 };
        Media.urls.set(m.media.id, URL.createObjectURL(r.blob));
        pend.push(m); draw(); list.scrollTop = list.scrollHeight;
        await uploadAndPost(m, r.blob, 'voice.' + (r.blob.type.includes('mp4') ? 'm4a' : 'webm'), { dur: Math.round(r.dur) });
      };
      bar.append(h('button', { class: 'ib danger', onclick: () => stop(false) }, ic('trash', 22)), h('span', { class: 'recdot' }), timer, h('span', { class: 'sp' }),
        h('button', { class: 'sendb', onclick: () => stop(true) }, ic('send', 20, 'flip')));
      cbox.style.display = 'none'; sendBtn.style.display = 'none'; comp.append(bar);
    } catch (e) { recording = false; toast(t('e_mic')); }
  }

  /* ----- message actions ----- */
  async function msgMenu(m) {
    const mine = isMine(m);
    const quick = ['\ud83d\udc4d', '\u2764\ufe0f', '\ud83d\ude02', '\ud83d\ude2e', '\ud83d\ude22', '\ud83d\ude4f'];
    let o;
    const react = (e) => { o.close(); reactNow(m, e); };
    const act = (fn) => () => { o.close(); fn(); };
    const items = m.del ? [h('button', { class: 'sheet-i', onclick: act(() => delMe(m)) }, ic('trash', 20), h('span', null, t('delete_me')))] : [
      h('button', { class: 'sheet-i', onclick: act(() => setReply(m)) }, ic('reply', 20), h('span', null, t('reply'))),
      m.type === 'text' && h('button', { class: 'sheet-i', onclick: act(() => copyText(m.body)) }, ic('copy', 20), h('span', null, t('copy'))),
      mine && m.type === 'text' && Date.now() - m.at < 15 * 60 * 1000 && h('button', { class: 'sheet-i', onclick: act(() => { editing = m; replyTo = null; input.value = m.body; updSend(); replyBar.replaceChildren(h('div', { class: 'rb' }, h('b', null, t('edit')), h('span', null, m.body.slice(0, 80))), h('button', { class: 'ib', onclick: () => { clearReply(); input.value = ''; updSend(); } }, ic('close', 20))); replyBar.style.display = ''; input.focus(); }) }, ic('pen', 20), h('span', null, t('edit'))),
      h('button', { class: 'sheet-i', onclick: act(() => forward(m)) }, ic('share', 20), h('span', null, t('forward'))),
      mine && h('button', { class: 'sheet-i', onclick: act(() => msgInfo(m)) }, ic('info', 20), h('span', null, t('msg_info'))),
      h('button', { class: 'sheet-i danger', onclick: act(() => delMe(m)) }, ic('trash', 20), h('span', null, t('delete_me'))),
      mine && h('button', { class: 'sheet-i danger', onclick: act(() => delAll(m)) }, ic('trash', 20), h('span', null, t('delete_all')))];
    const card = h('div', { class: 'sheet' }, !m.del && h('div', { class: 'qrx' }, quick.map((e) => h('button', { onclick: () => react(e) }, e)),
      h('button', { class: 'more', onclick: () => { o.close(); moreReact(m); } }, ic('plus', 20))), items);
    o = overlay(card);
  }
  function moreReact(m) {
    let o;
    o = overlay(h('div', { class: 'sheet tall' }, emojiPicker((e) => { o.close(); reactNow(m, e); })));
  }
  async function delMe(m) {
    if (!(await dialog({ title: t('delete_me'), text: t('delete_me_text'), ok: t('delete'), danger: true }))) return;
    try { await api('/api/messages/' + m.id + '/delete', { body: { scope: 'me' } }); const a = S.msgs.get(chatId) || []; S.msgs.set(chatId, a.filter((x) => x.id !== m.id)); Disk.dropMsg(m); draw(); Sync.now(); } catch (e) { toast(errText(e)); }
  }
  async function delAll(m) {
    if (!(await dialog({ title: t('delete_all'), text: t('delete_all_text'), ok: t('delete'), danger: true }))) return;
    try { await api('/api/messages/' + m.id + '/delete', { body: { scope: 'all' } }); Sync.now(); } catch (e) { toast(errText(e)); }
  }
  async function forward(m) {
    const chats = sortedChats(() => true, '');
    let o;
    const pick = async (c) => {
      o.close();
      try {
        const nid = uid(); const ids = c.members.map((x) => x.id);
        const need = ids.filter((i) => !E2E.hasPub(i)); if (need.length) await fetchKeys(need);
        const { payload } = await E2E.encrypt(c.id, nid, { b: m.body || '', m: m.media ? Object.assign({}, m.media) : null, r: null, f: 1 }, ids);
        const body = { id: nid, type: m.type, body: payload, enc: 1 };
        if (m.media) body.media = { id: m.media.id, chunks: m.media.chunks, mime: 'application/octet-stream', size: m.media.size, name: '' };
        await api('/api/chats/' + c.id + '/messages', { body, retry: true }); toast(t('forwarded')); Sync.now();
      } catch (e) { toast(e.message === 'no_key' ? t('e_no_key') : errText(e)); }
    };
    o = overlay(h('div', { class: 'sheet tall' }, h('h3', { class: 'sh' }, t('forward_to')), chats.map((c) => h('button', { class: 'sheet-i', onclick: () => pick(c) }, avatar(chatTitle(c), 36, c.type === 'group'), h('span', null, chatTitle(c))))));
  }
  function msgInfo(m) {
    const rc = rcOf(m.id);
    const el2 = h('div', { class: 'main' });
    const sect = (title, key) => {
      const l = rc.filter((x) => x[key]).sort((a, b) => a[key] - b[key]);
      return [h('div', { class: 'sect' }, title), l.length ? l.map((x) => h('div', { class: 'irow' }, avatar(displayName(x[0]), 36), h('span', null, displayName(x[0])), h('small', null, fmtDay(x[key]) + ' ' + fmtTime(x[key])))) : h('div', { class: 'muted pad2' }, '\u2014')];
    };
    el2.append(header(t('msg_info')), h('div', { class: 'pad' }, h('div', { class: 'row out info-b' }, bubble(Object.assign({}, m))), h('p', { class: 'muted' }, t('sent_at') + ': ' + fmtDay(m.at) + ' ' + fmtTime(m.at)),
      sect(t('read_by'), 2), sect(t('delivered_to'), 1)));
    Nav.push(el2, 'msginfo');
  }

  /* ----- boot: show what is already loaded instantly, then refresh ----- */
  drawHead(); updSend();
  if (S.hist.has(chatId)) { list._first = true; draw(); markRead(); }
  loadHistory();
  Sync.kick();
  return el;
}

/* ---------- audio ---------- */
let curAudio = null;
function stopAudio() { if (curAudio) { try { curAudio.pause(); } catch (e) { /* ignore */ } curAudio = null; } }
function audioPlayer(m) {
  const md = m.media;
  const au = new Audio(); au.preload = 'none';
  const playBtn = h('button', { class: 'pl' }, ic('play', 20));
  const bar = h('div', { class: 'wave' }, h('i'));
  const tm = h('span', { class: 'dur' }, fmtDur(md.dur));
  const speeds = [1, 1.5, 2]; let si = 0;
  const spd = h('button', { class: 'spd', onclick: () => { si = (si + 1) % 3; au.playbackRate = speeds[si]; spd.textContent = speeds[si] + 'x'; } }, '1x');
  let ready = false;
  const setIc = (p) => playBtn.replaceChildren(ic(p ? 'pause' : 'play', 20));
  au.addEventListener('timeupdate', () => { const d = au.duration && isFinite(au.duration) ? au.duration : md.dur || 1; bar.firstChild.style.width = Math.min(100, au.currentTime / d * 100) + '%'; tm.textContent = fmtDur(au.paused && au.currentTime === 0 ? md.dur : au.currentTime); });
  au.addEventListener('ended', () => { setIc(false); bar.firstChild.style.width = '0'; tm.textContent = fmtDur(md.dur); });
  au.addEventListener('pause', () => setIc(false)); au.addEventListener('play', () => setIc(true));
  playBtn.addEventListener('click', async () => {
    if (!au.paused) return au.pause();
    if (curAudio && curAudio !== au) curAudio.pause();
    if (!ready) { try { playBtn.classList.add('busy'); au.src = await Media.get(md); ready = true; } catch (e) { toast(t('e_generic')); return; } finally { playBtn.classList.remove('busy'); } }
    curAudio = au; au.playbackRate = speeds[si]; au.play().catch(() => toast(t('e_generic')));
  });
  bar.addEventListener('click', (e) => { if (!ready) return; const r = bar.getBoundingClientRect(); const f = (S.lang === 'ar' ? r.right - e.clientX : e.clientX - r.left) / r.width; if (au.duration) au.currentTime = Math.max(0, Math.min(1, f)) * au.duration; });
  return h('div', { class: 'aud' }, playBtn, bar, tm, spd);
}

/* ---------- security code ("verify" like WhatsApp) ---------- */
async function securityScreen(peerId) {
  const el = h('div', { class: 'main' });
  const groups = await E2E.fingerprint(S.me.id, peerId);
  const code = h('div', { class: 'seccode' }, groups.map((g) => h('span', null, g)));
  el.append(header(t('verify_code')), h('div', { class: 'pad' },
    h('div', { class: 'ibig' }, h('div', { class: 'logo' }, ic('shield', 30)), h('h2', null, displayName(peerId))),
    code, h('p', { class: 'muted' }, t('verify_text', { n: displayName(peerId) })),
    h('button', { class: 'btn ghost wide', onclick: () => copyText(groups.join(' ')) }, ic('copy', 18), t('copy')),
    S.keyChanged.has(peerId) ? h('p', { class: 'err' }, t('key_changed', { n: displayName(peerId) })) : null));
  Nav.push(el, 'security');
}

/* ---------- contact / group info (WhatsApp style) ---------- */
function infoScreen(chatId) {
  const c = S.chats.get(chatId); if (!c) return;
  const el = h('div', { class: 'main' });
  const body = h('div', { class: 'pad info nopad' });
  const toggleRow = (icon, label, on, fn) => h('div', { class: 'srow' }, h('span', { class: 'lic' }, ic(icon, 20)), h('span', { class: 'sm' }, h('b', null, label)), toggle(on, fn));
  const draw = async () => {
    const c2 = S.chats.get(chatId); if (!c2) return;
    body.replaceChildren();
    const amAdmin = c2.role === 'admin';
    const msgs = (S.msgs.get(chatId) || []).filter((m) => !m.del && m.media);
    const imgs = msgs.filter((m) => m.type === 'image' || m.type === 'video'), docs = msgs.filter((m) => m.type === 'file' || m.type === 'audio');
    const mediaSec = msgs.length ? [h('div', { class: 'sect' }, t('media_docs') + ' \u00b7 ' + msgs.length),
      h('div', { class: 'mgrid' }, imgs.slice(-8).reverse().map((m) => { const b = h('div', { class: 'mth', onclick: () => viewer(m) }); if (m.type === 'image') Media.get(m.media).then((u) => { b.style.backgroundImage = 'url(' + u + ')'; }).catch(() => {}); else b.append(ic('play', 22)); return b; }),
        docs.length ? h('div', { class: 'mth doc' }, ic('file', 22), h('small', null, docs.length)) : null)] : null;
    const cm = (id2) => S.contacts.get(id2);
    if (isSelf(c2)) {
      body.append(h('div', { class: 'ibig' }, h('div', { class: 'av selfav', style: { width: '96px', height: '96px' } }, ic('user', 44)), h('h2', null, t('message_yourself')), h('p', { class: 'muted' }, t('message_yourself_sub'))), mediaSec);
    } else if (c2.type === 'dm') {
      const p = peerOf(c2); if (!p) return;
      let info = {}; try { info = await api('/api/users/' + p.id, { quiet: true }); } catch (e) { /* ignore */ }
      body.append(h('div', { class: 'ibig' }, h('div', { class: 'bigav', onclick: () => { if (p.av) Avatars.get(p.id, p.av).then((u) => u && overlay(h('div', { class: 'viewer' }, h('div', { class: 'vbody' }, h('img', { src: u }))))); } }, avatar(displayName(p.id), 110, false, { id: p.id, av: p.av })),
        h('h2', null, displayName(p.id), ' ', h('button', { class: 'ib sm', onclick: async () => { await editContact(p.id); draw(); } }, ic('pen', 16))),
        cm(p.id) ? h('p', { class: 'muted' }, '~ ' + p.full_name) : null,
        (info.last_seen || Presence.map.has(p.id)) ? h('p', { class: 'muted s' }, (() => { const lv = Presence.map.get(p.id); if (lv && lv.o) return t('online'); const ts = (lv && lv.t) || info.last_seen; if (!ts) return ''; return (!lv && !Sync.wsOk && Date.now() - ts < 100000) ? t('online') : t('last_seen', { d: fmtDay(ts), t: fmtTime(ts) }); })()) : null),
        h('div', { class: 'sect' }, t('about')), h('div', { class: 'abox' }, info.about || p.about || t('about_default')),
        mediaSec,
        h('div', { class: 'sect' }, t('contact_details')),
        h('div', { class: 'srow tap', onclick: () => copyText('@' + p.username) }, h('span', { class: 'lic' }, ic('user', 20)), h('span', { class: 'sm' }, h('b', null, '@' + p.username), h('small', null, t('f_user')))),
        info.phone ? h('div', { class: 'srow tap', onclick: () => copyText(info.phone) }, h('span', { class: 'lic' }, ic('chat', 20)), h('span', { class: 'sm' }, h('b', null, info.phone), h('small', null, t('f_phone')))) : null,
        h('div', { class: 'sect' }, t('settings')),
        toggleRow('mute', t('mute'), !!c2.muted, async (v) => { try { await api('/api/chats/' + chatId + '/me', { method: 'PATCH', body: { muted: v } }); Sync.now(); } catch (e) { toast(errText(e)); return false; } }),
        toggleRow('lock', t('lock_chat'), !!c2.locked, async (v) => { if (v && !S.me.lock_hash && !(await createLockPassword())) return false; try { await api('/api/chats/' + chatId + '/me', { method: 'PATCH', body: { locked: v } }); Sync.now(); } catch (e) { toast(errText(e)); return false; } }),
        h('div', { class: 'srow tap', onclick: () => securityScreen(p.id) }, h('span', { class: 'lic' }, ic('shield', 20)), h('span', { class: 'sm' }, h('b', null, t('encryption')), h('small', null, t('encryption_sub')))),
        (info.groups && info.groups.length) ? [h('div', { class: 'sect' }, t('common_groups', { n: info.groups.length })), info.groups.map((g) => h('div', { class: 'irow' }, avatar(g.name, 40, true), h('span', null, h('b', null, g.name))))] : null,
        h('button', { class: 'lrow danger', onclick: async () => { try { await api('/api/blocks', { body: { user_id: p.id, block: !S.blocked.has(p.id) } }); if (S.blocked.has(p.id)) S.blocked.delete(p.id); else S.blocked.add(p.id); Sync.now(); draw(); } catch (e) { toast(errText(e)); } } }, h('span', { class: 'lic' }, ic('ban', 20)), S.blocked.has(p.id) ? t('unblock') : t('block') + ' ' + displayName(p.id)));
    } else {
      const nm = h('h2', null, c2.name);
      body.append(h('div', { class: 'ibig' }, avatar(c2.name, 110, true), nm, h('p', { class: 'muted' }, t('members_n', { n: c2.members.length })),
        amAdmin && h('button', { class: 'btn ghost', onclick: async () => { const v = await ask(t('rename_group'), [{ label: t('group_name'), value: c2.name, max: 60 }]); if (v && v[0].trim()) { try { await api('/api/chats/' + chatId, { method: 'PATCH', body: { name: v[0].trim() } }); await Sync.now(); draw(); } catch (e) { toast(errText(e)); } } } }, ic('pen', 16), t('rename_group'))),
        mediaSec,
        toggleRow('mute', t('mute'), !!c2.muted, async (v) => { try { await api('/api/chats/' + chatId + '/me', { method: 'PATCH', body: { muted: v } }); Sync.now(); } catch (e) { toast(errText(e)); return false; } }),
        h('div', { class: 'srow tap', onclick: () => toast(t('e2e_note')) }, h('span', { class: 'lic' }, ic('shield', 20)), h('span', { class: 'sm' }, h('b', null, t('encryption')), h('small', null, t('encryption_group_sub')))),
        amAdmin && h('button', { class: 'lrow', onclick: async () => {
          const v = await ask(t('add_member'), [{ label: t('nc_label'), placeholder: t('nc_ph') }], t('add'));
          if (v && v[0].trim()) { try { await api('/api/chats/' + chatId + '/members', { body: { query: v[0].trim() } }); await Sync.now(); draw(); } catch (e) { toast(errText(e)); } }
        } }, h('span', { class: 'lic' }, ic('plus', 20)), t('add_member')),
        h('div', { class: 'sect' }, t('members')),
        c2.members.map((m) => h('div', { class: 'irow' }, avatar(displayName(m.id), 40, false, { id: m.id, av: m.av }), h('span', null, h('b', null, displayName(m.id)), h('small', null, '@' + m.username)), m.role === 'admin' ? h('em', { class: 'adm' }, t('admin')) : null,
          amAdmin && m.id !== S.me.id ? h('button', { class: 'ib sm', onclick: async () => {
            const v = await sheet([{ v: 'adm', icon: 'crown', label: m.role === 'admin' ? t('remove_admin') : t('make_admin') }, { v: 'rm', icon: 'trash', label: t('remove_member'), danger: true }]);
            try {
              if (v === 'adm') await api('/api/chats/' + chatId + '/admin', { body: { user_id: m.id, admin: m.role !== 'admin' } });
              else if (v === 'rm') await api('/api/chats/' + chatId + '/members/' + m.id, { method: 'DELETE' });
              if (v) { await Sync.now(); draw(); }
            } catch (e) { toast(errText(e)); }
          } }, ic('more', 20)) : null)),
        h('button', { class: 'lrow danger', onclick: () => Chat.action(c2, 'leave') }, h('span', { class: 'lic' }, ic('back', 20)), t('leave_group')));
    }
  };
  el.append(header(c.type === 'group' ? t('group_info') : t('contact_info')), body);
  el._show = draw;
  draw();
  Nav.push(el, 'info');
}
