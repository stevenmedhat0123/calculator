'use strict';
const secHdr = (txt) => h('div', { class: 'shdr' }, txt);
const srow = (icon, title, sub, right, fn) => h('div', { class: 'srow' + (fn ? ' tap' : ''), onclick: fn }, h('span', { class: 'lic' }, ic(icon, 20)), h('span', { class: 'sm' }, h('b', null, title), sub ? h('small', null, sub) : null), right);
const chev = () => ic('fwd', 18, 'flip');
const fsOn = () => store.get('fullscreen', true);

function settingsView() {
  const wrap = h('div', { class: 'sview' });
  const me = S.me;
  const upd = h('div', { class: 'srow tap', onclick: () => { if (S.update) Upd.act(); else checkUpdate(true); } });
  const drawUpd = () => {
    upd.replaceChildren(h('span', { class: 'lic' }, ic('download', 20)), h('span', { class: 'sm' }, h('b', null, t('app_update')),
      h('small', null, S.update ? t('upd_available', { v: S.update.version, s: fmtSize(S.update.size) }) : t('upd_current', { v: NV.version() }))),
      S.update ? h('span', { class: 'dotb' }) : null);
  };
  wrap._draw = drawUpd; drawUpd();
  const priv = (key, v) => async (on) => {
    const old = me[key]; me[key] = on ? 1 : 0;                       // applied at once, so my status changes in the same moment
    if (key === 'show_seen') Presence.send();
    try { await api('/api/privacy', { body: { [key]: on }, retry: true }); } catch (e) { me[key] = old; if (key === 'show_seen') Presence.send(); toast(errText(e)); return false; }
  };
  const recents = store.get('recents', 1);
  wrap.append(
    h('div', { class: 'prof', onclick: () => Nav.push(profileScreen(), 'profile') }, avatar(me.full_name, 68, false, { id: me.id, av: me.avatar_ver }),
      h('div', { class: 'pcol' }, h('div', { class: 'pname' }, h('h2', null, me.full_name), me.role === 'owner' ? h('span', { class: 'pill active' }, t('owner')) : null),
        h('p', { class: 'muted' }, '@' + me.username + ' \u00b7 ' + me.phone), me.about ? h('p', { class: 'muted s' }, me.about) : null), chev()),
    secHdr(t('sec_account')),
    me.role === 'owner' && srow('crown', t('owner_panel'), t('owner_panel_sub'), chev(), () => Nav.push(ownerPanel(), 'owner')),
    srow('user', t('contacts'), null, chev(), () => Nav.push(contactsScreen(), 'contacts')),
    srow('globe', t('language'), S.lang === 'ar' ? '\u0627\u0644\u0639\u0631\u0628\u064a\u0629' : 'English', chev(), async () => {
      const v = await sheet([{ v: 'en', label: 'English' }, { v: 'ar', label: '\u0627\u0644\u0639\u0631\u0628\u064a\u0629' }]);
      if (v) { setLang(v); Nav.replaceAll(mainScreen(), 'main'); }
    }),
    secHdr(t('sec_appearance')),
    srow('brush', t('theme_wall'), t('theme_wall_sub'), chev(), () => Nav.push(appearanceScreen(), 'appearance')),
    secHdr(t('sec_privacy')),
    srow('eye', t('priv_seen'), t('priv_seen_sub'), toggle(me.show_seen !== 0, priv('show_seen'))),
    srow('check', t('priv_read'), t('priv_read_sub'), toggle(me.show_read !== 0, priv('show_read'))),
    srow('pen', t('priv_typing'), t('priv_typing_sub'), toggle(me.show_typing !== 0, priv('show_typing'))),
    srow('lock', t('autolock'), t('autolock_sub'), toggle(S.autoLock, (v) => { S.autoLock = v; store.set('autolock', v); })),
    srow('phone', t('recents'), recents === 0 ? t('recents_hide') : (recents === 2 ? t('recents_normal') : t('recents_calc')), chev(), async () => {
      const v = await sheet([{ v: 0, icon: 'eyeoff', label: t('recents_hide') }, { v: 1, icon: 'calc', label: t('recents_calc') }, { v: 2, icon: 'phone', label: t('recents_normal') }]);
      if (v === null || v === undefined) return;
      store.set('recents', v); try { nat && nat.setRecents && nat.setRecents(v); } catch (e) { /* ignore */ } toast(t('saved')); Main.show('settings');
    }),
    srow('expand', t('floating'), t('floating_sub'), chev(), () => Nav.push(floatingScreen(), 'floating')),
    me.role === 'owner' && srow('image', t('allow_shots'), t('allow_shots_sub'), toggle(!!S.settings.allow_screens, async (v) => {
      const was = S.settings.allow_screens; S.settings.allow_screens = v; App.applySecure();      // applied at once
      api('/api/owner/settings', { body: { allow_screens: v }, retry: true }).catch((e) => { S.settings.allow_screens = was; App.applySecure(); App.refresh(); toast(errText(e)); });
    })),
    secHdr(t('sec_security')),
    srow('shield', t('encryption'), t('encryption_on'), null, () => toast(t('e2e_note'))),
    srow('phone', t('devices'), t('devices_sub'), chev(), () => Nav.push(sessionsScreen(), 'sessions')),
    srow('key' in ICONS ? 'lock' : 'lock', t('change_password'), null, chev(), () => changePwFlow('pass')),
    srow('shield', t('change_backup_pw'), t('backup_hint'), chev(), () => changePwFlow('rec')),
    srow('calc', t('calc_code'), t('calc_code_sub'), chev(), async () => {
      for (;;) {
        const v = await ask(t('calc_code'), [{ label: t('calc_code_cur'), type: 'tel', mode: 'numeric', max: 16 }, { label: t('calc_code_new'), type: 'tel', mode: 'numeric', max: 16, hint: t('calc_code_hint') }, { label: t('calc_code_new2'), type: 'tel', mode: 'numeric', max: 16 }], t('save'));
        if (!v) return;
        if (!(await Calc.codeOk(v[0]))) { toast(t('e_code_wrong')); continue; }
        if (!/^\d{4,12}$/.test(v[1])) { toast(t('e_code_fmt')); continue; }
        if (v[1] !== v[2]) { toast(t('e_pw_mismatch')); continue; }
        await Calc.setCode(v[1]); toast(t('saved')); return;
      }
    }),
    secHdr(t('sec_data')),
    srow('cloud', t('backup'), t('backup_sub'), chev(), () => Nav.push(backupScreen(), 'backup')),
    srow('phone', t('data_title'), t('data_title_sub'), chev(), () => Nav.push(dataScreen(), 'data')),
    upd,
    srow('up', t('sign_out'), null, null, () => App.signOut()),
    h('p', { class: 'muted center s ver' }, 'v' + NV.version()));
  return wrap;
}

/* ---------- edit my profile ---------- */
function profileScreen() {
  const el = h('div', { class: 'main' });
  const me = S.me;
  const name = h('input', { value: me.full_name, maxLength: 80 });
  const un = h('input', { value: me.username, autocapitalize: 'off', spellcheck: false, maxLength: 24 });
  const about = h('input', { value: me.about || '', maxLength: 140, placeholder: t('about_default') });
  const err = h('div', { class: 'err' });
  const avBox = h('div', { class: 'bigav edit' });
  const file = h('input', { type: 'file', accept: 'image/*', class: 'hidden' });
  const drawAv = () => avBox.replaceChildren(avatar(me.full_name, 120, false, { id: me.id, av: me.avatar_ver }), h('span', { class: 'camb' }, ic('camera', 20)));
  avBox.addEventListener('click', async () => {
    const v = await sheet([{ v: 'pick', icon: 'image', label: t('photo_choose') }, me.avatar_ver > 0 && { v: 'remove', icon: 'trash', label: t('photo_remove'), danger: true }]);
    if (v === 'pick') file.click();
    else if (v === 'remove') { try { const r = await api('/api/profile', { method: 'PATCH', body: { avatar: null } }); Object.assign(me, r.user); drawAv(); toast(t('saved')); } catch (e) { toast(errText(e)); } }
  });
  file.addEventListener('change', async () => {
    const f = file.files[0]; file.value = ''; if (!f) return;
    try {
      let q = 0.82, data = await Theme.fromFile(f, 320, q);
      while (data.length > 85000 && q > 0.4) { q -= 0.12; data = await Theme.fromFile(f, 320, q); }
      const r = await api('/api/profile', { method: 'PATCH', body: { avatar: data } });
      Object.assign(me, r.user); drawAv(); toast(t('saved'));
    } catch (e) { toast(errText(e)); }
  });
  const save = h('button', { class: 'btn primary wide' }, t('save'));
  save.addEventListener('click', async () => {
    err.textContent = '';
    const nm = name.value.trim().replace(/\s+/g, ' ');
    if (nm.split(' ').length < 4) return (err.textContent = t('e_bad_name'));
    if (!/^[a-zA-Z0-9_.]{3,24}$/.test(un.value.trim())) return (err.textContent = t('e_bad_username'));
    save.disabled = true;
    try {
      const body = {};
      if (nm !== me.full_name) body.full_name = nm;
      if (un.value.trim().toLowerCase() !== me.username) body.username = un.value.trim().toLowerCase();
      if (about.value.trim() !== (me.about || '')) body.about = about.value.trim();
      if (Object.keys(body).length) {
        const r = await api('/api/profile', { method: 'PATCH', body, quiet: true });
        Object.assign(me, r.user); store.set('last_name', me.full_name); store.set('last_user', me.username);
        S.users.set(me.id, Object.assign(S.users.get(me.id) || {}, { full_name: me.full_name, username: me.username, about: me.about }));
      }
      toast(t('saved')); Nav.pop(); Main.show('settings');
    } catch (e) { err.textContent = errText(e); }
    save.disabled = false;
  });
  el.append(header(t('edit_profile')), h('div', { class: 'pad' }, h('div', { class: 'ibig' }, avBox, h('p', { class: 'muted s' }, t('photo_hint'))),
    field(t('f_name'), name), field(t('f_user'), un, t('username_change_hint')), field(t('about'), about), h('p', { class: 'muted s' }, t('profile_signin_hint')), err, save, file));
  drawAv();
  return el;
}

/* ---------- themes and wallpapers ---------- */
function appearanceScreen() {
  const el = h('div', { class: 'main' });
  const body = h('div', { class: 'pad' });
  const file = h('input', { type: 'file', accept: 'image/*', class: 'hidden' });
  file.addEventListener('change', async () => {
    const f = file.files[0]; file.value = ''; if (!f) return;
    try { Theme.set({ wall: 'custom', custom: await Theme.fromFile(f, 1100, 0.72) }); draw(); toast(t('saved')); } catch (e) { toast(t('e_generic')); }
  });
  const draw = () => {
    const c = Theme.get();
    const pv = (PALETTES[c.theme] || PALETTES.classic);
    const wallCss = (k) => { const w = WALLS[k], img = (pv.light && w[3]) ? w[3] : w[1]; return { background: (img === 'none' ? '' : img + ', ') + (w[0] || pv.v.wallbg), backgroundSize: w[2] === 'cover' ? 'cover' : (w[2] === 'auto' ? 'auto' : '40px 40px') }; };
    body.replaceChildren(
      h('div', { class: 'msgs mini' }, h('div', { class: 'row in' }, h('div', { class: 'bub in' }, h('div', { class: 'txt' }, t('theme_preview_in')), h('div', { class: 'meta' }, '10:41'))),
        h('div', { class: 'row out' }, h('div', { class: 'bub out' }, h('div', { class: 'txt' }, t('theme_preview_out')), h('div', { class: 'meta' }, '10:42', tickEl([[1, 1, 1]], false))))),
      h('div', { class: 'sect' }, t('bidi')),
      h('div', { class: 'walls' }, ['ltr', 'auto'].map((k) => h('button', { class: 'wall' + (Bidi.get() === k ? ' on' : ''), style: { background: 'var(--card2)', color: 'var(--tx)' }, onclick: () => { Bidi.set(k); draw(); } }, h('span', { style: { color: 'var(--tx)', textShadow: 'none' } }, t('bidi_' + k))))),
      h('p', { class: 'muted s pad2' }, t('bidi_note')),
      h('div', { class: 'sect' }, t('theme')),
      h('div', { class: 'walls' }, Object.keys(PALETTES).map((k) => h('button', { class: 'wall' + (c.theme === k ? ' on' : ''), style: { background: PALETTES[k].v.bg, color: PALETTES[k].v.tx, borderColor: c.theme === k ? PALETTES[k].v.ac : PALETTES[k].v.bd2 }, onclick: () => { Theme.set({ theme: k, accent: null }); draw(); } }, h('span', { style: { color: PALETTES[k].v.tx, textShadow: 'none' } }, t('th_' + k))))),
      h('div', { class: 'sect' }, t('accent')),
      h('div', { class: 'swatches' }, Object.keys(ACCENTS).map((k) => h('button', { class: 'sw' + (c.accent === k ? ' on' : ''), style: { background: ACCENTS[k][0] }, onclick: () => { Theme.set({ accent: k }); draw(); } }, c.accent === k ? ic('check', 18) : null))),
      h('div', { class: 'sect' }, t('wallpaper')),
      h('div', { class: 'walls' }, Object.keys(WALLS).map((k) => h('button', { class: 'wall' + (c.wall === k ? ' on' : ''), style: wallCss(k), onclick: () => { Theme.set({ wall: k }); draw(); } }, h('span', null, t('wall_' + k)))),
        h('button', { class: 'wall custom' + (c.wall === 'custom' ? ' on' : ''), style: c.custom ? { backgroundImage: 'url(' + c.custom + ')', backgroundSize: 'cover' } : null, onclick: () => file.click() }, h('span', null, ic('image', 16), ' ', t('wall_custom')))),
      h('div', { class: 'sect' }, t('text_size')),
      h('div', { class: 'chiprow' }, ['s', 'm', 'l'].map((k) => h('button', { class: 'ch' + (c.size === k ? ' on' : ''), onclick: () => { Theme.set({ size: k }); draw(); } }, t('size_' + k)))),
      h('button', { class: 'btn ghost wide', onclick: () => { store.del('theme'); Theme.apply(); draw(); } }, t('theme_reset')), file);
  };
  el.append(header(t('theme_wall')), body); draw();
  return el;
}

/* ---------- the floating calculator button and full screen ---------- */
function floatingScreen() {
  const el = h('div', { class: 'main' });
  const body = h('div', { class: 'pad nopad' });
  const draw = () => {
    const c = Ball.cfg();
    body.replaceChildren(
      srow('calc', t('ball_show'), t('ball_show_sub'), toggle(c.show, (v) => { Ball.save({ show: v }); Ball.show(S.active); })),
      srow('expand', t('ball_move'), t('ball_move_sub'), toggle(c.move, (v) => { Ball.save({ move: v }); Ball.place(); })),
      srow('expand', t('fullscreen'), t('fullscreen_sub'), toggle(fsOn(), (v) => { store.set('fullscreen', v); App.applyFullscreen(); })),
      h('div', { class: 'sect pad2' }, t('ball_size')),
      h('div', { class: 'chiprow pad2' }, [[40, 's'], [48, 'm'], [58, 'l']].map(([px, k]) => h('button', { class: 'ch' + (c.size === px ? ' on' : ''), onclick: () => { Ball.save({ size: px }); Ball.place(); draw(); } }, t('size_' + k)))),
      h('div', { class: 'pad2' }, h('button', { class: 'btn ghost wide', onclick: () => { Ball.reset(); toast(t('ball_reset_done')); } }, t('ball_reset'))),
      h('p', { class: 'muted s pad2' }, t('ball_tip')));
  };
  el.append(header(t('floating')), body); draw();
  return el;
}

/* ---------- logged-in devices ---------- */
function sessionsScreen() {
  const el = h('div', { class: 'main' });
  const body = h('div', { class: 'pad nopad' });
  const load = async () => {
    try {
      const r = await api('/api/sessions');
      body.replaceChildren(...r.sessions.map((s) => srow('phone', (s.current ? t('this_device') : t('other_device')) + ' \u00b7 ' + (/Android/i.test(s.ua) ? 'Android' : /iPhone|iPad/i.test(s.ua) ? 'iOS' : t('device')), t('last_active', { d: fmtDay(s.last_used) + ' ' + fmtTime(s.last_used) }), s.current ? null : h('button', { class: 'btn small red', onclick: async () => { try { await api('/api/sessions/revoke', { body: { id: s.id } }); load(); } catch (e) { toast(errText(e)); } } }, t('log_out')))),
        r.sessions.length > 1 ? h('div', { class: 'pad2' }, h('button', { class: 'btn danger wide', onclick: async () => { if (await dialog({ title: t('log_out_all'), text: t('log_out_all_text'), ok: t('log_out'), danger: true })) { try { await api('/api/sessions/revoke', { body: { others: true } }); load(); } catch (e) { toast(errText(e)); } } } }, t('log_out_all'))) : null);
    } catch (e) { toast(errText(e)); }
  };
  el.append(header(t('devices')), body); load();
  return el;
}

/* ---------- backup ---------- */
function backupScreen() {
  const el = h('div', { class: 'main' });
  const file = h('input', { type: 'file', accept: '.cbk,application/octet-stream', class: 'hidden' });
  file.addEventListener('change', async () => { const f = file.files[0]; file.value = ''; if (f) await restoreBackup(f); });
  el.append(header(t('backup')), h('div', { class: 'pad' }, h('div', { class: 'ibig' }, h('div', { class: 'logo' }, ic('cloud', 30)), h('p', { class: 'muted center' }, t('backup_intro'))),
    h('p', { class: 'muted center s' }, (() => { const at = store.get('backup_at', 0); return at ? t('backup_last', { d: new Date(at).toLocaleString(S.lang === 'ar' ? 'ar-EG' : undefined) }) : t('backup_never'); })()),
    h('button', { class: 'btn primary wide', onclick: () => makeBackup() }, ic('download', 18), t('backup_create')),
    h('button', { class: 'btn ghost wide', onclick: () => file.click() }, ic('up', 18), t('backup_restore')),
    h('p', { class: 'muted s' }, t('backup_note')), file));
  return el;
}

/* ---------- owner: give a user a new locked-chats password ---------- */
async function resetLockFor(m) {
  const gen = String(100000 + Math.floor(Math.random() * 900000));
  const v = await ask(t('reset_lock'), [{ label: t('lock_new'), value: gen, hint: t('reset_lock_hint') }], t('save'), t('reset_lock_text', { n: m.full_name }));
  if (!v) return;
  const pw = v[0].trim();
  if (pw.length < 4) return toast(t('e_lock_short'));
  try {
    const salt = [...crypto.getRandomValues(new Uint8Array(8))].map((x) => x.toString(16).padStart(2, '0')).join('');
    await api('/api/owner/members/lockreset', { body: { id: m.id, salt, hash: await pbk(pw, salt) } });
    await dialog({ title: t('reset_lock_done'), text: t('reset_lock_done_text', { n: m.full_name, p: pw }), ok: t('ok'), cancel: false });
  } catch (e) { toast(errText(e)); }
}

/* ---------- storage & data: what is saved on this phone and (owner) where the files live on the server ---------- */
function dataScreen() {
  const el = h('div', { class: 'main' });
  const mine = h('div'), srv = h('div');
  const drawMine = async () => {
    const st = await Disk.stats();
    mine.replaceChildren(
      secHdr(t('data_phone')),
      h('p', { class: 'muted s pad2' }, t('data_phone_text')),
      srow('cloud', t('data_saved'), Disk.ok() ? t('data_saved_n', { c: st.chats, m: st.msgs }) : t('data_off'), null),
      srow('trash', t('data_clear'), t('data_clear_sub'), chev(), async () => {
        if (Quota.active()) return toast(Quota.text());
        if (!(await dialog({ title: t('data_clear'), text: t('data_clear_confirm'), ok: t('data_clear_go'), danger: true }))) return;
        await Disk.reset(); S.ver = null; S.cur = 0; S.chats.clear(); S.msgs.clear(); S.hist.clear(); S.rc.clear(); App.refresh();
        Sync.now(); toast(t('saved')); drawMine();
      }));
  };
  const move = async () => {
    if (!(await dialog({ title: t('data_move'), text: t('data_move_confirm'), ok: t('data_move_go') }))) return;
    let stop = false, n = 0;
    const prog = h('p', { class: 'muted center' }, t('data_moved_n', { n: 0 }));
    const o = overlay(h('div', { class: 'dlg' }, h('h3', null, t('data_moving')), prog, h('div', { class: 'spin' }),
      h('div', { class: 'dlg-b' }, h('button', { class: 'btn ghost', onclick: () => { stop = true; } }, t('cancel')))), { center: true, sticky: true });
    try {
      while (!stop) {
        const r = await api('/api/owner/migrate', { body: {}, timeout: 55000 });
        n += r.moved || 0; prog.textContent = t('data_moved_n', { n });
        if (!r.more) break;
      }
      toast(t('data_move_done', { n }));
    } catch (e) { toast(errText(e)); }
    o.close(); drawSrv();
  };
  const drawSrv = async () => {
    if (S.me.role !== 'owner') return;
    let r;
    try { r = await api('/api/owner/storage', { quiet: true }); } catch (e) { srv.replaceChildren(h('p', { class: 'muted s pad2' }, errText(e))); return; }
    const old = r.old_files || r.old_avatars;
    srv.replaceChildren(
      secHdr(t('data_server')),
      srow('cloud', t('data_store'), t('store_' + r.store), null),
      r.store === 'none' ? h('p', { class: 'muted s pad2' }, t('store_none_help')) : null,
      old ? srow('up', t('data_move'), r.store === 'none' ? t('data_move_need') : t('data_move_sub'), r.store === 'none' ? null : chev(), r.store === 'none' ? null : move)
        : srow('check', t('data_clean'), null, null));
  };
  el.append(header(t('data_title')), h('div', { class: 'pad nopad' }, mine, srv));
  drawMine(); drawSrv();
  return el;
}
